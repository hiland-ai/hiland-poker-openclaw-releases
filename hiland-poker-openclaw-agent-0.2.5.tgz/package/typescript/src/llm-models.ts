/**
 * Fetch OpenAI-compatible GET /v1/models (or {baseUrl}/models) and keep ids
 * suitable for Hiland poker JSON decision advisor (chat/completions class models).
 */

const DECISION_UNSUITABLE_SUBSTRINGS = [
  'embed',
  'embedding',
  'text-embedding',
  'whisper',
  'dall-e',
  'dall_e',
  'gpt-image',
  'gpt_image',
  'image-alpha',
  'tts',
  'text-to-speech',
  'speech-',
  '-speech',
  'moderation',
  'omni-moderation',
  'rerank',
  'reranker',
  'transcrib',
  'dictation',
  'realtime-preview',
  'audio-',
  '-audio',
  'video-',
] as const

export function isDecisionSuitableModelId(id: string): boolean {
  const s = id.trim().toLowerCase()
  if (!s) return false
  for (const frag of DECISION_UNSUITABLE_SUBSTRINGS) {
    if (s.includes(frag)) return false
  }
  return true
}

function modelsListURL(baseUrl: string): string {
  const trimmed = baseUrl.trim().replace(/\/+$/, '')
  return `${trimmed}/models`
}

export async function fetchDecisionSuitableModelIds(
  baseUrl: string,
  apiKey: string,
  timeoutMs = 10_000,
): Promise<string[]> {
  const key = apiKey.trim()
  if (!key) throw new Error('missing API key for models list')

  const url = modelsListURL(baseUrl)
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), Math.max(2000, timeoutMs))
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${key}`,
        Accept: 'application/json',
      },
      signal: controller.signal,
    })
    if (!res.ok) {
      const t = await res.text().catch(() => '')
      throw new Error(`models list HTTP ${res.status}${t ? `: ${t.slice(0, 200)}` : ''}`)
    }
    const body = (await res.json()) as { data?: unknown }
    const rows = Array.isArray(body.data) ? body.data : []
    const ids: string[] = []
    for (const row of rows) {
      if (!row || typeof row !== 'object') continue
      const id = (row as { id?: unknown }).id
      if (typeof id !== 'string' || !id.trim()) continue
      if (!isDecisionSuitableModelId(id)) continue
      ids.push(id.trim())
    }
    const unique = [...new Set(ids)]
    unique.sort((a, b) => a.localeCompare(b))
    return unique
  } finally {
    clearTimeout(timer)
  }
}
