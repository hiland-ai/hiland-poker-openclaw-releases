// Minimal Agent client. Wraps the Hiland Poker agent WebSocket protocol
// behind a simple `decide()` callback.
//
// Usage:
//   const agent = new AgentClient({
//     url: 'wss://host/agent',
//     pat: process.env.HILAND_PAT!,
//     decide: async ({ state, request }) => ({ action: 'call' }),
//   })
//   await agent.start()

import { EventEmitter } from 'node:events'
import WebSocket from 'ws'
import { PLUGIN_VERSION } from '../../plugin-version.js'
import type {
  Inbound,
  Outbound,
  MsgHello,
  MsgGameState,
  MsgDecisionRequest,
  MsgActionResult,
  MsgError,
  MsgModeChanged,
  MsgPong,
  ActionKind,
  ActionSubmitKind,
  LegalAction,
} from './types.js'

export interface DecideResult {
  action: ActionKind
  amount?: number
  // Defaults to 'submit' in auto modes when autosubmit=true, 'suggestion' otherwise.
  kind?: ActionSubmitKind
  confidence?: number
  rationale?: string
}

export interface DecideContext {
  state: MsgGameState
  request: MsgDecisionRequest
  legalActions: LegalAction[]
}

export interface AgentClientOptions {
  url: string
  pat: string
  /** Sent as X-Hiland-Agent-Name (e.g. OpenClaw session nickname). */
  agentDisplayName?: string
  decide: (ctx: DecideContext) => Promise<DecideResult> | DecideResult
  // Safety default: false. When false, auto modes still emit suggestions only.
  autosubmit?: boolean
  heartbeatMs?: number
  onEvent?: (event: AgentClientEvent) => void
  onError?: (err: Error) => void
}

export type AgentClientEvent =
  | { type: 'connected' }
  | { type: 'hello'; message: MsgHello }
  | { type: 'game_state'; message: MsgGameState }
  | { type: 'decision_request'; message: MsgDecisionRequest }
  | { type: 'action_sent'; message: Outbound & { type: 'action' } }
  | { type: 'action_result'; message: MsgActionResult }
  | { type: 'mode_changed'; message: MsgModeChanged }
  | { type: 'pong'; message: MsgPong }
  | { type: 'server_error'; message: MsgError }
  | { type: 'closed'; code: number; reason: string }

export class AgentClient extends EventEmitter {
  private ws: WebSocket | null = null
  private lastState: MsgGameState | null = null
  private heartbeat: ReturnType<typeof setInterval> | null = null

  constructor(private readonly opts: AgentClientOptions) {
    super()
  }

  async start(): Promise<void> {
    const wsURL = new URL(this.opts.url)
    wsURL.searchParams.set('token', this.opts.pat)
    const url = wsURL.toString()
    const agentName = (this.opts.agentDisplayName ?? 'openclaw').trim() || 'openclaw'
    this.ws = new WebSocket(url, {
      headers: {
        'X-Hiland-Agent-Name': agentName.length > 80 ? agentName.slice(0, 80) : agentName,
        'X-Hiland-Agent-Version': PLUGIN_VERSION,
        'X-Hiland-Protocol': 'hiland-poker-agent/1',
      },
    })

    // Attach protocol handlers before awaiting `open`; a fast server may send
    // hello/game_state/decision_request immediately after the handshake.
    this.ws.on('message', (data: WebSocket.RawData) => void this.onMessage(data))
    this.ws.on('error', (e: Error) => this.opts.onError?.(e))
    this.ws.on('close', (code, reason) => {
      this.clearHeartbeat()
      this.emitEvent({ type: 'closed', code, reason: reason.toString() })
    })

    await new Promise<void>((resolve, reject) => {
      this.ws!.once('open', () => {
        this.emitEvent({ type: 'connected' })
        resolve()
      })
      this.ws!.once('error', (e: Error) => reject(e))
    })
    this.heartbeat = setInterval(
      () => this.send({ type: 'ping', ts: Date.now() }),
      this.opts.heartbeatMs ?? 20_000,
    )
  }

  close(): void {
    this.clearHeartbeat()
    this.ws?.close()
    this.ws = null
  }

  getLatestState(): MsgGameState | null {
    return this.lastState
  }

  private clearHeartbeat(): void {
    if (this.heartbeat) clearInterval(this.heartbeat)
    this.heartbeat = null
  }

  private send(msg: Outbound): void {
    this.ws?.send(JSON.stringify(msg))
  }

  private emitEvent(event: AgentClientEvent): void {
    this.opts.onEvent?.(event)
    this.emit(event.type, event)
  }

  private async onMessage(data: WebSocket.RawData): Promise<void> {
    let msg: Inbound
    try {
      msg = JSON.parse(data.toString()) as Inbound
    } catch (e) {
      this.opts.onError?.(e as Error)
      return
    }

    switch (msg.type) {
      case 'hello':
        this.emitEvent({ type: 'hello', message: msg })
        return
      case 'game_state':
        this.lastState = msg
        this.emitEvent({ type: 'game_state', message: msg })
        return
      case 'decision_request':
        this.emitEvent({ type: 'decision_request', message: msg })
        await this.handleDecisionRequest(msg)
        return
      case 'action_result':
        this.emitEvent({ type: 'action_result', message: msg })
        return
      case 'mode_changed':
        this.emitEvent({ type: 'mode_changed', message: msg })
        return
      case 'pong':
        this.emitEvent({ type: 'pong', message: msg })
        return
      case 'error':
        this.emitEvent({ type: 'server_error', message: msg })
        return
      default: {
        const neverMsg: never = msg
        this.opts.onError?.(new Error(`unknown message type: ${JSON.stringify(neverMsg)}`))
      }
    }
  }

  private async handleDecisionRequest(request: MsgDecisionRequest): Promise<void> {
    if (!this.lastState) {
      this.opts.onError?.(new Error(`decision_request ${request.requestId} arrived before game_state`))
      return
    }

    try {
      const legalActions = request.legalActions ?? this.lastState.legalActions ?? []
      const result = await this.opts.decide({
        state: this.lastState,
        request,
        legalActions,
      })
      const kind: ActionSubmitKind =
        result.kind ??
        (this.opts.autosubmit &&
        (request.mode === 'auto_with_veto' || request.mode === 'full_auto')
          ? 'submit'
          : 'suggestion')
      const action: Outbound & { type: 'action' } = {
        type: 'action',
        requestId: request.requestId,
        stateSeq: request.stateSeq ?? this.lastState.stateSeq,
        action: result.action,
        amount: result.amount,
        kind,
        confidence: result.confidence,
        rationale: result.rationale,
      }
      this.send(action)
      this.emitEvent({ type: 'action_sent', message: action })
    } catch (e) {
      this.opts.onError?.(e as Error)
    }
  }
}
