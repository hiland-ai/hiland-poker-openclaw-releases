import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import type { MsgGameState } from './types.js'

/** Playstyle / narrative persona (orthogonal to conservative|balanced|aggressive). */
export type AgentPersona =
  | 'gto_cold'
  | 'mad_dog'
  | 'exploit'
  | 'turtle'
  | 'grudge'
  | 'learning'
  | 'trash_talk'

const PERSONA_ALIASES: Record<string, AgentPersona> = {
  gto_cold: 'gto_cold',
  gto: 'gto_cold',
  gto_cool: 'gto_cold',
  cold: 'gto_cold',
  // 中文别名
  gto冷血型: 'gto_cold',
  gt冷血型: 'gto_cold',
  冷血型: 'gto_cold',
  冷血: 'gto_cold',
  mad_dog: 'mad_dog',
  maddog: 'mad_dog',
  aggro: 'mad_dog',
  maniac: 'mad_dog',
  疯狗: 'mad_dog',
  疯狗激进型: 'mad_dog',
  exploit: 'exploit',
  老阴逼: 'exploit',
  剥削: 'exploit',
  nit: 'turtle',
  turtle: 'turtle',
  nitty: 'turtle',
  保守: 'turtle',
  苟命: 'turtle',
  苟命型: 'turtle',
  grudge: 'grudge',
  revenge: 'grudge',
  记仇: 'grudge',
  记仇型: 'grudge',
  learning: 'learning',
  evolve: 'learning',
  adaptive: 'learning',
  学习型: 'learning',
  学习: 'learning',
  trash_talk: 'trash_talk',
  trashtalk: 'trash_talk',
  banter: 'trash_talk',
  mouth: 'trash_talk',
  嘴炮: 'trash_talk',
  嘴炮型: 'trash_talk',
}

export function normalizePersona(value: unknown): AgentPersona | undefined {
  if (value === undefined || value === null) return undefined
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  if (!trimmed) return undefined
  const asciiKey = trimmed.toLowerCase().replace(/[\s-]+/g, '_')
  if (PERSONA_ALIASES[asciiKey]) return PERSONA_ALIASES[asciiKey]
  const cnKey = trimmed.replace(/\s+/g, '').replace(/[A-Za-z]+/g, (s) => s.toLowerCase())
  if (PERSONA_ALIASES[cnKey]) return PERSONA_ALIASES[cnKey]
  return undefined
}

/** Table “bully” heuristic: deepest stack still in the hand (for grudge / exploit bias). */
export function pickNemesisSeat(state: MsgGameState): number | null {
  const hero = state.yourSeat
  const entries = Object.entries(state.stacks ?? {})
    .map(([k, v]) => [Number(k), Number(v)] as const)
    .filter(([seat, stack]) => seat !== hero && Number.isFinite(stack) && stack > 0)
  if (!entries.length) return null
  entries.sort((a, b) => b[1] - a[1])
  return entries[0]![0]!
}

export function isNemesisInHand(state: MsgGameState, nemesisSeat: number | null | undefined): boolean {
  if (nemesisSeat == null) return false
  const stack = Number(state.stacks?.[nemesisSeat] ?? 0)
  return Number.isFinite(stack) && stack > 0
}

type RuntimeFile = { rooms: Record<string, { lastHandId: string; handsSeen: number }> }

function readRuntime(): RuntimeFile {
  try {
    const file = path.join(os.homedir(), '.hiland-poker', 'persona-runtime.json')
    if (!fs.existsSync(file)) return { rooms: {} }
    const raw = JSON.parse(fs.readFileSync(file, 'utf8')) as RuntimeFile
    if (!raw || typeof raw !== 'object' || !raw.rooms) return { rooms: {} }
    return raw
  } catch {
    return { rooms: {} }
  }
}

function writeRuntime(data: RuntimeFile): void {
  try {
    const dir = path.join(os.homedir(), '.hiland-poker')
    fs.mkdirSync(dir, { recursive: true })
    const file = path.join(dir, 'persona-runtime.json')
    fs.writeFileSync(file, JSON.stringify(data, null, 0), 'utf8')
  } catch {
    // best-effort persistence only
  }
}

/**
 * Increments per-room hand counter when handId changes (for learning persona).
 * Returns the 0-based index after this observation.
 */
export function observePersonaHand(roomId: string | undefined, handId: string | undefined): number {
  if (!roomId || !handId) return 0
  const data = readRuntime()
  const prev = data.rooms[roomId]
  if (!prev) {
    data.rooms[roomId] = { lastHandId: handId, handsSeen: 0 }
    writeRuntime(data)
    return 0
  }
  if (prev.lastHandId === handId) return prev.handsSeen
  const next = { lastHandId: handId, handsSeen: prev.handsSeen + 1 }
  data.rooms[roomId] = next
  writeRuntime(data)
  return next.handsSeen
}

export interface PersonaBaselineTuning {
  callThresholdDelta: number
  pressureLimitDelta: number
  /** Added to free-card bet strength gates (higher = need stronger hand to bet). */
  freeBetGateDelta: number
  /** Extra fraction toward max when sizing bet/raise (0..1 scale). */
  sizingPush: number
  /** Prefer jam (all-in) when legal and strength above this threshold. */
  jamStrength: number | null
}

export function baselineTuningForPersona(
  persona: AgentPersona | undefined,
  nemesisActive: boolean,
): PersonaBaselineTuning {
  const neutral: PersonaBaselineTuning = {
    callThresholdDelta: 0,
    pressureLimitDelta: 0,
    freeBetGateDelta: 0,
    sizingPush: 0,
    jamStrength: null,
  }
  if (!persona) return neutral
  switch (persona) {
    case 'gto_cold':
      return {
        callThresholdDelta: 0.05,
        pressureLimitDelta: -0.04,
        freeBetGateDelta: 0.06,
        sizingPush: -0.06,
        jamStrength: null,
      }
    case 'mad_dog':
      return {
        callThresholdDelta: -0.14,
        pressureLimitDelta: 0.2,
        freeBetGateDelta: -0.1,
        sizingPush: 0.35,
        jamStrength: 0.52,
      }
    case 'exploit':
      return {
        callThresholdDelta: -0.06,
        pressureLimitDelta: 0.08,
        freeBetGateDelta: -0.04,
        sizingPush: 0.12,
        jamStrength: null,
      }
    case 'turtle':
      return {
        callThresholdDelta: 0.12,
        pressureLimitDelta: -0.1,
        freeBetGateDelta: 0.1,
        sizingPush: -0.1,
        jamStrength: 0.94,
      }
    case 'grudge':
      if (!nemesisActive) return neutral
      return {
        callThresholdDelta: -0.1,
        pressureLimitDelta: 0.14,
        freeBetGateDelta: -0.06,
        sizingPush: 0.22,
        jamStrength: 0.58,
      }
    case 'learning':
    case 'trash_talk':
      return neutral
    default:
      return neutral
  }
}

export function personaSystemPromptAddendum(persona: AgentPersona | undefined, language: 'zh-CN' | 'en'): string {
  if (!persona) return ''
  const zh: Record<AgentPersona, string> = {
    gto_cold: '人格：GTO 冷血机器人。情绪中立、无嘴炮；用频率与数学语言思考；rationale 简短冰冷。',
    mad_dog: '人格：疯狗激进。偏好 3-bet、超池、全下；节目效果优先但动作必须仍在 legalActions 内；rationale 可略带挑衅。',
    exploit: '人格：老阴逼剥削。针对对手倾向与筹码深度剥削，小底池控池、大底池收割；rationale 暗示“在读人”但不编造读心结果。',
    turtle: '人格：保守苟命。多数时候弃牌或过牌；只在极强牌或极大底池期望值下突然重锤；rationale 体现隐忍。',
    grudge: '人格：记仇。把筹码最深的对手当作“霸凌者”，对其范围更激进反击（诈唬与价值混合）；不得捏造对方具体手牌。',
    learning: '人格：学习型。随牌局推进略微调整激进程度；在 rationale 里可带一句“上一手之后的调整”但不要编造不存在的牌谱。',
    trash_talk: '人格：嘴炮。rationale 要啰嗦、挑衅、带误导性夸张，但仍须合法动作；禁止暴露真实思考细节或编造他人底牌。',
  }
  const en: Record<AgentPersona, string> = {
    gto_cold: 'Persona: GTO ice-bot. Emotionless, no theatrics; frequency/math tone; keep rationale cold and short.',
    mad_dog: 'Persona: maniac. Prefer 3-bet, overbets, jams when legal; entertainment-first; rationale may be spicy.',
    exploit: 'Persona: exploitative nit-with-teeth. Small pots control, big pots strike; imply reads without claiming soul reads.',
    turtle: 'Persona: ultra-nit. Fold/check a lot; suddenly hammer only with huge equity or huge payoff; rationale shows patience.',
    grudge: 'Persona: grudge. Treat the deepest-stack villain as your nemesis; fight back more aggressively (mix); never invent hole cards.',
    learning: 'Persona: evolving. Shift style as the session progresses; you may hint at adaptation without inventing prior hands.',
    trash_talk: 'Persona: trash talk. Longer provocative misleading rationale; still pick exactly one legal action; no real hole-card claims.',
  }
  return language === 'en' ? en[persona]! : zh[persona]!
}

export function rationaleMaxChars(persona: AgentPersona | undefined): number {
  return persona === 'trash_talk' ? 200 : 80
}
