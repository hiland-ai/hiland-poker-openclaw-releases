import type {
  ActionKind,
  LegalAction,
  MsgDecisionRequest,
  MsgGameState,
  RangedAmountLegalAction,
} from './types.js'
import type { DecideResult } from './client.js'
import {
  baselineTuningForPersona,
  isNemesisInHand,
  type AgentPersona,
} from './persona.js'

export type StrategyName = 'conservative' | 'balanced' | 'aggressive'

const RANK_VALUE: Record<string, number> = {
  '2': 2,
  '3': 3,
  '4': 4,
  '5': 5,
  '6': 6,
  '7': 7,
  '8': 8,
  '9': 9,
  T: 10,
  J: 11,
  Q: 12,
  K: 13,
  A: 14,
}

export interface StrategyContext {
  state: MsgGameState
  request?: MsgDecisionRequest
  legalActions: LegalAction[]
  strategy?: StrategyName | string
  persona?: AgentPersona
  /** 0-based hands seen in this room (for learning). */
  personaHandIndex?: number
  nemesisSeat?: number | null
}

export function resolveLearningStrategy(handIndex: number): StrategyName {
  const cycle: StrategyName[] = ['conservative', 'balanced', 'aggressive']
  return cycle[Math.max(0, handIndex) % 3]!
}

export function decideWithBaselineStrategy(ctx: StrategyContext): DecideResult {
  let strategy = normalizeStrategy(ctx.strategy)
  const persona = ctx.persona
  const nemesisActive = isNemesisInHand(ctx.state, ctx.nemesisSeat ?? null)
  const tune = baselineTuningForPersona(persona, nemesisActive)

  if (persona === 'learning' && ctx.personaHandIndex !== undefined) {
    strategy = resolveLearningStrategy(ctx.personaHandIndex)
  } else if (persona === 'mad_dog') {
    strategy = 'aggressive'
  } else if (persona === 'turtle') {
    strategy = 'conservative'
  } else if (persona === 'gto_cold') {
    strategy = 'balanced'
  } else if (persona === 'exploit') {
    strategy = strategy === 'conservative' ? 'balanced' : 'aggressive'
  } else if (persona === 'grudge' && nemesisActive) {
    strategy = 'aggressive'
  }

  const legalActions = ctx.legalActions.length ? ctx.legalActions : fallbackLegalActions(ctx.state)
  const strength = estimateHandStrength(ctx.state)
  const toCall = Math.max(0, ctx.state.toCall ?? 0)
  const stack = Number(ctx.state.stacks?.[ctx.state.yourSeat] ?? 0)
  const pressureRatio = stack > 0 ? toCall / stack : toCall > 0 ? 1 : 0

  const check = findLegal(legalActions, 'check')
  const fold = findLegal(legalActions, 'fold')
  const call = findFixedLegal(legalActions, 'call')
  const bet = findRangedLegal(legalActions, 'bet')
  const raise = findRangedLegal(legalActions, 'raise')
  const allin = findFixedLegal(legalActions, 'allin')

  const agGate = 0.62 + tune.freeBetGateDelta
  const balGate = 0.72 + tune.freeBetGateDelta
  const conGate = 0.82 + tune.freeBetGateDelta

  if (toCall === 0) {
    if (strategy === 'aggressive' && strength >= agGate && bet) {
      return sizedResult('bet', bet, stack, strength, tune.sizingPush, 'Free option with playable strength; apply pressure.')
    }
    if (strategy === 'balanced' && strength >= balGate && bet) {
      return sizedResult('bet', bet, stack, strength, tune.sizingPush, 'Strong enough to value bet while keeping sizing controlled.')
    }
    if (strategy === 'conservative' && strength >= conGate && bet) {
      return sizedResult('bet', bet, stack, strength, tune.sizingPush, 'Premium holding; small value bet is acceptable.')
    }
    if (check) {
      return {
        action: 'check',
        confidence: confidenceFromStrength(strength),
        rationale: 'No chips needed; take the free card / showdown option.',
      }
    }
  }

  let callThreshold = strategy === 'aggressive' ? 0.42 : strategy === 'balanced' ? 0.5 : 0.62
  let pressureLimit = strategy === 'aggressive' ? 0.35 : strategy === 'balanced' ? 0.22 : 0.12
  callThreshold = clamp(callThreshold + tune.callThresholdDelta, 0.2, 0.78)
  pressureLimit = clamp(pressureLimit + tune.pressureLimitDelta, 0.05, 0.55)

  const nutRaiseLine = 0.84
  if (strength >= nutRaiseLine && (raise || allin)) {
    if (raise) {
      return sizedResult('raise', raise, stack, strength, tune.sizingPush, 'Very strong holding; raise for value.')
    }
    if (allin) {
      return fixedResult('allin', allin.amount, strength, 'Very strong holding and all-in is legal.')
    }
  }

  if (tune.jamStrength != null && allin && strength >= tune.jamStrength && strength < nutRaiseLine) {
    return fixedResult('allin', allin.amount, strength, 'Persona prefers getting the chips in now while legal.')
  }

  if (call && strength >= callThreshold && pressureRatio <= pressureLimit) {
    return fixedResult('call', call.amount ?? toCall, strength, 'Price is acceptable for current hand strength.')
  }

  if (strategy === 'aggressive' && strength >= 0.72 + tune.freeBetGateDelta * 0.5 && raise) {
    return sizedResult('raise', raise, stack, strength, tune.sizingPush, 'Aggressive profile: apply pressure with a strong playable hand.')
  }

  if (fold) {
    return {
      action: 'fold',
      confidence: 0.72,
      rationale: 'Calling pressure is not justified by visible strength.',
    }
  }

  if (call) {
    return fixedResult('call', call.amount ?? toCall, strength, 'Fold unavailable; call is the safest legal continuation.')
  }

  if (check) {
    return {
      action: 'check',
      confidence: 0.65,
      rationale: 'Passive legal action available; avoid unnecessary risk.',
    }
  }

  const first = legalActions[0]
  if (first) {
    return actionFromLegal(first, strength, 'Fallback to first server-provided legal action.')
  }

  return {
    action: 'fold',
    confidence: 0.25,
    rationale: 'No legal action list available; choose safest passive fallback.',
  }
}

export function normalizeStrategy(strategy: unknown): StrategyName {
  if (strategy === 'conservative' || strategy === 'balanced' || strategy === 'aggressive') {
    return strategy
  }
  return 'balanced'
}

export function estimateHandStrength(state: MsgGameState): number {
  const cards = [...(state.yourHole ?? []), ...state.board]
  if (!state.yourHole || state.yourHole.length !== 2) return 0.35

  const hole = state.yourHole.map(parseCard).filter(Boolean) as ParsedCard[]
  const parsed = cards.map(parseCard).filter(Boolean) as ParsedCard[]
  if (hole.length !== 2) return 0.35

  const ranks = parsed.map((card) => card.rank)
  const suits = parsed.map((card) => card.suit)
  const rankCounts = countBy(ranks)
  const suitCounts = countBy(suits)
  const maxRankMultiplicity = Math.max(...Object.values(rankCounts))
  const maxSuitMultiplicity = Math.max(...Object.values(suitCounts))
  const sortedHole = [...hole].sort((a, b) => b.rank - a.rank)
  const isPair = hole[0]!.rank === hole[1]!.rank
  const isSuited = hole[0]!.suit === hole[1]!.suit
  const high = sortedHole[0]!.rank
  const low = sortedHole[1]!.rank
  const connected = high - low <= 1

  let score = 0.28
  score += (high - 2) / 12 * 0.22
  score += (low - 2) / 12 * 0.12
  if (isPair) score += 0.24 + (high - 2) / 12 * 0.1
  if (isSuited) score += 0.06
  if (connected) score += 0.04
  if (maxRankMultiplicity >= 4) score += 0.35
  else if (maxRankMultiplicity >= 3) score += 0.26
  else if (Object.values(rankCounts).filter((count) => count >= 2).length >= 2) score += 0.18
  else if (maxRankMultiplicity >= 2) score += 0.1
  if (maxSuitMultiplicity >= 5) score += 0.14
  if (hasStraightLike(ranks)) score += 0.12

  return clamp(score, 0.05, 0.98)
}

type ParsedCard = { rank: number; suit: string }

function parseCard(card: string): ParsedCard | null {
  const trimmed = card.trim()
  if (trimmed.length < 2) return null
  const suit = trimmed.at(-1)!
  const rankText = trimmed.slice(0, -1).toUpperCase()
  const rank = RANK_VALUE[rankText]
  if (!rank) return null
  return { rank, suit }
}

function countBy<T extends string | number>(items: T[]): Record<string, number> {
  const counts: Record<string, number> = {}
  for (const item of items) {
    const key = String(item)
    counts[key] = (counts[key] ?? 0) + 1
  }
  return counts
}

function hasStraightLike(ranks: number[]): boolean {
  const unique = [...new Set(ranks)]
  if (unique.includes(14)) unique.push(1)
  unique.sort((a, b) => a - b)
  let run = 1
  for (let i = 1; i < unique.length; i += 1) {
    if (unique[i] === unique[i - 1]! + 1) {
      run += 1
      if (run >= 5) return true
    } else {
      run = 1
    }
  }
  return false
}

function fallbackLegalActions(state: MsgGameState): LegalAction[] {
  if (state.toCall === 0) return [{ action: 'check' }]
  return [{ action: 'fold' }, { action: 'call', amount: state.toCall }]
}

function findLegal<TAction extends ActionKind>(legalActions: LegalAction[], action: TAction) {
  return legalActions.find((item) => item.action === action) as Extract<LegalAction, { action: TAction }> | undefined
}

function findFixedLegal(legalActions: LegalAction[], action: 'call' | 'allin') {
  return legalActions.find((item) => item.action === action) as Extract<LegalAction, { action: typeof action }> | undefined
}

function findRangedLegal(legalActions: LegalAction[], action: 'bet' | 'raise') {
  return legalActions.find((item) => item.action === action) as RangedAmountLegalAction | undefined
}

function sizedResult(
  action: 'bet' | 'raise',
  legal: RangedAmountLegalAction,
  stack: number,
  strength: number,
  sizingPush: number,
  rationale: string,
): DecideResult {
  const minAmount = legal.minAmount ?? legal.amount ?? 0
  const maxAmount = legal.maxAmount ?? (stack || minAmount)
  const baseFrac = strength > 0.9 ? 0.35 : 0.18
  const frac = clamp(baseFrac + sizingPush, 0.08, 0.92)
  const target = Math.round(minAmount + Math.max(0, maxAmount - minAmount) * frac)
  return {
    action,
    amount: clampInteger(target, minAmount, maxAmount),
    confidence: confidenceFromStrength(strength),
    rationale,
  }
}

function fixedResult(action: 'call' | 'allin', amount: number | undefined, strength: number, rationale: string): DecideResult {
  return {
    action,
    amount,
    confidence: confidenceFromStrength(strength),
    rationale,
  }
}

function actionFromLegal(legal: LegalAction, strength: number, rationale: string): DecideResult {
  if (legal.action === 'bet' || legal.action === 'raise') {
    return sizedResult(legal.action, legal, legal.maxAmount ?? legal.amount ?? 0, strength, 0, rationale)
  }
  return {
    action: legal.action,
    amount: 'amount' in legal ? legal.amount : undefined,
    confidence: confidenceFromStrength(strength),
    rationale,
  }
}

function confidenceFromStrength(strength: number) {
  return clamp(0.45 + Math.abs(strength - 0.5), 0.45, 0.9)
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value))
}

function clampInteger(value: number, min: number, max: number) {
  return Math.trunc(clamp(value, min, max))
}
