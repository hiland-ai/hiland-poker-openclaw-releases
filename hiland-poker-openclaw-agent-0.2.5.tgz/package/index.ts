import { definePluginEntry } from 'openclaw/plugin-sdk/plugin-entry'
import WebSocket from 'ws'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { PLUGIN_VERSION } from './plugin-version.js'
import { AgentClient, type AgentClientEvent, type DecideResult } from './typescript/src/client.js'
import {
  decideWithBaselineStrategy,
  normalizeStrategy,
  type StrategyName,
} from './typescript/src/strategy.js'
import {
  decideWithLLMAdvisor,
  hasRunnableLLMAdvisor,
  listMissingLLMAdvisorRequirements,
  resolveLLMAdvisorConfig,
  type LLMAdvisorConfig,
  type LLMAdvisorDecision,
} from './typescript/src/llm-advisor.js'
import { fetchDecisionSuitableModelIds } from './typescript/src/llm-models.js'
import {
  normalizePersona,
  observePersonaHand,
  pickNemesisSeat,
  type AgentPersona,
} from './typescript/src/persona.js'
import type { LegalAction, MsgDecisionRequest, MsgGameState } from './typescript/src/types.js'

const PERSONA_ENUM = [
  'gto_cold',
  'mad_dog',
  'exploit',
  'turtle',
  'grudge',
  'learning',
  'trash_talk',
] as const satisfies readonly AgentPersona[]

const personaSchemaProperty = {
  type: 'string',
  enum: [...PERSONA_ENUM],
  description:
    'Agent playstyle persona: gto_cold (robotic), mad_dog (maniac), exploit (nit-with-teeth), turtle (ultra-nit), grudge (vs deep-stack bully), learning (rotating style), trash_talk (longer spicy rationale). Defaults unset (strategy-only).',
} as const

type AdvisorEngine = 'baseline' | 'llm'

type AdvisorDecisionResult = DecideResult & {
  source?: LLMAdvisorDecision['source']
  fallbackReason?: string
}

type PluginConfig = {
  apiBaseUrl?: string
  nickname?: string
  agentUrl?: string
  strategy?: StrategyName
  persona?: AgentPersona
  autosubmit?: boolean
  advisor?: AdvisorEngine
  llmProvider?: LLMAdvisorConfig['provider']
  llmProtocol?: LLMAdvisorConfig['protocol']
  llmBaseUrl?: string
  llmModel?: string
  llmTimeoutMs?: number
  llmTemperature?: number
  llmMaxTokens?: number
  llmLanguage?: LLMAdvisorConfig['language']
}

type ToolContent = { type: 'text'; text: string }

type ToolResult<TDetails> = {
  content: ToolContent[]
  details: TDetails
}

type LoginCodeToolResult = {
  status: 'issued'
  apiBaseUrl: string
  nickname: string
  userId: string
  expiresIn: number
  loginCodeGenerated: boolean
}

type AgentOwnerWsConnectResult = {
  status: 'connected' | 'timeout' | 'failed'
  ownerId?: string
  connId?: string
  llm?: {
    protocol: LLMAdvisorConfig['protocol']
    model: string
    baseUrl: string
  }
  events: string[]
}

type RunOnceResult = {
  status: 'connected' | 'action_sent' | 'action_result' | 'closed' | 'timeout' | 'failed'
  mode?: string
  requestId?: string
  action?: AdvisorDecisionResult
  events: string[]
}

type StatusResult = {
  configured: {
    apiBaseUrl: boolean
    agentUrl: boolean
    pat: boolean
    strategy: StrategyName
    persona?: AgentPersona
    autosubmit: boolean
    advisor: AdvisorEngine
    llmAdvisor: {
      runnable: boolean
      provider: LLMAdvisorConfig['provider']
      protocol: LLMAdvisorConfig['protocol']
      baseUrl: boolean
      apiKey: boolean
      model: string
      timeoutMs: number
    }
  }
  warnings: string[]
  llmRuntime: {
    sessionFound: boolean
    total: number
    llmUsed: number
    fallback: number
    timeoutFallback: number
    timeoutStreak: number
    circuitOpen: boolean
    circuitOpenForMs: number
    lastLatencyMs?: number
    lastDecisionAt?: string
    lastFallbackReason?: string
  }
  /** Long-lived /agent activity in this process. */
  ownerWsActivity: {
    sessionFound: boolean
    socketOpen: boolean
    readyState?: number
    connId?: string
    ownerId?: string
    inboundTail: string[]
    inboundCounts: Record<string, number>
  }
}

const LLM_DEADLINE_MIN_MS = 1_500
const LLM_TIMEOUT_STREAK_FOR_CIRCUIT = 3
const LLM_CIRCUIT_OPEN_MS = 30_000

type BootstrapRoomInput = {
  name?: string
  maxSeats?: number
  smallBlind?: number
  bigBlind?: number
  minBuyIn?: number
  maxBuyIn?: number
}

type BootstrapConfig = {
  apiBaseUrl?: string
  publicBaseUrl?: string
  nickname?: string
  room: BootstrapRoomInput
  buyIn?: number
  preferredSeat?: number
  agentLabel?: string
  /** X-Hiland-Agent-Name when bootstrapping triggers connectOnce */
  wsAgentDisplayName: string
  strategy: StrategyName
  persona?: AgentPersona
  autosubmit: boolean
  advisor: AdvisorEngine
  llm: LLMAdvisorConfig
  timeoutMs: number
  connectOnce: boolean
  includeSensitiveDetails: boolean
  createMobileEntry: boolean
}

type BootstrapAgentRoomApiResponse = {
  type: 'agent.bootstrap'
  auth: {
    accessToken: string
    userId: string
    nickname: string
    chips: number
    expiresIn: number
  }
  room: {
    id: string
    name: string
    maxSeats: number
    smallBlind: number
    bigBlind: number
    minBuyIn: number
    maxBuyIn: number
    playerCount: number
  }
  seat: { seatPos: number; stack: number; buyIn: number }
  agent: {
    agentUrl: string
    pat: string
    agentTokenId: string
    agentBindExpiresAt: string
  }
  links: { entryUrl: string }
}

type AgentConnectionsByPATApiResponse = {
  connected: number
  agents: Array<{
    connId: string
    ownerId?: string
    agentVersion?: string
    connectedAt?: string
    lastPingAt?: string
  }>
}

type MobileGrantApiResponse = {
  grant: string
  expiresAt: string
  entryUrl: string
  ttlSeconds: number
}

type BootstrapToolResult = {
  status: 'created'
  apiBaseUrl: string
  publicBaseUrl?: string
  auth: {
    userId: string
    nickname: string
    chips: number
    expiresIn: number
    accessTokenGenerated: boolean
  }
  room: BootstrapAgentRoomApiResponse['room']
  seat: BootstrapAgentRoomApiResponse['seat']
  agent: {
    agentUrl: string
    agentTokenId: string
    patGenerated: boolean
    agentBindExpiresAt: string
  }
  links: {
    entryUrlGenerated: boolean
    entryUrlRedacted?: string
    mobileEntryUrlGenerated: boolean
    mobileEntryUrlRedacted?: string
  }
  runOnce?: RunOnceResult
  /** Sensitive credentials are machine-readable for follow-up tool calls; never print them in chat. */
  sensitive?: {
    accessToken: string
    entryUrl: string
    mobileEntryUrl?: string
    mobileGrant?: string
    agentUrl: string
    pat: string
  }
}

type BindWebSeatResult = {
  status: 'ready' | 'run_once'
  configured: {
    agentUrl: boolean
    pat: boolean
    strategy: StrategyName
    persona?: AgentPersona
    autosubmit: boolean
    advisor: AdvisorEngine
  }
  warnings: string[]
  runOnce?: RunOnceResult
}

const BootstrapRoomToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    apiBaseUrl: {
      type: 'string',
      description:
        'Optional REST API base URL, e.g. https://hiland.example.com. Defaults to plugin config, HILAND_API_BASE_URL, or derived from agentUrl.',
    },
    publicBaseUrl: {
      type: 'string',
      description:
        'Optional public web origin used in the clickable entry link. Defaults to apiBaseUrl.',
    },
    nickname: {
      type: 'string',
      description: 'Optional guest nickname. Defaults to OpenClaw user display name when available.',
    },
    room: {
      type: 'object',
      description:
        'Optional partial room config: name, maxSeats, smallBlind, bigBlind, minBuyIn, maxBuyIn. Server fills sensible defaults.',
    },
    roomName: { type: 'string', description: 'Optional shorthand for room.name.' },
    maxSeats: { type: 'number', minimum: 2, maximum: 10 },
    smallBlind: { type: 'number', minimum: 1 },
    bigBlind: { type: 'number', minimum: 1 },
    minBuyIn: { type: 'number', minimum: 1 },
    maxBuyIn: { type: 'number', minimum: 1 },
    buyIn: { type: 'number', minimum: 1, description: 'Optional buy-in. Server defaults when omitted.' },
    preferredSeat: { type: 'number', minimum: 0, description: 'Optional preferred seat position.' },
    agentLabel: { type: 'string', description: 'Optional label for the generated PAT.' },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override for connectOnce.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine for connectOnce. Defaults to llm and requires runnable LLM config.',
    },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
    autosubmit: {
      type: 'boolean',
      description: 'Safety default false. Used only when connectOnce=true.',
    },
    connectOnce: {
      type: 'boolean',
      description:
        'When true, immediately connect to /agent and run once after bootstrap. Defaults false.',
    },
    includeSensitiveDetails: {
      type: 'boolean',
      description:
        'When true, returns generated secrets only in machine-readable details for follow-up tools; text output stays redacted. Defaults true.',
    },
    createMobileEntry: {
      type: 'boolean',
      description:
        'When true (default), creates a one-time mobile login entry link for cross-device flow after bootstrap.',
    },
    timeoutMs: {
      type: 'number',
      minimum: 1000,
      description: 'HTTP request timeout, and connectOnce run timeout when enabled. Defaults to 15000.',
    },
  },
} as const

const BindWebSeatToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    credentials: {
      type: 'object',
      description:
        'Optional JSON copied from the web client (e.g. agentUrl). PAT must be set via HILAND_PAT in the environment.',
    },
    agentUrl: {
      type: 'string',
      description: 'Agent WebSocket URL from the web client, e.g. wss://example.com/agent.',
    },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override. Defaults to plugin config or balanced.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine when connect=true. Defaults to llm and requires runnable LLM config.',
    },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
    autosubmit: {
      type: 'boolean',
      description: 'Safety default false unless plugin config/env explicitly enables it.',
    },
    connect: {
      type: 'boolean',
      description:
        'When true, connect and run once immediately. Defaults false.',
    },
    timeoutMs: {
      type: 'number',
      minimum: 1000,
      description: 'Maximum connect/run timeout when connect=true. Defaults to 30000.',
    },
  },
} as const

const RunOnceToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    agentUrl: {
      type: 'string',
      description: 'Optional Agent WebSocket URL override. Defaults to plugin config or HILAND_AGENT_URL.',
    },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override. Defaults to plugin config or balanced.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine. Defaults to llm and requires runnable LLM config.',
    },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
    autosubmit: {
      type: 'boolean',
      description: 'When true, submit only in full_auto mode. Defaults false unless plugin config/env explicitly enables it.',
    },
    timeoutMs: {
      type: 'number',
      minimum: 1000,
      description: 'Maximum time to stay connected waiting for one decision_request. Defaults to 30000.',
    },
  },
} as const

const StatusToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {},
} as const

const LoginCodeToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    apiBaseUrl: { type: 'string' },
    nickname: { type: 'string', description: 'Optional nickname. Defaults to OpenClaw display name.' },
    publicBaseUrl: { type: 'string' },
    timeoutMs: { type: 'number', minimum: 1000 },
  },
} as const

const AgentOwnerWsConnectToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    apiBaseUrl: { type: 'string' },
    agentUrl: { type: 'string' },
    timeoutMs: {
      type: 'number',
      minimum: 0,
      description: 'How long to keep this long connection alive. 0 means keep alive until explicitly disconnected/restarted.',
    },
  },
} as const

type AgentOwnerWsSession = {
  ws: WebSocket
  pingTimer: ReturnType<typeof setInterval>
  autoCloseTimer?: ReturnType<typeof setTimeout>
  connId?: string
  ownerId?: string
  handActive: boolean
  strategy: StrategyName
  persona?: AgentPersona
  advisor: AdvisorEngine
  effectiveAdvisor: AdvisorEngine
  advisorFallbackReason?: string
  autosubmit: boolean
  llm: LLMAdvisorConfig
  llmModel: string
  supportedLLMModels: string[]
  llmModelsEndpointReady: boolean
  llmModelsEndpointReason?: string
  lastGameState?: MsgGameState
  /** Ring buffer: recent inbound frames (hello / game_state / decision_request / …) */
  inboundTail: string[]
  inboundCounts: Record<string, number>
  llmHealth: {
    total: number
    llmUsed: number
    fallback: number
    timeoutFallback: number
    timeoutStreak: number
    circuitOpenUntilMs: number
    lastLatencyMs?: number
    lastDecisionAt?: string
    lastFallbackReason?: string
  }
}

const agentOwnerWsSessions = new Map<string, AgentOwnerWsSession>()
const OWNER_WS_INBOUND_TAIL_MAX = 48

function agentOwnerSessionKey(agentWsBase: string, pat: string): string {
  const u = new URL(agentWsBase)
  u.search = ''
  u.hash = ''
  return `${u.origin}${u.pathname}::${pat}`
}

function maybeGetOwnerSession(agentUrl: string | undefined, pat: string | undefined): AgentOwnerWsSession | undefined {
  if (!agentUrl || !pat) return undefined
  const base = agentWsURLFrom(agentUrl)
  if (!base) return undefined
  return agentOwnerWsSessions.get(agentOwnerSessionKey(base, pat))
}

function summarizeAgentInboundMessage(m: Record<string, unknown>): string {
  const t = m?.type
  if (t === 'pong') return 'pong'
  if (t === 'hello') {
    const oid = m.ownerId
    const cid = m.connId
    return `hello owner=${oid} conn=${cid}`
  }
  if (t === 'game_state') {
    const handId = m.handId
    const seq = m.stateSeq
    const ao = m.actionOn
    return `game_state hand=${handId} seq=${seq} actionOn=${ao}`
  }
  if (t === 'decision_request') {
    const rid = m.requestId
    const mode = m.mode
    return `decision_request id=${rid} mode=${mode}`
  }
  if (t === 'action_result') return `action_result req=${m.requestId} status=${m.status} kind=${m.kind}`
  if (t === 'error') return `error code=${m.code}`
  if (t === 'mode_changed') return `mode_changed mode=${m.mode}`
  return `type=${String(t)}`
}

function appendOwnerWsInbound(session: AgentOwnerWsSession, msgType: string, line: string) {
  session.inboundCounts[msgType] = (session.inboundCounts[msgType] ?? 0) + 1
  session.inboundTail.push(`${new Date().toISOString()} ${line}`)
  while (session.inboundTail.length > OWNER_WS_INBOUND_TAIL_MAX) {
    session.inboundTail.shift()
  }
}

function listAdvertisedLLMModels(currentModel: string): string[] {
  const out = new Set<string>()
  if (currentModel.trim()) out.add(currentModel.trim())
  const raw = process.env.HILAND_LLM_MODELS
  if (raw && raw.trim()) {
    for (const item of raw.split(',')) {
      const v = item.trim()
      if (v) out.add(v)
    }
  }
  return [...out].sort((a, b) => a.localeCompare(b))
}

/** After hello: refresh from GET {llmBaseUrl}/models (Bearer api key), filter non-decision models, merge env + current model. */
async function refreshSessionSupportedModelsFromProvider(session: AgentOwnerWsSession): Promise<void> {
  const llm = session.llm
  const fallback = listAdvertisedLLMModels(session.llmModel)
  if (!llm.apiKey?.trim() || !llm.baseUrl?.trim()) {
    session.supportedLLMModels = fallback
    session.llmModelsEndpointReady = false
    session.llmModelsEndpointReason = 'llm_models_check_skipped_missing_config'
    return
  }
  const cap = Math.min(Math.max(llm.timeoutMs, 3000), 12_000)
  try {
    const fetched = await fetchDecisionSuitableModelIds(llm.baseUrl.trim(), llm.apiKey.trim(), cap)
    if (!fetched.length) {
      session.supportedLLMModels = fallback
      session.llmModelsEndpointReady = false
      session.llmModelsEndpointReason = 'llm_models_endpoint_empty'
      return
    }
    const merged = new Set<string>(fetched.length ? fetched : fallback)
    for (const m of fallback) merged.add(m)
    session.supportedLLMModels = [...merged].sort((a, b) => a.localeCompare(b))
    session.llmModelsEndpointReady = true
    session.llmModelsEndpointReason = undefined
  } catch {
    session.supportedLLMModels = fallback
    session.llmModelsEndpointReady = false
    session.llmModelsEndpointReason = 'llm_models_endpoint_unavailable'
  }
}

function ownerConfigStateFromSession(session: AgentOwnerWsSession) {
  return {
    strategy: session.strategy,
    persona: session.persona,
    advisor: session.advisor,
    effectiveAdvisor: session.effectiveAdvisor,
    advisorFallbackReason: session.advisorFallbackReason,
    autosubmit: session.autosubmit,
    llmModel: session.llmModel,
    supportedLlmModels: session.supportedLLMModels,
    llmHealth: {
      total: session.llmHealth.total,
      llmUsed: session.llmHealth.llmUsed,
      fallback: session.llmHealth.fallback,
      timeoutFallback: session.llmHealth.timeoutFallback,
      timeoutStreak: session.llmHealth.timeoutStreak,
      circuitOpen: session.llmHealth.circuitOpenUntilMs > Date.now(),
      circuitOpenForMs: Math.max(0, session.llmHealth.circuitOpenUntilMs - Date.now()),
      lastLatencyMs: session.llmHealth.lastLatencyMs,
      lastDecisionAt: session.llmHealth.lastDecisionAt,
      lastFallbackReason: session.llmHealth.lastFallbackReason,
    },
  }
}

function trySendOwnerConfigReport(session: AgentOwnerWsSession): void {
  if (session.ws.readyState !== WebSocket.OPEN) return
  session.ws.send(
    JSON.stringify({
      type: 'config_report',
      config: ownerConfigStateFromSession(session),
    }),
  )
}

async function handleOwnerConfigApplyMessage(session: AgentOwnerWsSession, msg: Record<string, unknown>): Promise<void> {
  const requestID = typeof msg.requestId === 'string' ? msg.requestId : ''
  const patch = asRecord(msg.patch)
  let ok = true
  let err = ''

  const patchTouchesPreGameOnly =
    patch.strategy !== undefined || patch.persona !== undefined || patch.llmModel !== undefined
  if (patchTouchesPreGameOnly && session.handActive) {
    ok = false
    err = 'strategy/persona/llmModel can only be changed before a hand starts'
  }
  if (ok && patch.strategy !== undefined) {
    const v = normalizeStrategy(readOptionalString(patch, 'strategy'))
    session.strategy = v
  }
  if (ok && patch.persona !== undefined) {
    session.persona = normalizePersona(readOptionalString(patch, 'persona'))
  }
  if (ok && patch.advisor !== undefined) {
    session.advisor = resolveAdvisorEngine(readOptionalString(patch, 'advisor'))
    session.effectiveAdvisor = session.advisor
    session.advisorFallbackReason = undefined
    if (session.advisor === 'llm') {
      session.llmModelsEndpointReady = false
      session.llmModelsEndpointReason = 'llm_models_check_pending'
      void refreshSessionSupportedModelsFromProvider(session).then(() => {
        trySendOwnerConfigReport(session)
      })
    }
  }
  if (ok && patch.autosubmit !== undefined) {
    const raw = patch.autosubmit
    if (typeof raw === 'boolean') {
      session.autosubmit = raw
    } else {
      ok = false
      err = 'autosubmit must be boolean'
    }
  }
  if (ok && patch.llmModel !== undefined) {
    const model = readOptionalString(patch, 'llmModel')
    if (!model) {
      ok = false
      err = 'llmModel must be non-empty string'
    } else {
      session.llmModel = model
      session.llm.model = model
      if (!session.supportedLLMModels.includes(model)) session.supportedLLMModels.push(model)
    }
  }
  if (ok && patch.resetLlmHealth !== undefined) {
    const raw = patch.resetLlmHealth
    if (raw === true) {
      session.llmHealth.total = 0
      session.llmHealth.llmUsed = 0
      session.llmHealth.fallback = 0
      session.llmHealth.timeoutFallback = 0
      session.llmHealth.timeoutStreak = 0
      session.llmHealth.circuitOpenUntilMs = 0
      session.llmHealth.lastLatencyMs = undefined
      session.llmHealth.lastDecisionAt = undefined
      session.llmHealth.lastFallbackReason = undefined
    } else if (raw !== false) {
      ok = false
      err = 'resetLlmHealth must be boolean'
    }
  }
  if (session.ws.readyState !== WebSocket.OPEN) return
  session.ws.send(
    JSON.stringify({
      type: 'config_ack',
      requestId: requestID,
      ok,
      ...(ok ? {} : { error: err || 'invalid config patch' }),
      config: ownerConfigStateFromSession(session),
    }),
  )
}

function isSubmitCapableMode(mode: unknown): mode is MsgDecisionRequest['mode'] {
  // Server currently accepts submit only in full_auto.
  return mode === 'full_auto'
}

function shouldAutoDowngradeAdvisorOnFallback(reason: string | undefined): boolean {
  const r = (reason ?? '').trim().toLowerCase()
  if (!r) return false
  // These guards are transient and should not force sticky baseline mode.
  if (r === 'llm_skipped_tight_deadline') return false
  if (r.startsWith('llm_circuit_open_')) return false
  return r.startsWith('llm_')
}

async function handleOwnerDecisionRequestMessage(session: AgentOwnerWsSession, msg: Record<string, unknown>): Promise<void> {
  const request = msg as unknown as MsgDecisionRequest
  const state = session.lastGameState
  if (!state) {
    appendOwnerWsInbound(session, 'decision_request', `decision_request ${request.requestId ?? 'unknown'} ignored: missing game_state`)
    return
  }

  const legalActions = request.legalActions ?? state.legalActions ?? []
  const persona = session.persona
  const personaHandIndex = persona === 'learning' ? observePersonaHand(state.roomId, state.handId) : undefined
  const nemesisSeat = persona ? pickNemesisSeat(state) : null
  const startedAt = Date.now()
  const decisionWindowMs = Number.isFinite(request.decisionWindowMs) ? Math.max(0, Number(request.decisionWindowMs)) : 0
  const circuitOpen = session.llmHealth.circuitOpenUntilMs > startedAt
  const shouldForceBaselineByDeadline =
    session.advisor === 'llm' && decisionWindowMs > 0 && decisionWindowMs <= LLM_DEADLINE_MIN_MS
  const shouldForceBaselineByCircuit = session.advisor === 'llm' && circuitOpen
  const shouldForceBaselineByModelsEndpoint = session.advisor === 'llm' && !session.llmModelsEndpointReady
  const decision =
    shouldForceBaselineByDeadline || shouldForceBaselineByCircuit || shouldForceBaselineByModelsEndpoint
      ? {
          ...(await decideWithAdvisor({
            state,
            request,
            legalActions,
            strategy: session.strategy,
            advisor: 'baseline',
            llm: session.llm,
            persona,
            personaHandIndex,
            nemesisSeat,
          })),
          source: 'fallback' as const,
          fallbackReason: shouldForceBaselineByDeadline
            ? 'llm_skipped_tight_deadline'
            : shouldForceBaselineByCircuit
              ? `llm_circuit_open_${Math.max(0, session.llmHealth.circuitOpenUntilMs - startedAt)}ms`
              : (session.llmModelsEndpointReason ?? 'llm_models_endpoint_unavailable'),
        }
      : await decideWithAdvisor({
          state,
          request,
          legalActions,
          strategy: session.strategy,
          advisor: session.advisor,
          llm: session.llm,
          persona,
          personaHandIndex,
          nemesisSeat,
        })
  const latencyMs = Math.max(1, Date.now() - startedAt)
  if (
    session.advisor === 'llm' &&
    decision.source === 'fallback' &&
    shouldAutoDowngradeAdvisorOnFallback(decision.fallbackReason)
  ) {
    session.advisor = 'baseline'
  }
  if (session.advisor === 'baseline') {
    session.effectiveAdvisor = 'baseline'
    session.advisorFallbackReason = decision.source === 'fallback' ? decision.fallbackReason : undefined
  } else if (decision.source === 'llm') {
    session.effectiveAdvisor = 'llm'
    session.advisorFallbackReason = undefined
  } else {
    session.effectiveAdvisor = 'baseline'
    session.advisorFallbackReason = decision.fallbackReason ?? 'llm_fallback'
  }
  session.llmHealth.total += 1
  session.llmHealth.lastLatencyMs = latencyMs
  session.llmHealth.lastDecisionAt = new Date().toISOString()
  session.llmHealth.lastFallbackReason = decision.fallbackReason
  if (decision.source === 'llm') {
    session.llmHealth.llmUsed += 1
    session.llmHealth.timeoutStreak = 0
  } else if (decision.source === 'fallback') {
    session.llmHealth.fallback += 1
    const reason = (decision.fallbackReason ?? '').toLowerCase()
    if (/timeout|abort/.test(reason)) {
      session.llmHealth.timeoutFallback += 1
      session.llmHealth.timeoutStreak += 1
      if (session.llmHealth.timeoutStreak >= LLM_TIMEOUT_STREAK_FOR_CIRCUIT) {
        session.llmHealth.circuitOpenUntilMs = Date.now() + LLM_CIRCUIT_OPEN_MS
      }
    } else {
      session.llmHealth.timeoutStreak = 0
    }
  } else {
    session.llmHealth.timeoutStreak = 0
  }
  const kind: 'submit' | 'suggestion' =
    decision.kind ??
    (session.autosubmit && isSubmitCapableMode(request.mode) ? 'submit' : 'suggestion')
  const action = {
    type: 'action' as const,
    requestId: request.requestId,
    stateSeq: request.stateSeq ?? state.stateSeq,
    action: decision.action,
    amount: decision.amount,
    kind,
    source: decision.source ?? 'baseline',
    confidence: decision.confidence,
    rationale: decision.rationale,
  }
  if (session.ws.readyState !== WebSocket.OPEN) {
    appendOwnerWsInbound(session, 'action_sent', `action skipped req=${request.requestId}: socket not open`)
    return
  }
  session.ws.send(JSON.stringify(action))
  // Push runtime advisor state to web owner promptly after each decision.
  trySendOwnerConfigReport(session)
  appendOwnerWsInbound(
    session,
    'action_sent',
    `action_sent req=${request.requestId} kind=${kind} action=${decision.action} source=${decision.source ?? 'baseline'} latencyMs=${latencyMs}`,
  )
}
let cachedFingerprint: string | undefined

export default definePluginEntry({
  id: 'hiland-poker-openclaw-agent',
  name: 'Hiland Poker OpenClaw Agent',
  description:
    'OpenClaw plugin that connects an OpenClaw Agent to a Hiland Poker seat through the Hiland Agent WebSocket protocol.',
  register(api) {
    const pluginConfig = resolvePluginConfig(api.pluginConfig)

    api.registerTool({
      name: 'hiland_poker_agent_status',
      label: 'Hiland Poker Agent Status',
      description:
        'Check whether Hiland Poker Agent plugin configuration is present without revealing secrets. ownerWsActivity is always queried from server-side authority.',
      parameters: StatusToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const config = resolveConnectionConfig(pluginConfig, params)
        const apiBaseUrl = resolveApiBaseUrl(pluginConfig, params)
        const details: StatusResult = {
          configured: {
            apiBaseUrl: Boolean(apiBaseUrl),
            agentUrl: Boolean(config.agentUrl),
            pat: Boolean(config.pat),
            strategy: config.strategy,
            persona: config.persona,
            autosubmit: config.autosubmit,
            advisor: config.advisor,
            llmAdvisor: formatLLMAdvisorStatus(config.llm),
          },
          warnings: [...buildApiWarnings(apiBaseUrl), ...buildConfigWarnings(config)],
          llmRuntime: {
            sessionFound: false,
            total: 0,
            llmUsed: 0,
            fallback: 0,
            timeoutFallback: 0,
            timeoutStreak: 0,
            circuitOpen: false,
            circuitOpenForMs: 0,
          },
          ownerWsActivity: {
            sessionFound: false,
            socketOpen: false,
            inboundTail: [],
            inboundCounts: {},
          },
        }
        const localSession = maybeGetOwnerSession(config.agentUrl, config.pat)
        if (localSession) {
          const now = Date.now()
          const circuitFor = Math.max(0, localSession.llmHealth.circuitOpenUntilMs - now)
          details.llmRuntime = {
            sessionFound: true,
            total: localSession.llmHealth.total,
            llmUsed: localSession.llmHealth.llmUsed,
            fallback: localSession.llmHealth.fallback,
            timeoutFallback: localSession.llmHealth.timeoutFallback,
            timeoutStreak: localSession.llmHealth.timeoutStreak,
            circuitOpen: circuitFor > 0,
            circuitOpenForMs: circuitFor,
            lastLatencyMs: localSession.llmHealth.lastLatencyMs,
            lastDecisionAt: localSession.llmHealth.lastDecisionAt,
            lastFallbackReason: localSession.llmHealth.lastFallbackReason,
          }
        }
        if (!apiBaseUrl || !config.pat) {
          details.warnings.push('ownerWsActivity(server): need apiBaseUrl and pat.')
        } else {
          try {
            const remote = await getJSONWithBearer<AgentConnectionsByPATApiResponse>(
              joinURL(apiBaseUrl, '/api/agent/connections/by-pat'),
              config.pat,
              3500,
            )
            const first = remote.agents[0]
            details.ownerWsActivity = {
              sessionFound: remote.connected > 0,
              socketOpen: remote.connected > 0,
              connId: first?.connId,
              ownerId: first?.ownerId,
              inboundTail:
                remote.connected > 0
                  ? [`${new Date().toISOString()} server: connected=${remote.connected}, connId=${first?.connId ?? 'unknown'}`]
                  : [],
              inboundCounts: remote.connected > 0 ? { server_presence: remote.connected } : {},
            }
          } catch (err) {
            details.warnings.push(`ownerWsActivity(server) failed: ${userSafeError(err)}`)
          }
        }
        return createToolResult(formatStatus(details), details)
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_connect',
      label: 'Hiland Poker Agent Connect',
      description:
        'Establish a long-lived owner-bound Agent WebSocket on GET /agent (presence + optional table stream once seated).',
      parameters: AgentOwnerWsConnectToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const config = resolveConnectionConfig(pluginConfig, params)
        if (!config.pat) {
          throw new Error('HILAND_PAT is required')
        }
        const base =
          agentWsURLFrom(
            readOptionalString(params, 'agentUrl') ??
              config.agentUrl ??
              (resolveApiBaseUrl(pluginConfig, params)
                ? resolveApiBaseUrl(pluginConfig, params)!.replace(/^http/, 'ws') + '/agent'
                : undefined),
          )
        if (!base) throw new Error('agentUrl or apiBaseUrl is required')
        const timeoutRaw = readInteger(params, 'timeoutMs', 0)
        const timeoutMs = timeoutRaw <= 0 ? 0 : Math.max(timeoutRaw, 1_000)
        return connectAgentOwnerWs(base, config.pat, config.agentDisplayName, config, timeoutMs)
      },
    })
  },
})

async function bootstrapAgentRoom(config: RunnableBootstrapConfig): Promise<ToolResult<BootstrapToolResult>> {
  const apiURL = joinURL(config.apiBaseUrl, '/api/bootstrap/agent-room')
  const body = removeUndefined({
    nickname: config.nickname,
    room: removeUndefined(config.room),
    buyIn: config.buyIn,
    preferredSeat: config.preferredSeat,
    agentLabel: config.agentLabel,
    publicBaseUrl: config.publicBaseUrl ?? originFromBaseURL(config.apiBaseUrl),
  })

  const response = await postJSON<BootstrapAgentRoomApiResponse>(apiURL, body, config.timeoutMs)
  let mobileGrant: MobileGrantApiResponse | undefined
  if (config.createMobileEntry && response.auth.accessToken) {
    const mobileGrantURL = joinURL(config.apiBaseUrl, '/api/auth/mobile-grant')
    mobileGrant = await postJSONWithAuth<MobileGrantApiResponse>(
      mobileGrantURL,
      { publicBaseUrl: config.publicBaseUrl ?? originFromBaseURL(config.apiBaseUrl) },
      response.auth.accessToken,
      config.timeoutMs,
    )
  }
  const details: BootstrapToolResult = {
    status: 'created',
    apiBaseUrl: config.apiBaseUrl,
    publicBaseUrl: config.publicBaseUrl,
    auth: {
      userId: response.auth.userId,
      nickname: response.auth.nickname,
      chips: response.auth.chips,
      expiresIn: response.auth.expiresIn,
      accessTokenGenerated: Boolean(response.auth.accessToken),
    },
    room: response.room,
    seat: response.seat,
    agent: {
      agentUrl: response.agent.agentUrl,
      agentTokenId: response.agent.agentTokenId,
      patGenerated: Boolean(response.agent.pat),
      agentBindExpiresAt: response.agent.agentBindExpiresAt,
    },
    links: {
      entryUrlGenerated: Boolean(response.links.entryUrl),
      entryUrlRedacted: response.links.entryUrl ? redactURLSecrets(response.links.entryUrl) : undefined,
      mobileEntryUrlGenerated: Boolean(mobileGrant?.entryUrl),
      mobileEntryUrlRedacted: mobileGrant?.entryUrl ? redactURLSecrets(mobileGrant.entryUrl) : undefined,
    },
  }

  if (config.includeSensitiveDetails) {
    details.sensitive = {
      accessToken: response.auth.accessToken,
      entryUrl: response.links.entryUrl,
      mobileEntryUrl: mobileGrant?.entryUrl,
      mobileGrant: mobileGrant?.grant,
      agentUrl: response.agent.agentUrl,
      pat: response.agent.pat,
    }
  }

  if (config.connectOnce) {
    assertRunnableLLMAdvisorForOperation(config.advisor, config.llm, 'hiland_poker_agent_bootstrap_room')
    const run = await runOnce({
      agentUrl: response.agent.agentUrl,
      pat: response.agent.pat,
      agentDisplayName: config.wsAgentDisplayName,
      strategy: config.strategy,
      persona: config.persona,
      autosubmit: config.autosubmit,
      advisor: config.advisor,
      llm: config.llm,
      timeoutMs: config.timeoutMs,
    })
    details.runOnce = run.details
  }

  return createToolResult(formatBootstrap(details), details)
}

/** Normalize HTTP(S) or WS(S) API/agent base to the owner-bound Agent WebSocket URL (GET /agent). */
function agentWsURLFrom(value: string | undefined): string | undefined {
  if (!value) return undefined
  try {
    const u = new URL(value)
    if (u.protocol === 'http:' || u.protocol === 'https:') {
      u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:'
    }
    u.pathname = '/agent'
    u.search = ''
    u.hash = ''
    return u.toString()
  } catch {
    return undefined
  }
}

async function runOnce(config: RunnableConnectionConfig): Promise<ToolResult<RunOnceResult>> {
  const events: string[] = []
  const timeoutMs = config.timeoutMs
  let settled = false
  let lastAction: AdvisorDecisionResult | undefined
  let lastRequest: MsgDecisionRequest | undefined

  let settleRun: ((result: RunOnceResult) => void) | undefined
  let timeout: ReturnType<typeof setTimeout> | undefined
  const settle = (result: RunOnceResult, agent?: AgentClient) => {
    if (settled) return
    settled = true
    if (timeout) clearTimeout(timeout)
    settleRun?.(result)
    agent?.close()
  }

  const agent = new AgentClient({
    url: config.agentUrl,
    pat: config.pat,
    agentDisplayName: config.agentDisplayName,
    autosubmit: config.autosubmit,
    decide: async ({ state, request, legalActions }) => {
      lastRequest = request
      const persona = config.persona
      const personaHandIndex =
        persona === 'learning' ? observePersonaHand(state.roomId, state.handId) : undefined
      const nemesisSeat = persona ? pickNemesisSeat(state) : null
      const decision = await decideWithAdvisor({
        state,
        request,
        legalActions,
        strategy: config.strategy,
        advisor: config.advisor,
        llm: config.llm,
        persona,
        personaHandIndex,
        nemesisSeat,
      })
      lastAction = decision
      return decision
    },
    onEvent: (event) => {
      events.push(formatEvent(event))
      if (event.type === 'action_result') {
        settle(
          {
            status: 'action_result',
            mode: lastRequest?.mode,
            requestId: event.message.requestId,
            action: lastAction,
            events,
          },
          agent,
        )
      }
      if (event.type === 'closed') {
        settle({ status: lastAction ? 'action_sent' : 'closed', mode: lastRequest?.mode, requestId: lastRequest?.requestId, action: lastAction, events })
      }
    },
  } as ConstructorParameters<typeof AgentClient>[0])

  try {
    const resultPromise = new Promise<RunOnceResult>((resolve) => {
      settleRun = resolve
      timeout = setTimeout(() => {
        settle({ status: 'timeout', events }, agent)
      }, timeoutMs)
    })
    await agent.start()
    const result = await resultPromise
    return createToolResult(formatRunOnce(result), result)
  } catch (error) {
    agent.close()
    const result: RunOnceResult = {
      status: 'failed',
      events: [...events, userSafeError(error)],
    }
    return createToolResult(formatRunOnce(result), result)
  }
}

async function connectAgentOwnerWs(
  baseURL: string,
  pat: string,
  agentDisplayName: string,
  config: ResolvedConnectionConfig,
  timeoutMs: number,
): Promise<ToolResult<AgentOwnerWsConnectResult>> {
  const llm = config.llm
  const llmDetails = {
    protocol: llm.protocol,
    model: llm.model,
    baseUrl: redactURLSecrets(llm.baseUrl),
  }
  const wsURL = new URL(baseURL)
  wsURL.searchParams.set('token', pat)
  const sessionKey = agentOwnerSessionKey(baseURL, pat)
  const existing = agentOwnerWsSessions.get(sessionKey)
  if (existing && existing.ws.readyState === WebSocket.OPEN) {
    const details: AgentOwnerWsConnectResult = {
      status: 'connected',
      connId: existing.connId,
      ownerId: existing.ownerId,
      llm: llmDetails,
      events: ['already connected'],
    }
    return createToolResult(formatAgentOwnerWsResult(details), details)
  }
  if (existing) {
    try {
      existing.ws.terminate()
    } catch {}
    clearInterval(existing.pingTimer)
    if (existing.autoCloseTimer) clearTimeout(existing.autoCloseTimer)
    agentOwnerWsSessions.delete(sessionKey)
  }

  const fingerprint = getOrCreateAgentFingerprint()
  const events: string[] = []
  return new Promise((resolve) => {
    const ws = new WebSocket(wsURL.toString(), {
      headers: {
        'X-Hiland-Agent-Name': agentDisplayName,
        'X-Hiland-Agent-Version': PLUGIN_VERSION,
        'X-Hiland-Agent-Fingerprint': fingerprint,
      },
    })
    const session: AgentOwnerWsSession = {
      ws,
      handActive: false,
      strategy: config.strategy,
      persona: config.persona,
      advisor: config.advisor,
      effectiveAdvisor: config.advisor,
      autosubmit: config.autosubmit,
      llm: config.llm,
      llmModel: llm.model,
      supportedLLMModels: listAdvertisedLLMModels(llm.model),
      llmModelsEndpointReady: config.advisor !== 'llm',
      inboundTail: [],
      inboundCounts: {},
      llmHealth: {
        total: 0,
        llmUsed: 0,
        fallback: 0,
        timeoutFallback: 0,
        timeoutStreak: 0,
        circuitOpenUntilMs: 0,
      },
      pingTimer: setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'ping', ts: Date.now() }))
        }
      }, 15_000),
    }
    agentOwnerWsSessions.set(sessionKey, session)
    let connId: string | undefined
    let ownerId: string | undefined
    let settled = false
    const settle = (result: AgentOwnerWsConnectResult) => {
      if (settled) return
      settled = true
      resolve(createToolResult(formatAgentOwnerWsResult(result), result))
    }
    const failAndCleanup = (result: AgentOwnerWsConnectResult) => {
      clearInterval(session.pingTimer)
      if (session.autoCloseTimer) clearTimeout(session.autoCloseTimer)
      agentOwnerWsSessions.delete(sessionKey)
      settle(result)
    }
    const connectWaitTimer = setTimeout(() => {
      events.push('connect handshake timeout')
      try {
        ws.close()
      } catch {}
      failAndCleanup({ status: 'failed', connId, ownerId, llm: llmDetails, events })
    }, 15_000)
    ws.on('open', () => {
      events.push('connected')
    })
    ws.on('message', (raw) => {
      try {
        const m = JSON.parse(String(raw)) as Record<string, unknown>
        if (m?.type === 'hello') {
          connId = m.connId as string | undefined
          ownerId = m.ownerId as string | undefined
          session.connId = connId
          session.ownerId = ownerId
          events.push(`hello owner=${ownerId} conn=${connId}`)
          appendOwnerWsInbound(session, 'hello', `hello owner=${ownerId} conn=${connId}`)
          trySendOwnerConfigReport(session)
          void refreshSessionSupportedModelsFromProvider(session)
            .then(() => {
              trySendOwnerConfigReport(session)
            })
            .catch(() => {})
          clearTimeout(connectWaitTimer)
          if (timeoutMs > 0) {
            session.autoCloseTimer = setTimeout(() => {
              events.push('timeout reached, closing')
              try {
                ws.close()
              } catch {}
            }, timeoutMs)
          }
          settle({ status: 'connected', connId, ownerId, llm: llmDetails, events })
        } else {
          const ty = typeof m?.type === 'string' ? m.type : 'unknown'
          if (ty === 'game_state') {
            session.lastGameState = m as unknown as MsgGameState
            session.handActive = typeof m.handId === 'string' && m.handId.trim() !== ''
          } else if (ty === 'config_apply') {
            void handleOwnerConfigApplyMessage(session, m)
          } else if (ty === 'decision_request') {
            void handleOwnerDecisionRequestMessage(session, m).catch((err) => {
              appendOwnerWsInbound(session, 'decision_request', `decision error: ${userSafeError(err)}`)
            })
          }
          appendOwnerWsInbound(session, ty, summarizeAgentInboundMessage(m))
        }
      } catch {
        events.push('received non-json message')
        appendOwnerWsInbound(session, 'parse_error', 'non-json inbound frame')
      }
    })
    ws.on('error', (err) => {
      events.push(userSafeError(err))
      clearTimeout(connectWaitTimer)
      failAndCleanup({ status: 'failed', connId, ownerId, llm: llmDetails, events })
    })
    ws.on('close', () => {
      clearTimeout(connectWaitTimer)
      clearInterval(session.pingTimer)
      if (session.autoCloseTimer) clearTimeout(session.autoCloseTimer)
      agentOwnerWsSessions.delete(sessionKey)
      if (!settled) {
        settle({
          status: events.includes('timeout reached, closing') ? 'timeout' : 'failed',
          connId,
          ownerId,
          llm: llmDetails,
          events,
        })
      }
    })
  })
}

function getOrCreateAgentFingerprint(): string {
  if (cachedFingerprint) return cachedFingerprint
  const file = path.join(os.homedir(), '.hiland-poker', 'agent-fingerprint')
  try {
    if (fs.existsSync(file)) {
      const existing = fs.readFileSync(file, 'utf8').trim()
      if (existing) {
        cachedFingerprint = existing
        return existing
      }
    }
  } catch {}
  const created = randomUUID()
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, created, 'utf8')
  } catch {}
  cachedFingerprint = created
  return created
}

type ResolvedConnectionConfig = {
  agentUrl?: string
  pat?: string
  /** X-Hiland-Agent-Name for Hiland presence / device bindings */
  agentDisplayName: string
  strategy: StrategyName
  persona?: AgentPersona
  autosubmit: boolean
  timeoutMs: number
  advisor: AdvisorEngine
  llm: LLMAdvisorConfig
}

type RunnableConnectionConfig = ResolvedConnectionConfig & {
  agentUrl: string
  pat: string
}

type RunnableBootstrapConfig = BootstrapConfig & { apiBaseUrl: string }

function resolvePluginConfig(raw: Record<string, unknown> | undefined): PluginConfig {
  const config = raw ?? {}
  const strategy = readOptionalString(config, 'strategy')
  return {
    apiBaseUrl: readOptionalString(config, 'apiBaseUrl'),
    nickname: readOptionalString(config, 'nickname'),
    agentUrl: readOptionalString(config, 'agentUrl'),
    strategy: strategy ? normalizeStrategy(strategy) : undefined,
    persona: normalizePersona(readOptionalString(config, 'persona')),
    autosubmit: readOptionalBoolean(config, 'autosubmit'),
    advisor: resolveAdvisorEngine(readOptionalString(config, 'advisor')),
    llmProvider: readLLMProvider(config, 'llmProvider'),
    llmProtocol: readLLMProtocol(config, 'llmProtocol'),
    llmBaseUrl: readOptionalString(config, 'llmBaseUrl'),
    llmModel: readOptionalString(config, 'llmModel'),
    llmTimeoutMs: readOptionalInteger(config, 'llmTimeoutMs'),
    llmTemperature: readOptionalNumber(config, 'llmTemperature'),
    llmMaxTokens: readOptionalInteger(config, 'llmMaxTokens'),
    llmLanguage: readOptionalString(config, 'llmLanguage') === 'en' ? 'en' : readOptionalString(config, 'llmLanguage') === 'zh-CN' ? 'zh-CN' : undefined,
  }
}

function resolvePersonaFromInputs(pluginConfig: PluginConfig, params: Record<string, unknown>): AgentPersona | undefined {
  return (
    normalizePersona(readOptionalString(params, 'persona')) ??
    pluginConfig.persona ??
    normalizePersona(process.env.HILAND_AGENT_PERSONA)
  )
}

function detectOpenClawNickname(pluginConfig: PluginConfig): string | undefined {
  const fromConfig = pluginConfig.nickname
  if (fromConfig) return fromConfig
  const candidates = [
    process.env.OPENCLAW_USER_NICKNAME,
    process.env.OPENCLAW_USER_DISPLAY_NAME,
    process.env.OPENCLAW_USERNAME,
    process.env.USER,
  ]
  for (const c of candidates) {
    if (typeof c === 'string' && c.trim() !== '') return c.trim()
  }
  return undefined
}

function sanitizeWsAgentName(raw: string): string {
  const collapsed = raw.trim().replace(/\s+/g, ' ')
  if (!collapsed) return 'openclaw'
  return collapsed.length > 80 ? collapsed.slice(0, 80) : collapsed
}

/** Hiland WS header X-Hiland-Agent-Name (server trims; keep bounded). */
function hilandAgentNameHeader(pluginConfig: PluginConfig): string {
  return sanitizeWsAgentName(detectOpenClawNickname(pluginConfig) ?? 'openclaw')
}

function readHilandPatFromEnv(): string | undefined {
  const v = process.env.HILAND_PAT
  if (typeof v !== 'string') return undefined
  const t = v.trim()
  return t !== '' ? t : undefined
}

function resolveConnectionConfig(
  pluginConfig: PluginConfig,
  params: Record<string, unknown>,
): ResolvedConnectionConfig {
  return {
    agentUrl:
      readOptionalString(params, 'agentUrl') ?? pluginConfig.agentUrl ?? process.env.HILAND_AGENT_URL,
    pat: readHilandPatFromEnv(),
    agentDisplayName: hilandAgentNameHeader(pluginConfig),
    strategy: normalizeStrategy(
      readOptionalString(params, 'strategy') ?? pluginConfig.strategy ?? process.env.HILAND_AGENT_STRATEGY,
    ),
    persona: resolvePersonaFromInputs(pluginConfig, params),
    autosubmit: readBoolean(
      params,
      'autosubmit',
      pluginConfig.autosubmit ?? parseBoolean(process.env.HILAND_AGENT_AUTOSUBMIT, false),
    ),
    timeoutMs: Math.max(readInteger(params, 'timeoutMs', 30_000), 1_000),
    advisor: resolveAdvisorEngine(readOptionalString(params, 'advisor') ?? pluginConfig.advisor),
    llm: resolveLLMAdvisorConfig({ ...pluginConfig, ...params }),
  }
}

function resolveBootstrapConfig(pluginConfig: PluginConfig, params: Record<string, unknown>): BootstrapConfig {
  const apiBaseUrl = resolveApiBaseUrl(pluginConfig, params)
  const strategy = normalizeStrategy(
    readOptionalString(params, 'strategy') ?? pluginConfig.strategy ?? process.env.HILAND_AGENT_STRATEGY,
  )
  const agentLabelParam = readOptionalString(params, 'agentLabel')
  const wsAgentNick =
    agentLabelParam && agentLabelParam.trim() !== ''
      ? agentLabelParam
      : (detectOpenClawNickname(pluginConfig) ?? 'openclaw')
  return {
    apiBaseUrl,
    publicBaseUrl: readOptionalString(params, 'publicBaseUrl'),
    nickname: readOptionalString(params, 'nickname') ?? detectOpenClawNickname(pluginConfig),
    room: readBootstrapRoom(params),
    buyIn: readOptionalInteger(params, 'buyIn'),
    preferredSeat: readOptionalInteger(params, 'preferredSeat'),
    agentLabel: agentLabelParam,
    wsAgentDisplayName: sanitizeWsAgentName(wsAgentNick),
    strategy,
    persona: resolvePersonaFromInputs(pluginConfig, params),
    autosubmit: readBoolean(
      params,
      'autosubmit',
      pluginConfig.autosubmit ?? parseBoolean(process.env.HILAND_AGENT_AUTOSUBMIT, false),
    ),
    advisor: resolveAdvisorEngine(readOptionalString(params, 'advisor') ?? pluginConfig.advisor),
    llm: resolveLLMAdvisorConfig({ ...pluginConfig, ...params }),
    timeoutMs: Math.max(readInteger(params, 'timeoutMs', 15_000), 1_000),
    connectOnce: readBoolean(params, 'connectOnce', false),
    includeSensitiveDetails: readBoolean(params, 'includeSensitiveDetails', true),
    createMobileEntry: readBoolean(params, 'createMobileEntry', true),
  }
}

function resolveApiBaseUrl(pluginConfig: PluginConfig, params: Record<string, unknown>): string | undefined {
  const explicit = readOptionalString(params, 'apiBaseUrl') ?? pluginConfig.apiBaseUrl ?? process.env.HILAND_API_BASE_URL
  if (explicit) return normalizeHTTPBaseURL(explicit)
  const agentUrl = readOptionalString(params, 'agentUrl') ?? pluginConfig.agentUrl ?? process.env.HILAND_AGENT_URL
  return restBaseFromAgentURL(agentUrl)
}

function readBootstrapRoom(params: Record<string, unknown>): BootstrapRoomInput {
  const room = readObjectParam<Record<string, unknown>>(params, 'room', false) ?? {}
  return removeUndefined({
    name: readOptionalString(params, 'roomName') ?? readOptionalString(room, 'name'),
    maxSeats: readOptionalInteger(params, 'maxSeats') ?? readOptionalInteger(room, 'maxSeats'),
    smallBlind: readOptionalInteger(params, 'smallBlind') ?? readOptionalInteger(room, 'smallBlind'),
    bigBlind: readOptionalInteger(params, 'bigBlind') ?? readOptionalInteger(room, 'bigBlind'),
    minBuyIn: readOptionalInteger(params, 'minBuyIn') ?? readOptionalInteger(room, 'minBuyIn'),
    maxBuyIn: readOptionalInteger(params, 'maxBuyIn') ?? readOptionalInteger(room, 'maxBuyIn'),
  })
}

function mergeCredentialParams(params: Record<string, unknown>): Record<string, unknown> {
  const credentials = readObjectParam<Record<string, unknown>>(params, 'credentials', false)
  if (!credentials) return params
  // Top-level values win over JSON blob values.
  return { ...credentials, ...params }
}

function buildApiWarnings(apiBaseUrl?: string): string[] {
  const warnings: string[] = []
  if (!apiBaseUrl) warnings.push('HILAND_API_BASE_URL / apiBaseUrl is missing and could not be derived from agentUrl.')
  if (apiBaseUrl && !/^https?:\/\//.test(apiBaseUrl)) warnings.push('apiBaseUrl must start with http:// or https://.')
  return warnings
}

/** Shown when LLM config is incomplete so agents guide users without invoking OpenClaw `gateway config.patch` (often rejected for plugin paths). */
const LLM_CONFIG_REMEDIATION_HINT =
  'Remediation: set LLM API keys only via environment (e.g. OPENAI_API_KEY / ANTHROPIC_API_KEY / HILAND_LLM_API_KEY with matching base URL and model env vars). Non-secret options may use plugin Settings (llmBaseUrl, llmModel, llmProtocol, …) or tool parameters for llmBaseUrl / llmModel / llmProtocol. Do not use gateway config.patch on protected plugin paths.'

function formatLLMAdvisorMissingMessage(
  prefix: string,
  llm: LLMAdvisorConfig,
): string {
  const missing = listMissingLLMAdvisorRequirements(llm)
  const list = missing.length ? missing.join(', ') : 'unknown'
  return `${prefix} missing: ${list}. ${LLM_CONFIG_REMEDIATION_HINT}`
}

function buildConfigWarnings(config: ResolvedConnectionConfig): string[] {
  const warnings: string[] = []
  if (!config.agentUrl) warnings.push('HILAND_AGENT_URL / agentUrl is missing.')
  if (!config.pat) warnings.push('HILAND_PAT is missing (must be set in the process environment).')
  if (config.agentUrl && !/^wss?:\/\//.test(config.agentUrl)) {
    warnings.push('agentUrl must start with ws:// or wss://.')
  }
  if (config.advisor === 'llm' && !hasRunnableLLMAdvisor(config.llm)) {
    warnings.push(formatLLMAdvisorMissingMessage('LLM advisor is not runnable.', config.llm))
  }
  return warnings
}

function assertRunnableConfig(config: ResolvedConnectionConfig): asserts config is RunnableConnectionConfig {
  const warnings = buildConfigWarnings(config)
  if (warnings.length) {
    throw new Error(warnings.join(' '))
  }
}

function assertBootstrapConfig(config: BootstrapConfig): asserts config is RunnableBootstrapConfig {
  const warnings = buildApiWarnings(config.apiBaseUrl)
  if (warnings.length) throw new Error(warnings.join(' '))
}

function assertRunnableLLMAdvisorForOperation(
  advisor: AdvisorEngine,
  llm: LLMAdvisorConfig,
  operation: 'hiland_poker_agent_decide' | 'hiland_poker_agent_run_once' | 'hiland_poker_agent_bind_web_seat' | 'hiland_poker_agent_bootstrap_room',
): void {
  if (advisor !== 'llm') return
  if (hasRunnableLLMAdvisor(llm)) return
  throw new Error(
    formatLLMAdvisorMissingMessage(`${operation} requires runnable LLM advisor when advisor=llm;`, llm),
  )
}

async function decideWithAdvisor(options: {
  state: MsgGameState
  request?: MsgDecisionRequest
  legalActions: LegalAction[]
  strategy: StrategyName
  advisor: AdvisorEngine
  llm: LLMAdvisorConfig
  persona?: AgentPersona
  personaHandIndex?: number
  nemesisSeat?: number | null
}): Promise<AdvisorDecisionResult> {
  if (options.advisor === 'llm') {
    return decideWithLLMAdvisor({
      state: options.state,
      request: options.request,
      legalActions: options.legalActions,
      strategy: options.strategy,
      config: options.llm,
      persona: options.persona,
      personaHandIndex: options.personaHandIndex,
      nemesisSeat: options.nemesisSeat,
    })
  }

  return {
    ...decideWithBaselineStrategy({
      state: options.state,
      request: options.request,
      legalActions: options.legalActions,
      strategy: options.strategy,
      persona: options.persona,
      personaHandIndex: options.personaHandIndex,
      nemesisSeat: options.nemesisSeat ?? null,
    }),
    source: 'baseline',
  }
}

function resolveAdvisorEngine(value: unknown): AdvisorEngine {
  return value === 'baseline' ? 'baseline' : 'llm'
}

function readLLMProvider(params: Record<string, unknown>, key: string): LLMAdvisorConfig['provider'] | undefined {
  const value = readOptionalString(params, key)?.toLowerCase()
  if (value === 'anthropic' || value === 'anthropic-compatible') return 'anthropic'
  if (value === 'openai' || value === 'openai-compatible') return 'openai-compatible'
  return undefined
}

function readLLMProtocol(params: Record<string, unknown>, key: string): LLMAdvisorConfig['protocol'] | undefined {
  const value = readOptionalString(params, key)?.toLowerCase()
  if (value === 'responses' || value === 'response' || value === 'openai-responses' || value === 'openai_responses') return 'responses'
  if (value === 'messages' || value === 'message' || value === 'anthropic-messages' || value === 'anthropic_messages') return 'messages'
  if (
    value === 'chat-completions' ||
    value === 'chat_completions' ||
    value === 'chat-completion' ||
    value === 'chat_completion' ||
    value === 'openai-chat-completions' ||
    value === 'openai_chat_completions'
  ) {
    return 'chat-completions'
  }
  return undefined
}

function formatLLMAdvisorStatus(config: LLMAdvisorConfig): StatusResult['configured']['llmAdvisor'] {
  return {
    runnable: hasRunnableLLMAdvisor(config),
    provider: config.provider,
    protocol: config.protocol,
    baseUrl: Boolean(config.baseUrl),
    apiKey: Boolean(config.apiKey),
    model: config.model,
    timeoutMs: config.timeoutMs,
  }
}

function formatStatus(result: StatusResult): string {
  const lines = [
    'Hiland Poker Agent plugin status.',
    `apiBaseUrl: ${result.configured.apiBaseUrl ? 'configured' : 'missing'}`,
    `agentUrl: ${result.configured.agentUrl ? 'configured' : 'missing'}`,
    `pat: ${result.configured.pat ? 'configured' : 'missing'}`,
    `strategy: ${result.configured.strategy}`,
    `persona: ${result.configured.persona ?? 'unset'}`,
    `advisor: ${result.configured.advisor}`,
    `autosubmit: ${result.configured.autosubmit ? 'enabled' : 'disabled'}`,
    `llmAdvisor: ${result.configured.llmAdvisor.runnable ? 'runnable' : 'not runnable'} (protocol=${result.configured.llmAdvisor.protocol}, model=${result.configured.llmAdvisor.model})`,
  ]
  const act = result.ownerWsActivity
  const rt = result.llmRuntime
  lines.push(
    '',
    'llm runtime (this OpenClaw process):',
    `sessionFound: ${rt.sessionFound}`,
    `llmUsed/total: ${rt.llmUsed}/${rt.total}`,
    `fallback: ${rt.fallback} (timeout=${rt.timeoutFallback}, streak=${rt.timeoutStreak})`,
    `circuit: ${rt.circuitOpen ? `open (${rt.circuitOpenForMs}ms left)` : 'closed'}`,
  )
  if (rt.lastLatencyMs != null) lines.push(`lastLatencyMs: ${rt.lastLatencyMs}`)
  if (rt.lastDecisionAt) lines.push(`lastDecisionAt: ${rt.lastDecisionAt}`)
  if (rt.lastFallbackReason) lines.push(`lastFallbackReason: ${rt.lastFallbackReason}`)
  if (act) {
    lines.push(
      '',
      'long-lived /agent session (this OpenClaw process):',
      `sessionFound: ${act.sessionFound}`,
      `socketOpen: ${act.socketOpen}${act.readyState != null ? ` (readyState=${act.readyState})` : ''}`,
      act.connId ? `connId: ${act.connId}` : 'connId: (none yet)',
      act.ownerId ? `ownerId: ${act.ownerId}` : 'ownerId: (none yet)',
    )
    const entries = Object.entries(act.inboundCounts).filter(([, n]) => n > 0)
    if (entries.length) {
      lines.push('inboundCounts: ' + entries.map(([k, n]) => `${k}=${n}`).join(', '))
    } else {
      lines.push('inboundCounts: (none)')
    }
    if (act.inboundTail.length) {
      lines.push('inboundTail (oldest → newest):')
      for (const row of act.inboundTail) lines.push(`  ${row}`)
    } else {
      lines.push('inboundTail: (empty — no frames logged since connect in this process)')
    }
  }
  if (result.warnings.length) {
    lines.push('', 'warnings:')
    for (const warning of result.warnings) lines.push(`- ${warning}`)
  }
  return lines.join('\n')
}

function formatBootstrap(result: BootstrapToolResult): string {
  const lines = [
    'Hiland Poker Agent room bootstrapped.',
    `status: ${result.status}`,
    `room: ${result.room.name} (${result.room.id})`,
    `seat: ${result.seat.seatPos}, stack=${result.seat.stack}, buyIn=${result.seat.buyIn}`,
    `owner: ${result.auth.nickname} (${result.auth.userId})`,
    `agentUrl: ${result.agent.agentUrl || 'missing'}`,
    `agentTokenId: ${result.agent.agentTokenId}`,
    `entry link: ${result.links.entryUrlGenerated ? 'generated; auth is in URL fragment and is not printed' : 'missing'}`,
    `mobile entry link: ${result.links.mobileEntryUrlGenerated ? 'generated for phone sign-in; one-time and short-lived' : 'not generated'}`,
    `agent credentials: ${result.agent.patGenerated ? 'generated; secrets are not printed' : 'missing'}`,
    `agent bind expires: ${result.agent.agentBindExpiresAt}`,
  ]
  if (result.links.entryUrlRedacted) lines.push(`entry link redacted: ${result.links.entryUrlRedacted}`)
  if (result.links.mobileEntryUrlRedacted) lines.push(`mobile entry redacted: ${result.links.mobileEntryUrlRedacted}`)
  if (result.runOnce) {
    lines.push('', 'connectOnce result:')
    lines.push(indent(formatRunOnce(result.runOnce)))
  }
  return lines.join('\n')
}

function formatBindWebSeat(result: BindWebSeatResult): string {
  const lines = [
    'Hiland Poker web seat credentials accepted.',
    `status: ${result.status}`,
    `agentUrl: ${result.configured.agentUrl ? 'configured' : 'missing'}`,
    `pat: ${result.configured.pat ? 'configured' : 'missing'}`,
    `strategy: ${result.configured.strategy}`,
    `persona: ${result.configured.persona ?? 'unset'}`,
    `advisor: ${result.configured.advisor}`,
    `autosubmit: ${result.configured.autosubmit ? 'enabled' : 'disabled'}`,
  ]
  if (result.warnings.length) {
    lines.push('', 'warnings:')
    for (const warning of result.warnings) lines.push(`- ${warning}`)
  }
  if (result.runOnce) {
    lines.push('', 'runOnce:')
    lines.push(indent(formatRunOnce(result.runOnce)))
  }
  return lines.join('\n')
}

function formatRunOnce(result: RunOnceResult): string {
  const lines = ['Hiland Poker Agent run-once finished.', `status: ${result.status}`]
  if (result.mode) lines.push(`mode: ${result.mode}`)
  if (result.requestId) lines.push(`requestId: ${result.requestId}`)
  if (result.action) {
    lines.push(`action: ${result.action.action}`)
    if (result.action.amount !== undefined) lines.push(`amount: ${result.action.amount}`)
    if (result.action.kind) lines.push(`kind: ${result.action.kind}`)
    if (result.action.source) lines.push(`source: ${result.action.source}`)
    if (result.action.confidence !== undefined) lines.push(`confidence: ${result.action.confidence.toFixed(2)}`)
    if (result.action.rationale) lines.push(`rationale: ${result.action.rationale}`)
    if (result.action.fallbackReason) lines.push(`fallbackReason: ${result.action.fallbackReason}`)
  }
  if (result.events.length) {
    lines.push('', 'events:')
    for (const event of result.events) lines.push(`- ${event}`)
  }
  return lines.join('\n')
}

function formatAgentOwnerWsResult(result: AgentOwnerWsConnectResult): string {
  const lines = ['Hiland Poker Agent WebSocket session finished.', `status: ${result.status}`]
  if (result.ownerId) lines.push(`ownerId: ${result.ownerId}`)
  if (result.connId) lines.push(`connId: ${result.connId}`)
  if (result.llm) {
    lines.push(`llmProtocol: ${result.llm.protocol}`)
    lines.push(`llmModel: ${result.llm.model}`)
    lines.push(`llmBaseUrl: ${result.llm.baseUrl}`)
  }
  if (result.events.length) {
    lines.push('', 'events:')
    for (const e of result.events.slice(-10)) lines.push(`- ${e}`)
  }
  return lines.join('\n')
}

function formatEvent(event: AgentClientEvent): string {
  switch (event.type) {
    case 'connected':
      return 'connected'
    case 'hello':
      return `hello room=${event.message.seat.roomId} seatPos=${event.message.seat.seatPos}`
    case 'game_state':
      return `game_state hand=${event.message.handId} seq=${event.message.stateSeq ?? 'n/a'} actionOn=${event.message.actionOn ?? 'none'}`
    case 'decision_request':
      return `decision_request request=${event.message.requestId} mode=${event.message.mode}`
    case 'action_sent':
      return `action_sent ${event.message.kind} ${event.message.action}`
    case 'action_result':
      return `action_result request=${event.message.requestId} status=${event.message.status}`
    case 'mode_changed':
      return `mode_changed ${event.message.mode}`
    case 'pong':
      return 'pong'
    case 'server_error':
      return `server_error ${event.message.code}: ${userSafeError(event.message.message)}`
    case 'closed':
      return `closed code=${event.code}`
  }
}

function createToolResult<TDetails>(text: string, details: TDetails): ToolResult<TDetails> {
  return {
    content: [{ type: 'text', text }],
    details,
  }
}

async function postJSON<T>(url: string, body: unknown, timeoutMs: number): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body ?? {}),
      signal: controller.signal,
    })
    const text = await response.text()
    let parsed: unknown = undefined
    if (text.trim() !== '') {
      try {
        parsed = JSON.parse(text)
      } catch {
        parsed = text
      }
    }
    if (!response.ok) {
      const msg = apiErrorMessage(parsed) ?? response.statusText
      throw new Error(`HTTP ${response.status}: ${msg}`)
    }
    return parsed as T
  } catch (error) {
    throw new Error(userSafeError(error))
  } finally {
    clearTimeout(timeout)
  }
}

async function postJSONWithAuth<T>(
  url: string,
  body: unknown,
  accessToken: string,
  timeoutMs: number,
): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(body ?? {}),
      signal: controller.signal,
    })
    const text = await response.text()
    let parsed: unknown = undefined
    if (text.trim() !== '') {
      try {
        parsed = JSON.parse(text)
      } catch {
        parsed = text
      }
    }
    if (!response.ok) {
      const msg = apiErrorMessage(parsed) ?? response.statusText
      throw new Error(`HTTP ${response.status}: ${msg}`)
    }
    return parsed as T
  } catch (error) {
    throw new Error(userSafeError(error))
  } finally {
    clearTimeout(timeout)
  }
}

async function getJSONWithBearer<T>(url: string, token: string, timeoutMs: number): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      signal: controller.signal,
    })
    const text = await response.text()
    let parsed: any = undefined
    try {
      parsed = text ? JSON.parse(text) : undefined
    } catch {}
    if (!response.ok) {
      const msg = parsed?.message ? String(parsed.message) : text || response.statusText
      throw new Error(`HTTP ${response.status}: ${userSafeError(msg)}`)
    }
    return (parsed ?? {}) as T
  } finally {
    clearTimeout(timeout)
  }
}

function apiErrorMessage(value: unknown): string | undefined {
  if (!value || typeof value !== 'object') return typeof value === 'string' ? value : undefined
  const record = value as Record<string, unknown>
  return typeof record.message === 'string' ? record.message : undefined
}

function joinURL(base: string, path: string): string {
  return new URL(path, normalizeHTTPBaseURL(base)).toString()
}

function normalizeHTTPBaseURL(value: string): string {
  const trimmed = value.trim()
  const url = new URL(trimmed)
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new Error('apiBaseUrl must start with http:// or https://')
  url.hash = ''
  url.search = ''
  return url.toString().replace(/\/$/, '')
}

function restBaseFromAgentURL(value: string | undefined): string | undefined {
  if (!value) return undefined
  try {
    const url = new URL(value)
    if (url.protocol !== 'ws:' && url.protocol !== 'wss:') return undefined
    url.protocol = url.protocol === 'wss:' ? 'https:' : 'http:'
    url.pathname = ''
    url.search = ''
    url.hash = ''
    return url.toString().replace(/\/$/, '')
  } catch {
    return undefined
  }
}

function originFromBaseURL(value: string): string {
  try {
    const url = new URL(value)
    return `${url.protocol}//${url.host}`
  } catch {
    return value
  }
}

function redactURLSecrets(value: string): string {
  try {
    const url = new URL(value)
    const sensitiveKeys = ['token', 'bind', 'pat', 'grant', 'accessToken', 'mobileGrant']
    for (const key of sensitiveKeys) {
      if (url.searchParams.has(key)) url.searchParams.set(key, '<redacted>')
    }
    if (url.hash) {
      const fragment = new URLSearchParams(url.hash.slice(1))
      let changed = false
      for (const key of sensitiveKeys) {
        if (fragment.has(key)) {
          fragment.set(key, '<redacted>')
          changed = true
        }
      }
      if (changed) url.hash = fragment.toString()
    }
    return url.toString()
  } catch {
    return userSafeError(value)
  }
}

function removeUndefined<T extends Record<string, unknown>>(value: T): T {
  for (const key of Object.keys(value)) {
    if (value[key] === undefined) delete value[key]
  }
  return value
}

function indent(value: string): string {
  return value.split('\n').map((line) => `  ${line}`).join('\n')
}

function asRecord(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return value as Record<string, unknown>
}

function readObjectParam<T>(params: Record<string, unknown>, key: string, required: true): T
function readObjectParam<T>(params: Record<string, unknown>, key: string, required: false): T | undefined
function readObjectParam<T>(params: Record<string, unknown>, key: string, required: boolean): T | undefined {
  const value = params[key]
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    if (required) throw new Error(`${key} is required`)
    return undefined
  }
  return value as T
}

function readOptionalString(params: Record<string, unknown>, key: string) {
  const value = params[key]
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed === '' ? undefined : trimmed
}

function readBoolean(params: Record<string, unknown>, key: string, fallback: boolean) {
  return parseBoolean(params[key], fallback)
}

function readOptionalBoolean(params: Record<string, unknown>, key: string) {
  const value = params[key]
  if (typeof value === 'boolean') return value
  if (typeof value === 'string' && value.trim() !== '') return parseBoolean(value, false)
  return undefined
}

function readInteger(params: Record<string, unknown>, key: string, fallback: number) {
  const value = params[key]
  if (typeof value === 'number' && Number.isFinite(value)) return Math.trunc(value)
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return Math.trunc(parsed)
  }
  return fallback
}

function readOptionalInteger(params: Record<string, unknown>, key: string): number | undefined {
  const value = params[key]
  if (typeof value === 'number' && Number.isFinite(value)) return Math.trunc(value)
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return Math.trunc(parsed)
  }
  return undefined
}

function readOptionalNumber(params: Record<string, unknown>, key: string): number | undefined {
  const value = params[key]
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return undefined
}

function parseBoolean(value: unknown, fallback: boolean) {
  if (typeof value === 'boolean') return value
  if (typeof value !== 'string' || value.trim() === '') return fallback
  const normalized = value.trim().toLowerCase()
  if (['1', 'true', 'yes', 'on'].includes(normalized)) return true
  if (['0', 'false', 'no', 'off'].includes(normalized)) return false
  return fallback
}

function userSafeError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error)
  return message
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, 'Bearer <redacted>')
    .replace(/\bsk-[A-Za-z0-9_-]+\b/g, '<redacted-api-key>')
    .replace(/([?&](?:token|bind|pat|grant|accessToken|apiKey|llmApiKey)=)[^&\s)]+/gi, '$1<redacted>')
    .replace(/\?(?:token|bind|pat|grant|accessToken|apiKey|llmApiKey)=[^\s)]+/gi, '?<redacted-query>')
    .replace(/\bhp_(?:pat|bind|mlg)_[A-Za-z0-9_-]+\b/g, '<redacted-hiland-token>')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '<redacted-jwt>')
}
