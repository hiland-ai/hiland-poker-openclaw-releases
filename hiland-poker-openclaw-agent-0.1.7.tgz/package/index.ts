import { definePluginEntry } from 'openclaw/plugin-sdk/plugin-entry'
import WebSocket from 'ws'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { AgentClient, type AgentClientEvent, type DecideResult } from './typescript/src/client.js'
import {
  decideWithBaselineStrategy,
  normalizeStrategy,
  type StrategyName,
} from './typescript/src/strategy.js'
import {
  decideWithLLMAdvisor,
  hasRunnableLLMAdvisor,
  listMissingLLMAdvisorRequirements,
  resolveLLMAdvisorConfig,
  type LLMAdvisorConfig,
  type LLMAdvisorDecision,
} from './typescript/src/llm-advisor.js'
import {
  normalizePersona,
  observePersonaHand,
  pickNemesisSeat,
  type AgentPersona,
} from './typescript/src/persona.js'
import type { LegalAction, MsgDecisionRequest, MsgGameState } from './typescript/src/types.js'

const PERSONA_ENUM = [
  'gto_cold',
  'mad_dog',
  'exploit',
  'turtle',
  'grudge',
  'learning',
  'trash_talk',
] as const satisfies readonly AgentPersona[]

const personaSchemaProperty = {
  type: 'string',
  enum: [...PERSONA_ENUM],
  description:
    'Agent playstyle persona: gto_cold (robotic), mad_dog (maniac), exploit (nit-with-teeth), turtle (ultra-nit), grudge (vs deep-stack bully), learning (rotating style), trash_talk (longer spicy rationale). Defaults unset (strategy-only).',
} as const

type AdvisorEngine = 'baseline' | 'llm'

type AdvisorDecisionResult = DecideResult & {
  source?: LLMAdvisorDecision['source']
  fallbackReason?: string
}

type PluginConfig = {
  apiBaseUrl?: string
  nickname?: string
  agentUrl?: string
  pat?: string
  agentBindToken?: string
  strategy?: StrategyName
  persona?: AgentPersona
  autosubmit?: boolean
  advisor?: AdvisorEngine
  llmEnabled?: boolean
  llmProvider?: LLMAdvisorConfig['provider']
  llmProtocol?: LLMAdvisorConfig['protocol']
  llmBaseUrl?: string
  llmApiKey?: string
  llmModel?: string
  llmTimeoutMs?: number
  llmTemperature?: number
  llmMaxTokens?: number
  llmLanguage?: LLMAdvisorConfig['language']
}

type ToolContent = { type: 'text'; text: string }

type ToolResult<TDetails> = {
  content: ToolContent[]
  details: TDetails
}

type LoginCodeToolResult = {
  status: 'issued'
  apiBaseUrl: string
  nickname: string
  userId: string
  expiresIn: number
  loginCodeGenerated: boolean
}

type HubConnectResult = {
  status: 'connected' | 'timeout' | 'failed'
  ownerId?: string
  connId?: string
  events: string[]
}

type DecideToolResult = AdvisorDecisionResult & {
  strategy: StrategyName
  advisor: AdvisorEngine
  persona?: AgentPersona
  legalActions: LegalAction[]
}

type RunOnceResult = {
  status: 'connected' | 'action_sent' | 'action_result' | 'closed' | 'timeout' | 'failed'
  mode?: string
  requestId?: string
  action?: AdvisorDecisionResult
  events: string[]
}

type StatusResult = {
  configured: {
    apiBaseUrl: boolean
    agentUrl: boolean
    pat: boolean
    agentBindToken: boolean
    strategy: StrategyName
    persona?: AgentPersona
    autosubmit: boolean
    advisor: AdvisorEngine
    llmAdvisor: {
      enabled: boolean
      runnable: boolean
      provider: LLMAdvisorConfig['provider']
      protocol: LLMAdvisorConfig['protocol']
      baseUrl: boolean
      apiKey: boolean
      model: string
      timeoutMs: number
    }
  }
  warnings: string[]
}

type BootstrapRoomInput = {
  name?: string
  maxSeats?: number
  smallBlind?: number
  bigBlind?: number
  minBuyIn?: number
  maxBuyIn?: number
}

type BootstrapConfig = {
  apiBaseUrl?: string
  publicBaseUrl?: string
  nickname?: string
  room: BootstrapRoomInput
  buyIn?: number
  preferredSeat?: number
  agentLabel?: string
  strategy: StrategyName
  persona?: AgentPersona
  autosubmit: boolean
  advisor: AdvisorEngine
  llm: LLMAdvisorConfig
  timeoutMs: number
  connectOnce: boolean
  includeSensitiveDetails: boolean
  createMobileEntry: boolean
}

type BootstrapAgentRoomApiResponse = {
  type: 'agent.bootstrap'
  auth: {
    accessToken: string
    userId: string
    nickname: string
    chips: number
    expiresIn: number
  }
  room: {
    id: string
    name: string
    maxSeats: number
    smallBlind: number
    bigBlind: number
    minBuyIn: number
    maxBuyIn: number
    playerCount: number
  }
  seat: { seatPos: number; stack: number; buyIn: number }
  agent: {
    agentUrl: string
    pat: string
    agentTokenId: string
    agentBindToken: string
    agentBindExpiresAt: string
  }
  links: { entryUrl: string }
}

type MobileGrantApiResponse = {
  grant: string
  expiresAt: string
  entryUrl: string
  ttlSeconds: number
}

type BootstrapToolResult = {
  status: 'created'
  apiBaseUrl: string
  publicBaseUrl?: string
  auth: {
    userId: string
    nickname: string
    chips: number
    expiresIn: number
    accessTokenGenerated: boolean
  }
  room: BootstrapAgentRoomApiResponse['room']
  seat: BootstrapAgentRoomApiResponse['seat']
  agent: {
    agentUrl: string
    agentTokenId: string
    patGenerated: boolean
    agentBindTokenGenerated: boolean
    agentBindExpiresAt: string
  }
  links: {
    entryUrlGenerated: boolean
    entryUrlRedacted?: string
    mobileEntryUrlGenerated: boolean
    mobileEntryUrlRedacted?: string
  }
  runOnce?: RunOnceResult
  /** Sensitive credentials are machine-readable for follow-up tool calls; never print them in chat. */
  sensitive?: {
    accessToken: string
    entryUrl: string
    mobileEntryUrl?: string
    mobileGrant?: string
    agentUrl: string
    pat: string
    agentBindToken: string
  }
}

type BindWebSeatResult = {
  status: 'ready' | 'run_once'
  configured: {
    agentUrl: boolean
    pat: boolean
    agentBindToken: boolean
    strategy: StrategyName
    persona?: AgentPersona
    autosubmit: boolean
    advisor: AdvisorEngine
  }
  warnings: string[]
  runOnce?: RunOnceResult
}

const DecideToolSchema = {
  type: 'object',
  additionalProperties: false,
  required: ['state'],
  properties: {
    state: {
      type: 'object',
      description: 'Latest Hiland Agent game_state message.',
    },
    request: {
      type: 'object',
      description: 'Optional Hiland Agent decision_request message.',
    },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override. Defaults to plugin config or balanced.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine. Defaults to llm and requires runnable LLM config.',
    },
    llmEnabled: { type: 'boolean', description: 'Enable LLM calls for advisor=llm. Defaults to true via plugin config/env.' },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmApiKey: { type: 'string', description: 'Optional LLM API key override. Never print this value.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
  },
} as const

const BootstrapRoomToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    apiBaseUrl: {
      type: 'string',
      description:
        'Optional REST API base URL, e.g. https://hiland.example.com. Defaults to plugin config, HILAND_API_BASE_URL, or derived from agentUrl.',
    },
    publicBaseUrl: {
      type: 'string',
      description:
        'Optional public web origin used in the clickable entry link. Defaults to apiBaseUrl.',
    },
    nickname: {
      type: 'string',
      description: 'Optional guest nickname. Defaults to OpenClaw user display name when available.',
    },
    room: {
      type: 'object',
      description:
        'Optional partial room config: name, maxSeats, smallBlind, bigBlind, minBuyIn, maxBuyIn. Server fills sensible defaults.',
    },
    roomName: { type: 'string', description: 'Optional shorthand for room.name.' },
    maxSeats: { type: 'number', minimum: 2, maximum: 10 },
    smallBlind: { type: 'number', minimum: 1 },
    bigBlind: { type: 'number', minimum: 1 },
    minBuyIn: { type: 'number', minimum: 1 },
    maxBuyIn: { type: 'number', minimum: 1 },
    buyIn: { type: 'number', minimum: 1, description: 'Optional buy-in. Server defaults when omitted.' },
    preferredSeat: { type: 'number', minimum: 0, description: 'Optional preferred seat position.' },
    agentLabel: { type: 'string', description: 'Optional label for the generated PAT.' },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override for connectOnce.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine for connectOnce. Defaults to llm and requires runnable LLM config.',
    },
    llmEnabled: { type: 'boolean', description: 'Enable LLM calls for advisor=llm. Defaults to true via plugin config/env.' },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmApiKey: { type: 'string', description: 'Optional LLM API key override. Never print this value.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
    autosubmit: {
      type: 'boolean',
      description: 'Safety default false. Used only when connectOnce=true.',
    },
    connectOnce: {
      type: 'boolean',
      description:
        'When true, immediately connect to /agent and run once after bootstrap. This consumes the one-time AgentBindToken. Defaults false.',
    },
    includeSensitiveDetails: {
      type: 'boolean',
      description:
        'When true, returns generated secrets only in machine-readable details for follow-up tools; text output stays redacted. Defaults true.',
    },
    createMobileEntry: {
      type: 'boolean',
      description:
        'When true (default), creates a one-time mobile login entry link for cross-device flow after bootstrap.',
    },
    timeoutMs: {
      type: 'number',
      minimum: 1000,
      description: 'HTTP request timeout, and connectOnce run timeout when enabled. Defaults to 15000.',
    },
  },
} as const

const BindWebSeatToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    credentials: {
      type: 'object',
      description:
        'Optional JSON copied from the web client with agentUrl, pat, and agentBindToken.',
    },
    agentUrl: {
      type: 'string',
      description: 'Agent WebSocket URL from the web client, e.g. wss://example.com/agent.',
    },
    pat: {
      type: 'string',
      description: 'PAT from the web client. Never print this value.',
    },
    agentBindToken: {
      type: 'string',
      description: 'AgentBindToken from the web client. Never print this value.',
    },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override. Defaults to plugin config or balanced.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine when connect=true. Defaults to llm and requires runnable LLM config.',
    },
    llmEnabled: { type: 'boolean', description: 'Enable LLM calls for advisor=llm. Defaults to true via plugin config/env.' },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmApiKey: { type: 'string', description: 'Optional LLM API key override. Never print this value.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
    autosubmit: {
      type: 'boolean',
      description: 'Safety default false unless plugin config/env explicitly enables it.',
    },
    connect: {
      type: 'boolean',
      description:
        'When true, connect and run once immediately. This consumes the one-time AgentBindToken. Defaults false.',
    },
    timeoutMs: {
      type: 'number',
      minimum: 1000,
      description: 'Maximum connect/run timeout when connect=true. Defaults to 30000.',
    },
  },
} as const

const RunOnceToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    agentUrl: {
      type: 'string',
      description: 'Optional Agent WebSocket URL override. Defaults to plugin config or HILAND_AGENT_URL.',
    },
    pat: {
      type: 'string',
      description: 'Optional PAT override. Prefer secure plugin config/env; never print this value.',
    },
    agentBindToken: {
      type: 'string',
      description: 'Optional AgentBindToken override. Prefer secure plugin config/env; never print this value.',
    },
    strategy: {
      type: 'string',
      enum: ['conservative', 'balanced', 'aggressive'],
      description: 'Optional strategy override. Defaults to plugin config or balanced.',
    },
    advisor: {
      type: 'string',
      enum: ['baseline', 'llm'],
      description: 'Decision engine. Defaults to llm and requires runnable LLM config.',
    },
    llmEnabled: { type: 'boolean', description: 'Enable LLM calls for advisor=llm. Defaults to true via plugin config/env.' },
    llmProvider: { type: 'string', enum: ['openai-compatible', 'anthropic'], description: 'LLM provider. Inferred from llmProtocol when omitted.' },
    llmProtocol: { type: 'string', enum: ['responses', 'messages', 'chat-completions'], description: 'LLM protocol: responses=OpenAI Responses, messages=Anthropic Messages, chat-completions=OpenAI-compatible chat completions. Defaults to responses.' },
    llmModel: { type: 'string', description: 'Optional LLM model override for advisor=llm.' },
    llmBaseUrl: { type: 'string', description: 'Optional OpenAI-compatible base URL for advisor=llm.' },
    llmApiKey: { type: 'string', description: 'Optional LLM API key override. Never print this value.' },
    llmTimeoutMs: { type: 'number', minimum: 500, description: 'Optional LLM timeout. Defaults to 3500.' },
    llmTemperature: { type: 'number', minimum: 0, maximum: 1, description: 'Optional LLM temperature. Defaults to 0.15.' },
    llmMaxTokens: { type: 'number', minimum: 80, maximum: 1000, description: 'Optional LLM response token cap. Defaults to 220.' },
    llmLanguage: { type: 'string', enum: ['zh-CN', 'en'], description: 'Optional rationale language. Defaults to zh-CN.' },
    persona: personaSchemaProperty,
    autosubmit: {
      type: 'boolean',
      description: 'When true, submit in server auto modes. Defaults false unless plugin config/env explicitly enables it.',
    },
    timeoutMs: {
      type: 'number',
      minimum: 1000,
      description: 'Maximum time to stay connected waiting for one decision_request. Defaults to 30000.',
    },
  },
} as const

const StatusToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {},
} as const

const LoginCodeToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    apiBaseUrl: { type: 'string' },
    nickname: { type: 'string', description: 'Optional nickname. Defaults to OpenClaw display name.' },
    publicBaseUrl: { type: 'string' },
    timeoutMs: { type: 'number', minimum: 1000 },
  },
} as const

const HubConnectToolSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    apiBaseUrl: { type: 'string' },
    agentUrl: { type: 'string' },
    pat: { type: 'string' },
    agentBindToken: { type: 'string' },
    timeoutMs: {
      type: 'number',
      minimum: 0,
      description: 'How long to keep this long connection alive. 0 means keep alive until explicitly disconnected/restarted.',
    },
  },
} as const

type HubSession = {
  ws: WebSocket
  pingTimer: ReturnType<typeof setInterval>
  autoCloseTimer?: ReturnType<typeof setTimeout>
  connId?: string
  ownerId?: string
}

const hubSessions = new Map<string, HubSession>()
let cachedFingerprint: string | undefined

export default definePluginEntry({
  id: 'hiland-poker-openclaw-agent',
  name: 'Hiland Poker OpenClaw Agent',
  description:
    'OpenClaw plugin that connects an OpenClaw Agent to a Hiland Poker seat through the Hiland Agent WebSocket protocol.',
  register(api) {
    const pluginConfig = resolvePluginConfig(api.pluginConfig)

    api.registerTool({
      name: 'hiland_poker_agent_status',
      label: 'Hiland Poker Agent Status',
      description:
        'Check whether Hiland Poker Agent plugin configuration is present without revealing secrets.',
      parameters: StatusToolSchema as any,
      execute: async () => {
        const config = resolveConnectionConfig(pluginConfig, {})
        const apiBaseUrl = resolveApiBaseUrl(pluginConfig, {})
        const details: StatusResult = {
          configured: {
            apiBaseUrl: Boolean(apiBaseUrl),
            agentUrl: Boolean(config.agentUrl),
            pat: Boolean(config.pat),
            agentBindToken: Boolean(config.agentBindToken),
            strategy: config.strategy,
            persona: config.persona,
            autosubmit: config.autosubmit,
            advisor: config.advisor,
            llmAdvisor: formatLLMAdvisorStatus(config.llm),
          },
          warnings: [...buildApiWarnings(apiBaseUrl), ...buildConfigWarnings(config)],
        }
        return createToolResult(formatStatus(details), details)
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_bootstrap_room',
      label: 'Hiland Poker Agent Bootstrap Room',
      description:
        'Create a guest user, create a room, seat the user, generate an entry link, and mint Agent PAT/AgentBindToken credentials without printing secrets.',
      parameters: BootstrapRoomToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const config = resolveBootstrapConfig(pluginConfig, params)
        assertBootstrapConfig(config)
        return bootstrapAgentRoom(config)
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_issue_login_code',
      label: 'Hiland Poker Agent Issue Login Code',
      description:
        'Issue a mobile login code for the owner without creating any room or starting gameplay connection.',
      parameters: LoginCodeToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const apiBaseUrl = resolveApiBaseUrl(pluginConfig, params)
        if (!apiBaseUrl) throw new Error('HILAND_API_BASE_URL / apiBaseUrl is missing')
        const timeoutMs = Math.max(readInteger(params, 'timeoutMs', 15_000), 1_000)
        const nickname = readOptionalString(params, 'nickname') ?? detectOpenClawNickname(pluginConfig) ?? 'OpenClaw'
        const auth = await postJSON<BootstrapAgentRoomApiResponse['auth']>(
          joinURL(apiBaseUrl, '/api/auth/guest'),
          { nickname },
          timeoutMs,
        )
        const grant = await postJSONWithAuth<MobileGrantApiResponse>(
          joinURL(apiBaseUrl, '/api/auth/mobile-grant'),
          { publicBaseUrl: readOptionalString(params, 'publicBaseUrl') ?? originFromBaseURL(apiBaseUrl) },
          auth.accessToken,
          timeoutMs,
        )
        const details: LoginCodeToolResult & { sensitive?: { loginCode: string } } = {
          status: 'issued',
          apiBaseUrl,
          nickname: auth.nickname,
          userId: auth.userId,
          expiresIn: auth.expiresIn,
          loginCodeGenerated: Boolean(grant.grant),
          sensitive: { loginCode: grant.grant },
        }
        return createToolResult(
          [
            'Hiland Poker login code issued.',
            `owner: ${auth.nickname} (${auth.userId})`,
            `expiresIn: ${auth.expiresIn}s`,
            'loginCode: generated (not printed)',
          ].join('\n'),
          details,
        )
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_bind_web_seat',
      label: 'Hiland Poker Agent Bind Web Seat',
      description:
        'Accept Agent credentials generated by the web client and prepare or optionally run one Agent connection without printing secrets.',
      parameters: BindWebSeatToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const merged = mergeCredentialParams(params)
        const config = resolveConnectionConfig(pluginConfig, merged)
        assertRunnableConfig(config)
        const connect = readBoolean(params, 'connect', false)
        if (!connect) {
          const details: BindWebSeatResult = {
            status: 'ready',
            configured: {
              agentUrl: true,
              pat: true,
              agentBindToken: true,
              strategy: config.strategy,
              persona: config.persona,
              autosubmit: config.autosubmit,
              advisor: config.advisor,
            },
            warnings: [
              'Credentials are present. Do not print PAT or AgentBindToken.',
              'Connecting to /agent consumes the one-time AgentBindToken; use connect=true only when ready to run.',
            ],
          }
          return createToolResult(formatBindWebSeat(details), details)
        }
        assertRunnableLLMAdvisorForOperation(config.advisor, config.llm, 'hiland_poker_agent_bind_web_seat')
        const run = await runOnce(config)
        const details: BindWebSeatResult = {
          status: 'run_once',
          configured: {
            agentUrl: true,
            pat: true,
            agentBindToken: true,
            strategy: config.strategy,
            persona: config.persona,
            autosubmit: config.autosubmit,
            advisor: config.advisor,
          },
          warnings: ['The one-time AgentBindToken was used for this connection. Generate a fresh one before reconnecting.'],
          runOnce: run.details,
        }
        return createToolResult(formatBindWebSeat(details), details)
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_decide',
      label: 'Hiland Poker Agent Decide',
      description:
        'Compute a Hiland Poker action suggestion from a game_state/decision_request without connecting to the server.',
      parameters: DecideToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const state = readObjectParam<MsgGameState>(params, 'state', true)
        const request = readObjectParam<MsgDecisionRequest>(params, 'request', false)
        const strategy = normalizeStrategy(
          readOptionalString(params, 'strategy') ?? pluginConfig.strategy ?? process.env.HILAND_AGENT_STRATEGY,
        )
        const persona = resolvePersonaFromInputs(pluginConfig, params)
        const legalActions = request?.legalActions ?? state.legalActions ?? []
        const advisor = resolveAdvisorEngine(readOptionalString(params, 'advisor') ?? pluginConfig.advisor)
        const llm = resolveLLMAdvisorConfig({ ...pluginConfig, ...params })
        assertRunnableLLMAdvisorForOperation(advisor, llm, 'hiland_poker_agent_decide')
        const personaHandIndex =
          persona === 'learning' ? observePersonaHand(state.roomId, state.handId) : undefined
        const nemesisSeat = persona ? pickNemesisSeat(state) : null
        const decision = await decideWithAdvisor({
          state,
          request,
          legalActions,
          strategy,
          advisor,
          llm,
          persona,
          personaHandIndex,
          nemesisSeat,
        })
        const details: DecideToolResult = {
          ...decision,
          strategy,
          advisor,
          persona,
          legalActions,
        }
        return createToolResult(formatDecision(details), details)
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_run_once',
      label: 'Hiland Poker Agent Run Once',
      description:
        'Connect to Hiland Poker /agent, wait for one decision_request, send one suggestion or permitted auto action, then disconnect.',
      parameters: RunOnceToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const config = resolveConnectionConfig(pluginConfig, params)
        assertRunnableConfig(config)
        assertRunnableLLMAdvisorForOperation(config.advisor, config.llm, 'hiland_poker_agent_run_once')
        return runOnce(config)
      },
    })

    api.registerTool({
      name: 'hiland_poker_agent_connect_hub',
      label: 'Hiland Poker Agent Connect Hub',
      description:
        'Establish a long-lived owner-bound agent hub connection (/agent/hub) without creating rooms or gameplay actions.',
      parameters: HubConnectToolSchema as any,
      execute: async (_toolCallId, rawParams) => {
        const params = asRecord(rawParams)
        const config = resolveConnectionConfig(pluginConfig, params)
        if (!config.pat) {
          throw new Error('HILAND_PAT is required')
        }
        const base =
          hubURLFrom(
            readOptionalString(params, 'agentUrl') ??
              config.agentUrl ??
              (resolveApiBaseUrl(pluginConfig, params)
                ? resolveApiBaseUrl(pluginConfig, params)!.replace(/^http/, 'ws') + '/agent'
                : undefined),
          )
        if (!base) throw new Error('agentUrl or apiBaseUrl is required')
        const timeoutRaw = readInteger(params, 'timeoutMs', 0)
        const timeoutMs = timeoutRaw <= 0 ? 0 : Math.max(timeoutRaw, 1_000)
        return connectHub(base, config.pat, config.agentBindToken, timeoutMs)
      },
    })
  },
})

async function bootstrapAgentRoom(config: RunnableBootstrapConfig): Promise<ToolResult<BootstrapToolResult>> {
  const apiURL = joinURL(config.apiBaseUrl, '/api/bootstrap/agent-room')
  const body = removeUndefined({
    nickname: config.nickname,
    room: removeUndefined(config.room),
    buyIn: config.buyIn,
    preferredSeat: config.preferredSeat,
    agentLabel: config.agentLabel,
    publicBaseUrl: config.publicBaseUrl ?? originFromBaseURL(config.apiBaseUrl),
  })

  const response = await postJSON<BootstrapAgentRoomApiResponse>(apiURL, body, config.timeoutMs)
  let mobileGrant: MobileGrantApiResponse | undefined
  if (config.createMobileEntry && response.auth.accessToken) {
    const mobileGrantURL = joinURL(config.apiBaseUrl, '/api/auth/mobile-grant')
    mobileGrant = await postJSONWithAuth<MobileGrantApiResponse>(
      mobileGrantURL,
      { publicBaseUrl: config.publicBaseUrl ?? originFromBaseURL(config.apiBaseUrl) },
      response.auth.accessToken,
      config.timeoutMs,
    )
  }
  const details: BootstrapToolResult = {
    status: 'created',
    apiBaseUrl: config.apiBaseUrl,
    publicBaseUrl: config.publicBaseUrl,
    auth: {
      userId: response.auth.userId,
      nickname: response.auth.nickname,
      chips: response.auth.chips,
      expiresIn: response.auth.expiresIn,
      accessTokenGenerated: Boolean(response.auth.accessToken),
    },
    room: response.room,
    seat: response.seat,
    agent: {
      agentUrl: response.agent.agentUrl,
      agentTokenId: response.agent.agentTokenId,
      patGenerated: Boolean(response.agent.pat),
      agentBindTokenGenerated: Boolean(response.agent.agentBindToken),
      agentBindExpiresAt: response.agent.agentBindExpiresAt,
    },
    links: {
      entryUrlGenerated: Boolean(response.links.entryUrl),
      entryUrlRedacted: response.links.entryUrl ? redactURLSecrets(response.links.entryUrl) : undefined,
      mobileEntryUrlGenerated: Boolean(mobileGrant?.entryUrl),
      mobileEntryUrlRedacted: mobileGrant?.entryUrl ? redactURLSecrets(mobileGrant.entryUrl) : undefined,
    },
  }

  if (config.includeSensitiveDetails) {
    details.sensitive = {
      accessToken: response.auth.accessToken,
      entryUrl: response.links.entryUrl,
      mobileEntryUrl: mobileGrant?.entryUrl,
      mobileGrant: mobileGrant?.grant,
      agentUrl: response.agent.agentUrl,
      pat: response.agent.pat,
      agentBindToken: response.agent.agentBindToken,
    }
  }

  if (config.connectOnce) {
    assertRunnableLLMAdvisorForOperation(config.advisor, config.llm, 'hiland_poker_agent_bootstrap_room')
    const run = await runOnce({
      agentUrl: response.agent.agentUrl,
      pat: response.agent.pat,
      agentBindToken: response.agent.agentBindToken,
      strategy: config.strategy,
      persona: config.persona,
      autosubmit: config.autosubmit,
      advisor: config.advisor,
      llm: config.llm,
      timeoutMs: config.timeoutMs,
    })
    details.runOnce = run.details
  }

  return createToolResult(formatBootstrap(details), details)
}

function hubURLFrom(value: string | undefined): string | undefined {
  if (!value) return undefined
  try {
    const u = new URL(value)
    if (u.protocol === 'http:' || u.protocol === 'https:') {
      u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:'
    }
    u.pathname = '/agent/hub'
    u.search = ''
    u.hash = ''
    return u.toString()
  } catch {
    return undefined
  }
}

async function runOnce(config: RunnableConnectionConfig): Promise<ToolResult<RunOnceResult>> {
  const events: string[] = []
  const timeoutMs = config.timeoutMs
  let settled = false
  let lastAction: AdvisorDecisionResult | undefined
  let lastRequest: MsgDecisionRequest | undefined

  let settleRun: ((result: RunOnceResult) => void) | undefined
  let timeout: ReturnType<typeof setTimeout> | undefined
  const settle = (result: RunOnceResult, agent?: AgentClient) => {
    if (settled) return
    settled = true
    if (timeout) clearTimeout(timeout)
    settleRun?.(result)
    agent?.close()
  }

  const agent = new AgentClient({
    url: config.agentUrl,
    pat: config.pat,
    agentBindToken: config.agentBindToken,
    autosubmit: config.autosubmit,
    decide: async ({ state, request, legalActions }) => {
      lastRequest = request
      const persona = config.persona
      const personaHandIndex =
        persona === 'learning' ? observePersonaHand(state.roomId, state.handId) : undefined
      const nemesisSeat = persona ? pickNemesisSeat(state) : null
      const decision = await decideWithAdvisor({
        state,
        request,
        legalActions,
        strategy: config.strategy,
        advisor: config.advisor,
        llm: config.llm,
        persona,
        personaHandIndex,
        nemesisSeat,
      })
      lastAction = decision
      return decision
    },
    onEvent: (event) => {
      events.push(formatEvent(event))
      if (event.type === 'action_result') {
        settle(
          {
            status: 'action_result',
            mode: lastRequest?.mode,
            requestId: event.message.requestId,
            action: lastAction,
            events,
          },
          agent,
        )
      }
      if (event.type === 'closed') {
        settle({ status: lastAction ? 'action_sent' : 'closed', mode: lastRequest?.mode, requestId: lastRequest?.requestId, action: lastAction, events })
      }
    },
  } as ConstructorParameters<typeof AgentClient>[0])

  try {
    const resultPromise = new Promise<RunOnceResult>((resolve) => {
      settleRun = resolve
      timeout = setTimeout(() => {
        settle({ status: 'timeout', events }, agent)
      }, timeoutMs)
    })
    await agent.start()
    const result = await resultPromise
    return createToolResult(formatRunOnce(result), result)
  } catch (error) {
    agent.close()
    const result: RunOnceResult = {
      status: 'failed',
      events: [...events, userSafeError(error)],
    }
    return createToolResult(formatRunOnce(result), result)
  }
}

async function connectHub(
  baseURL: string,
  pat: string,
  agentBindToken: string | undefined,
  timeoutMs: number,
): Promise<ToolResult<HubConnectResult>> {
  const wsURL = new URL(baseURL)
  wsURL.searchParams.set('token', pat)
  if (agentBindToken) wsURL.searchParams.set('bind', agentBindToken)
  const sessionKey = `${wsURL.origin}${wsURL.pathname}::${pat}`
  const existing = hubSessions.get(sessionKey)
  if (existing && existing.ws.readyState === WebSocket.OPEN) {
    const details: HubConnectResult = {
      status: 'connected',
      connId: existing.connId,
      ownerId: existing.ownerId,
      events: ['already connected'],
    }
    return createToolResult(formatHubResult(details), details)
  }
  if (existing) {
    try {
      existing.ws.terminate()
    } catch {}
    clearInterval(existing.pingTimer)
    if (existing.autoCloseTimer) clearTimeout(existing.autoCloseTimer)
    hubSessions.delete(sessionKey)
  }

  const fingerprint = getOrCreateAgentFingerprint()
  const events: string[] = []
  return new Promise((resolve) => {
    const ws = new WebSocket(wsURL.toString(), {
      headers: {
        'X-Hiland-Agent-Name': 'openclaw',
        'X-Hiland-Agent-Version': '0.1.7',
        'X-Hiland-Agent-Fingerprint': fingerprint,
      },
    })
    const session: HubSession = {
      ws,
      pingTimer: setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'ping', ts: Date.now() }))
        }
      }, 15_000),
    }
    hubSessions.set(sessionKey, session)
    let connId: string | undefined
    let ownerId: string | undefined
    let settled = false
    const settle = (result: HubConnectResult) => {
      if (settled) return
      settled = true
      resolve(createToolResult(formatHubResult(result), result))
    }
    const failAndCleanup = (result: HubConnectResult) => {
      clearInterval(session.pingTimer)
      if (session.autoCloseTimer) clearTimeout(session.autoCloseTimer)
      hubSessions.delete(sessionKey)
      settle(result)
    }
    const connectWaitTimer = setTimeout(() => {
      events.push('connect handshake timeout')
      try {
        ws.close()
      } catch {}
      failAndCleanup({ status: 'failed', connId, ownerId, events })
    }, 15_000)
    ws.on('open', () => {
      events.push('connected')
    })
    ws.on('message', (raw) => {
      try {
        const m = JSON.parse(String(raw))
        if (m?.type === 'hello') {
          connId = m.connId
          ownerId = m.ownerId
          session.connId = connId
          session.ownerId = ownerId
          events.push(`hello owner=${ownerId} conn=${connId}`)
          clearTimeout(connectWaitTimer)
          if (timeoutMs > 0) {
            session.autoCloseTimer = setTimeout(() => {
              events.push('timeout reached, closing')
              try {
                ws.close()
              } catch {}
            }, timeoutMs)
          }
          settle({ status: 'connected', connId, ownerId, events })
        } else if (m?.type === 'pong') {
          events.push('pong')
        }
      } catch {
        events.push('received non-json message')
      }
    })
    ws.on('error', (err) => {
      events.push(userSafeError(err))
      clearTimeout(connectWaitTimer)
      failAndCleanup({ status: 'failed', connId, ownerId, events })
    })
    ws.on('close', () => {
      clearTimeout(connectWaitTimer)
      clearInterval(session.pingTimer)
      if (session.autoCloseTimer) clearTimeout(session.autoCloseTimer)
      hubSessions.delete(sessionKey)
      if (!settled) {
        settle({
          status: events.includes('timeout reached, closing') ? 'timeout' : 'failed',
          connId,
          ownerId,
          events,
        })
      }
    })
  })
}

function getOrCreateAgentFingerprint(): string {
  if (cachedFingerprint) return cachedFingerprint
  const file = path.join(os.homedir(), '.hiland-poker', 'agent-fingerprint')
  try {
    if (fs.existsSync(file)) {
      const existing = fs.readFileSync(file, 'utf8').trim()
      if (existing) {
        cachedFingerprint = existing
        return existing
      }
    }
  } catch {}
  const created = randomUUID()
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, created, 'utf8')
  } catch {}
  cachedFingerprint = created
  return created
}

type ResolvedConnectionConfig = {
  agentUrl?: string
  pat?: string
  agentBindToken?: string
  strategy: StrategyName
  persona?: AgentPersona
  autosubmit: boolean
  timeoutMs: number
  advisor: AdvisorEngine
  llm: LLMAdvisorConfig
}

type RunnableConnectionConfig = ResolvedConnectionConfig & {
  agentUrl: string
  pat: string
}

type RunnableBootstrapConfig = BootstrapConfig & { apiBaseUrl: string }

function resolvePluginConfig(raw: Record<string, unknown> | undefined): PluginConfig {
  const config = raw ?? {}
  const strategy = readOptionalString(config, 'strategy')
  return {
    apiBaseUrl: readOptionalString(config, 'apiBaseUrl'),
    nickname: readOptionalString(config, 'nickname'),
    agentUrl: readOptionalString(config, 'agentUrl'),
    pat: readOptionalString(config, 'pat'),
    agentBindToken: readOptionalString(config, 'agentBindToken'),
    strategy: strategy ? normalizeStrategy(strategy) : undefined,
    persona: normalizePersona(readOptionalString(config, 'persona')),
    autosubmit: readOptionalBoolean(config, 'autosubmit'),
    advisor: resolveAdvisorEngine(readOptionalString(config, 'advisor')),
    llmEnabled: readOptionalBoolean(config, 'llmEnabled'),
    llmProvider: readLLMProvider(config, 'llmProvider'),
    llmProtocol: readLLMProtocol(config, 'llmProtocol'),
    llmBaseUrl: readOptionalString(config, 'llmBaseUrl'),
    llmApiKey: readOptionalString(config, 'llmApiKey'),
    llmModel: readOptionalString(config, 'llmModel'),
    llmTimeoutMs: readOptionalInteger(config, 'llmTimeoutMs'),
    llmTemperature: readOptionalNumber(config, 'llmTemperature'),
    llmMaxTokens: readOptionalInteger(config, 'llmMaxTokens'),
    llmLanguage: readOptionalString(config, 'llmLanguage') === 'en' ? 'en' : readOptionalString(config, 'llmLanguage') === 'zh-CN' ? 'zh-CN' : undefined,
  }
}

function resolvePersonaFromInputs(pluginConfig: PluginConfig, params: Record<string, unknown>): AgentPersona | undefined {
  return (
    normalizePersona(readOptionalString(params, 'persona')) ??
    pluginConfig.persona ??
    normalizePersona(process.env.HILAND_AGENT_PERSONA)
  )
}

function detectOpenClawNickname(pluginConfig: PluginConfig): string | undefined {
  const fromConfig = pluginConfig.nickname
  if (fromConfig) return fromConfig
  const candidates = [
    process.env.OPENCLAW_USER_NICKNAME,
    process.env.OPENCLAW_USER_DISPLAY_NAME,
    process.env.OPENCLAW_USERNAME,
    process.env.USER,
  ]
  for (const c of candidates) {
    if (typeof c === 'string' && c.trim() !== '') return c.trim()
  }
  return undefined
}

function resolveConnectionConfig(
  pluginConfig: PluginConfig,
  params: Record<string, unknown>,
): ResolvedConnectionConfig {
  return {
    agentUrl:
      readOptionalString(params, 'agentUrl') ?? pluginConfig.agentUrl ?? process.env.HILAND_AGENT_URL,
    pat: readOptionalString(params, 'pat') ?? pluginConfig.pat ?? process.env.HILAND_PAT,
    agentBindToken:
      readOptionalString(params, 'agentBindToken') ??
      pluginConfig.agentBindToken ??
      process.env.HILAND_AGENT_BIND_TOKEN,
    strategy: normalizeStrategy(
      readOptionalString(params, 'strategy') ?? pluginConfig.strategy ?? process.env.HILAND_AGENT_STRATEGY,
    ),
    persona: resolvePersonaFromInputs(pluginConfig, params),
    autosubmit: readBoolean(
      params,
      'autosubmit',
      pluginConfig.autosubmit ?? parseBoolean(process.env.HILAND_AGENT_AUTOSUBMIT, false),
    ),
    timeoutMs: Math.max(readInteger(params, 'timeoutMs', 30_000), 1_000),
    advisor: resolveAdvisorEngine(readOptionalString(params, 'advisor') ?? pluginConfig.advisor),
    llm: resolveLLMAdvisorConfig({ ...pluginConfig, ...params }),
  }
}

function resolveBootstrapConfig(pluginConfig: PluginConfig, params: Record<string, unknown>): BootstrapConfig {
  const apiBaseUrl = resolveApiBaseUrl(pluginConfig, params)
  const strategy = normalizeStrategy(
    readOptionalString(params, 'strategy') ?? pluginConfig.strategy ?? process.env.HILAND_AGENT_STRATEGY,
  )
  return {
    apiBaseUrl,
    publicBaseUrl: readOptionalString(params, 'publicBaseUrl'),
    nickname: readOptionalString(params, 'nickname') ?? detectOpenClawNickname(pluginConfig),
    room: readBootstrapRoom(params),
    buyIn: readOptionalInteger(params, 'buyIn'),
    preferredSeat: readOptionalInteger(params, 'preferredSeat'),
    agentLabel: readOptionalString(params, 'agentLabel'),
    strategy,
    persona: resolvePersonaFromInputs(pluginConfig, params),
    autosubmit: readBoolean(
      params,
      'autosubmit',
      pluginConfig.autosubmit ?? parseBoolean(process.env.HILAND_AGENT_AUTOSUBMIT, false),
    ),
    advisor: resolveAdvisorEngine(readOptionalString(params, 'advisor') ?? pluginConfig.advisor),
    llm: resolveLLMAdvisorConfig({ ...pluginConfig, ...params }),
    timeoutMs: Math.max(readInteger(params, 'timeoutMs', 15_000), 1_000),
    connectOnce: readBoolean(params, 'connectOnce', false),
    includeSensitiveDetails: readBoolean(params, 'includeSensitiveDetails', true),
    createMobileEntry: readBoolean(params, 'createMobileEntry', true),
  }
}

function resolveApiBaseUrl(pluginConfig: PluginConfig, params: Record<string, unknown>): string | undefined {
  const explicit = readOptionalString(params, 'apiBaseUrl') ?? pluginConfig.apiBaseUrl ?? process.env.HILAND_API_BASE_URL
  if (explicit) return normalizeHTTPBaseURL(explicit)
  const agentUrl = readOptionalString(params, 'agentUrl') ?? pluginConfig.agentUrl ?? process.env.HILAND_AGENT_URL
  return restBaseFromAgentURL(agentUrl)
}

function readBootstrapRoom(params: Record<string, unknown>): BootstrapRoomInput {
  const room = readObjectParam<Record<string, unknown>>(params, 'room', false) ?? {}
  return removeUndefined({
    name: readOptionalString(params, 'roomName') ?? readOptionalString(room, 'name'),
    maxSeats: readOptionalInteger(params, 'maxSeats') ?? readOptionalInteger(room, 'maxSeats'),
    smallBlind: readOptionalInteger(params, 'smallBlind') ?? readOptionalInteger(room, 'smallBlind'),
    bigBlind: readOptionalInteger(params, 'bigBlind') ?? readOptionalInteger(room, 'bigBlind'),
    minBuyIn: readOptionalInteger(params, 'minBuyIn') ?? readOptionalInteger(room, 'minBuyIn'),
    maxBuyIn: readOptionalInteger(params, 'maxBuyIn') ?? readOptionalInteger(room, 'maxBuyIn'),
  })
}

function mergeCredentialParams(params: Record<string, unknown>): Record<string, unknown> {
  const credentials = readObjectParam<Record<string, unknown>>(params, 'credentials', false)
  if (!credentials) return params
  // Top-level values win over JSON blob values.
  return { ...credentials, ...params }
}

function buildApiWarnings(apiBaseUrl?: string): string[] {
  const warnings: string[] = []
  if (!apiBaseUrl) warnings.push('HILAND_API_BASE_URL / apiBaseUrl is missing and could not be derived from agentUrl.')
  if (apiBaseUrl && !/^https?:\/\//.test(apiBaseUrl)) warnings.push('apiBaseUrl must start with http:// or https://.')
  return warnings
}

/** Shown when LLM config is incomplete so agents guide users without invoking OpenClaw `gateway config.patch` (often rejected for plugin paths). */
const LLM_CONFIG_REMEDIATION_HINT =
  'Remediation: set env vars OpenClaw already uses for chat (e.g. OPENAI_API_KEY with OPENAI_BASE_URL/OPENAI_MODEL if needed, or ANTHROPIC_API_KEY and related), or HILAND_LLM_API_KEY / HILAND_LLM_BASE_URL / HILAND_LLM_MODEL, or configure this plugin in OpenClaw Settings / plugin UI; you may also pass llmBaseUrl, llmApiKey, llmModel (and llmProtocol if non-default) as tool parameters. Do not use gateway config.patch on this plugin’s config paths—they are protected and will be rejected.'

function formatLLMAdvisorMissingMessage(
  prefix: string,
  llm: LLMAdvisorConfig,
): string {
  const missing = listMissingLLMAdvisorRequirements(llm)
  const list = missing.length ? missing.join(', ') : 'unknown'
  return `${prefix} missing: ${list}. ${LLM_CONFIG_REMEDIATION_HINT}`
}

function buildConfigWarnings(config: ResolvedConnectionConfig): string[] {
  const warnings: string[] = []
  if (!config.agentUrl) warnings.push('HILAND_AGENT_URL / agentUrl is missing.')
  if (!config.pat) warnings.push('HILAND_PAT / pat is missing.')
  if (config.agentUrl && !/^wss?:\/\//.test(config.agentUrl)) {
    warnings.push('agentUrl must start with ws:// or wss://.')
  }
  if (config.advisor === 'llm' && !hasRunnableLLMAdvisor(config.llm)) {
    warnings.push(formatLLMAdvisorMissingMessage('LLM advisor is not runnable.', config.llm))
  }
  return warnings
}

function assertRunnableConfig(config: ResolvedConnectionConfig): asserts config is RunnableConnectionConfig {
  const warnings = buildConfigWarnings(config)
  if (warnings.length) {
    throw new Error(warnings.join(' '))
  }
}

function assertBootstrapConfig(config: BootstrapConfig): asserts config is RunnableBootstrapConfig {
  const warnings = buildApiWarnings(config.apiBaseUrl)
  if (warnings.length) throw new Error(warnings.join(' '))
}

function assertRunnableLLMAdvisorForOperation(
  advisor: AdvisorEngine,
  llm: LLMAdvisorConfig,
  operation: 'hiland_poker_agent_decide' | 'hiland_poker_agent_run_once' | 'hiland_poker_agent_bind_web_seat' | 'hiland_poker_agent_bootstrap_room',
): void {
  if (advisor !== 'llm') return
  if (hasRunnableLLMAdvisor(llm)) return
  throw new Error(
    formatLLMAdvisorMissingMessage(`${operation} requires runnable LLM advisor when advisor=llm;`, llm),
  )
}

async function decideWithAdvisor(options: {
  state: MsgGameState
  request?: MsgDecisionRequest
  legalActions: LegalAction[]
  strategy: StrategyName
  advisor: AdvisorEngine
  llm: LLMAdvisorConfig
  persona?: AgentPersona
  personaHandIndex?: number
  nemesisSeat?: number | null
}): Promise<AdvisorDecisionResult> {
  if (options.advisor === 'llm') {
    return decideWithLLMAdvisor({
      state: options.state,
      request: options.request,
      legalActions: options.legalActions,
      strategy: options.strategy,
      config: options.llm,
      persona: options.persona,
      personaHandIndex: options.personaHandIndex,
      nemesisSeat: options.nemesisSeat,
    })
  }

  return {
    ...decideWithBaselineStrategy({
      state: options.state,
      request: options.request,
      legalActions: options.legalActions,
      strategy: options.strategy,
      persona: options.persona,
      personaHandIndex: options.personaHandIndex,
      nemesisSeat: options.nemesisSeat ?? null,
    }),
    source: 'baseline',
  }
}

function resolveAdvisorEngine(value: unknown): AdvisorEngine {
  return value === 'baseline' ? 'baseline' : 'llm'
}

function readLLMProvider(params: Record<string, unknown>, key: string): LLMAdvisorConfig['provider'] | undefined {
  const value = readOptionalString(params, key)?.toLowerCase()
  if (value === 'anthropic' || value === 'anthropic-compatible') return 'anthropic'
  if (value === 'openai' || value === 'openai-compatible') return 'openai-compatible'
  return undefined
}

function readLLMProtocol(params: Record<string, unknown>, key: string): LLMAdvisorConfig['protocol'] | undefined {
  const value = readOptionalString(params, key)?.toLowerCase()
  if (value === 'responses' || value === 'response' || value === 'openai-responses' || value === 'openai_responses') return 'responses'
  if (value === 'messages' || value === 'message' || value === 'anthropic-messages' || value === 'anthropic_messages') return 'messages'
  if (
    value === 'chat-completions' ||
    value === 'chat_completions' ||
    value === 'chat-completion' ||
    value === 'chat_completion' ||
    value === 'openai-chat-completions' ||
    value === 'openai_chat_completions'
  ) {
    return 'chat-completions'
  }
  return undefined
}

function formatLLMAdvisorStatus(config: LLMAdvisorConfig): StatusResult['configured']['llmAdvisor'] {
  return {
    enabled: config.enabled,
    runnable: hasRunnableLLMAdvisor(config),
    provider: config.provider,
    protocol: config.protocol,
    baseUrl: Boolean(config.baseUrl),
    apiKey: Boolean(config.apiKey),
    model: config.model,
    timeoutMs: config.timeoutMs,
  }
}

function formatStatus(result: StatusResult): string {
  const lines = [
    'Hiland Poker Agent plugin status.',
    `apiBaseUrl: ${result.configured.apiBaseUrl ? 'configured' : 'missing'}`,
    `agentUrl: ${result.configured.agentUrl ? 'configured' : 'missing'}`,
    `pat: ${result.configured.pat ? 'configured' : 'missing'}`,
    `agentBindToken: ${result.configured.agentBindToken ? 'configured' : 'missing'}`,
    `strategy: ${result.configured.strategy}`,
    `persona: ${result.configured.persona ?? 'unset'}`,
    `advisor: ${result.configured.advisor}`,
    `autosubmit: ${result.configured.autosubmit ? 'enabled' : 'disabled'}`,
    `llmAdvisor: ${result.configured.llmAdvisor.enabled ? 'enabled' : 'disabled'} (${result.configured.llmAdvisor.runnable ? 'runnable' : 'not runnable'}, protocol=${result.configured.llmAdvisor.protocol}, model=${result.configured.llmAdvisor.model})`,
  ]
  if (result.warnings.length) {
    lines.push('', 'warnings:')
    for (const warning of result.warnings) lines.push(`- ${warning}`)
  }
  return lines.join('\n')
}

function formatBootstrap(result: BootstrapToolResult): string {
  const lines = [
    'Hiland Poker Agent room bootstrapped.',
    `status: ${result.status}`,
    `room: ${result.room.name} (${result.room.id})`,
    `seat: ${result.seat.seatPos}, stack=${result.seat.stack}, buyIn=${result.seat.buyIn}`,
    `owner: ${result.auth.nickname} (${result.auth.userId})`,
    `agentUrl: ${result.agent.agentUrl || 'missing'}`,
    `agentTokenId: ${result.agent.agentTokenId}`,
    `entry link: ${result.links.entryUrlGenerated ? 'generated; auth is in URL fragment and is not printed' : 'missing'}`,
    `mobile entry link: ${result.links.mobileEntryUrlGenerated ? 'generated for phone sign-in; one-time and short-lived' : 'not generated'}`,
    `agent credentials: ${result.agent.patGenerated && result.agent.agentBindTokenGenerated ? 'generated; secrets are not printed' : 'missing'}`,
    `agent bind expires: ${result.agent.agentBindExpiresAt}`,
  ]
  if (result.links.entryUrlRedacted) lines.push(`entry link redacted: ${result.links.entryUrlRedacted}`)
  if (result.links.mobileEntryUrlRedacted) lines.push(`mobile entry redacted: ${result.links.mobileEntryUrlRedacted}`)
  if (result.runOnce) {
    lines.push('', 'connectOnce result:')
    lines.push(indent(formatRunOnce(result.runOnce)))
  }
  return lines.join('\n')
}

function formatBindWebSeat(result: BindWebSeatResult): string {
  const lines = [
    'Hiland Poker web seat credentials accepted.',
    `status: ${result.status}`,
    `agentUrl: ${result.configured.agentUrl ? 'configured' : 'missing'}`,
    `pat: ${result.configured.pat ? 'configured' : 'missing'}`,
    `agentBindToken: ${result.configured.agentBindToken ? 'configured' : 'missing'}`,
    `strategy: ${result.configured.strategy}`,
    `persona: ${result.configured.persona ?? 'unset'}`,
    `advisor: ${result.configured.advisor}`,
    `autosubmit: ${result.configured.autosubmit ? 'enabled' : 'disabled'}`,
  ]
  if (result.warnings.length) {
    lines.push('', 'warnings:')
    for (const warning of result.warnings) lines.push(`- ${warning}`)
  }
  if (result.runOnce) {
    lines.push('', 'runOnce:')
    lines.push(indent(formatRunOnce(result.runOnce)))
  }
  return lines.join('\n')
}

function formatDecision(result: DecideToolResult): string {
  const lines = [
    'Hiland Poker decision computed.',
    `strategy: ${result.strategy}`,
    `persona: ${result.persona ?? 'unset'}`,
    `advisor: ${result.advisor}`,
    `source: ${result.source ?? 'baseline'}`,
    `action: ${result.action}`,
  ]
  if (result.amount !== undefined) lines.push(`amount: ${result.amount}`)
  if (result.kind) lines.push(`kind: ${result.kind}`)
  if (result.confidence !== undefined) lines.push(`confidence: ${result.confidence.toFixed(2)}`)
  if (result.rationale) lines.push(`rationale: ${result.rationale}`)
  if (result.fallbackReason) lines.push(`fallbackReason: ${result.fallbackReason}`)
  return lines.join('\n')
}

function formatRunOnce(result: RunOnceResult): string {
  const lines = ['Hiland Poker Agent run-once finished.', `status: ${result.status}`]
  if (result.mode) lines.push(`mode: ${result.mode}`)
  if (result.requestId) lines.push(`requestId: ${result.requestId}`)
  if (result.action) {
    lines.push(`action: ${result.action.action}`)
    if (result.action.amount !== undefined) lines.push(`amount: ${result.action.amount}`)
    if (result.action.kind) lines.push(`kind: ${result.action.kind}`)
    if (result.action.source) lines.push(`source: ${result.action.source}`)
    if (result.action.confidence !== undefined) lines.push(`confidence: ${result.action.confidence.toFixed(2)}`)
    if (result.action.rationale) lines.push(`rationale: ${result.action.rationale}`)
    if (result.action.fallbackReason) lines.push(`fallbackReason: ${result.action.fallbackReason}`)
  }
  if (result.events.length) {
    lines.push('', 'events:')
    for (const event of result.events) lines.push(`- ${event}`)
  }
  return lines.join('\n')
}

function formatHubResult(result: HubConnectResult): string {
  const lines = ['Hiland Poker Agent hub connection finished.', `status: ${result.status}`]
  if (result.ownerId) lines.push(`ownerId: ${result.ownerId}`)
  if (result.connId) lines.push(`connId: ${result.connId}`)
  if (result.events.length) {
    lines.push('', 'events:')
    for (const e of result.events.slice(-10)) lines.push(`- ${e}`)
  }
  return lines.join('\n')
}

function formatEvent(event: AgentClientEvent): string {
  switch (event.type) {
    case 'connected':
      return 'connected'
    case 'hello':
      return `hello room=${event.message.seat.roomId} seatPos=${event.message.seat.seatPos}`
    case 'game_state':
      return `game_state hand=${event.message.handId} seq=${event.message.stateSeq ?? 'n/a'} actionOn=${event.message.actionOn ?? 'none'}`
    case 'decision_request':
      return `decision_request request=${event.message.requestId} mode=${event.message.mode}`
    case 'action_sent':
      return `action_sent ${event.message.kind} ${event.message.action}`
    case 'action_result':
      return `action_result request=${event.message.requestId} status=${event.message.status}`
    case 'mode_changed':
      return `mode_changed ${event.message.mode}`
    case 'pong':
      return 'pong'
    case 'server_error':
      return `server_error ${event.message.code}: ${userSafeError(event.message.message)}`
    case 'closed':
      return `closed code=${event.code}`
  }
}

function createToolResult<TDetails>(text: string, details: TDetails): ToolResult<TDetails> {
  return {
    content: [{ type: 'text', text }],
    details,
  }
}

async function postJSON<T>(url: string, body: unknown, timeoutMs: number): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body ?? {}),
      signal: controller.signal,
    })
    const text = await response.text()
    let parsed: unknown = undefined
    if (text.trim() !== '') {
      try {
        parsed = JSON.parse(text)
      } catch {
        parsed = text
      }
    }
    if (!response.ok) {
      const msg = apiErrorMessage(parsed) ?? response.statusText
      throw new Error(`HTTP ${response.status}: ${msg}`)
    }
    return parsed as T
  } catch (error) {
    throw new Error(userSafeError(error))
  } finally {
    clearTimeout(timeout)
  }
}

async function postJSONWithAuth<T>(
  url: string,
  body: unknown,
  accessToken: string,
  timeoutMs: number,
): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(body ?? {}),
      signal: controller.signal,
    })
    const text = await response.text()
    let parsed: unknown = undefined
    if (text.trim() !== '') {
      try {
        parsed = JSON.parse(text)
      } catch {
        parsed = text
      }
    }
    if (!response.ok) {
      const msg = apiErrorMessage(parsed) ?? response.statusText
      throw new Error(`HTTP ${response.status}: ${msg}`)
    }
    return parsed as T
  } catch (error) {
    throw new Error(userSafeError(error))
  } finally {
    clearTimeout(timeout)
  }
}

function apiErrorMessage(value: unknown): string | undefined {
  if (!value || typeof value !== 'object') return typeof value === 'string' ? value : undefined
  const record = value as Record<string, unknown>
  return typeof record.message === 'string' ? record.message : undefined
}

function joinURL(base: string, path: string): string {
  return new URL(path, normalizeHTTPBaseURL(base)).toString()
}

function normalizeHTTPBaseURL(value: string): string {
  const trimmed = value.trim()
  const url = new URL(trimmed)
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new Error('apiBaseUrl must start with http:// or https://')
  url.hash = ''
  url.search = ''
  return url.toString().replace(/\/$/, '')
}

function restBaseFromAgentURL(value: string | undefined): string | undefined {
  if (!value) return undefined
  try {
    const url = new URL(value)
    if (url.protocol !== 'ws:' && url.protocol !== 'wss:') return undefined
    url.protocol = url.protocol === 'wss:' ? 'https:' : 'http:'
    url.pathname = ''
    url.search = ''
    url.hash = ''
    return url.toString().replace(/\/$/, '')
  } catch {
    return undefined
  }
}

function originFromBaseURL(value: string): string {
  try {
    const url = new URL(value)
    return `${url.protocol}//${url.host}`
  } catch {
    return value
  }
}

function redactURLSecrets(value: string): string {
  try {
    const url = new URL(value)
    const sensitiveKeys = ['token', 'bind', 'pat', 'grant', 'accessToken', 'agentBindToken', 'mobileGrant']
    for (const key of sensitiveKeys) {
      if (url.searchParams.has(key)) url.searchParams.set(key, '<redacted>')
    }
    if (url.hash) {
      const fragment = new URLSearchParams(url.hash.slice(1))
      let changed = false
      for (const key of sensitiveKeys) {
        if (fragment.has(key)) {
          fragment.set(key, '<redacted>')
          changed = true
        }
      }
      if (changed) url.hash = fragment.toString()
    }
    return url.toString()
  } catch {
    return userSafeError(value)
  }
}

function removeUndefined<T extends Record<string, unknown>>(value: T): T {
  for (const key of Object.keys(value)) {
    if (value[key] === undefined) delete value[key]
  }
  return value
}

function indent(value: string): string {
  return value.split('\n').map((line) => `  ${line}`).join('\n')
}

function asRecord(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return value as Record<string, unknown>
}

function readObjectParam<T>(params: Record<string, unknown>, key: string, required: true): T
function readObjectParam<T>(params: Record<string, unknown>, key: string, required: false): T | undefined
function readObjectParam<T>(params: Record<string, unknown>, key: string, required: boolean): T | undefined {
  const value = params[key]
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    if (required) throw new Error(`${key} is required`)
    return undefined
  }
  return value as T
}

function readOptionalString(params: Record<string, unknown>, key: string) {
  const value = params[key]
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed === '' ? undefined : trimmed
}

function readBoolean(params: Record<string, unknown>, key: string, fallback: boolean) {
  return parseBoolean(params[key], fallback)
}

function readOptionalBoolean(params: Record<string, unknown>, key: string) {
  const value = params[key]
  if (typeof value === 'boolean') return value
  if (typeof value === 'string' && value.trim() !== '') return parseBoolean(value, false)
  return undefined
}

function readInteger(params: Record<string, unknown>, key: string, fallback: number) {
  const value = params[key]
  if (typeof value === 'number' && Number.isFinite(value)) return Math.trunc(value)
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return Math.trunc(parsed)
  }
  return fallback
}

function readOptionalInteger(params: Record<string, unknown>, key: string): number | undefined {
  const value = params[key]
  if (typeof value === 'number' && Number.isFinite(value)) return Math.trunc(value)
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return Math.trunc(parsed)
  }
  return undefined
}

function readOptionalNumber(params: Record<string, unknown>, key: string): number | undefined {
  const value = params[key]
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return undefined
}

function parseBoolean(value: unknown, fallback: boolean) {
  if (typeof value === 'boolean') return value
  if (typeof value !== 'string' || value.trim() === '') return fallback
  const normalized = value.trim().toLowerCase()
  if (['1', 'true', 'yes', 'on'].includes(normalized)) return true
  if (['0', 'false', 'no', 'off'].includes(normalized)) return false
  return fallback
}

function userSafeError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error)
  return message
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, 'Bearer <redacted>')
    .replace(/\bsk-[A-Za-z0-9_-]+\b/g, '<redacted-api-key>')
    .replace(/([?&](?:token|bind|pat|grant|accessToken|agentBindToken|apiKey|llmApiKey)=)[^&\s)]+/gi, '$1<redacted>')
    .replace(/\?(?:token|bind|pat|grant|accessToken|agentBindToken|apiKey|llmApiKey)=[^\s)]+/gi, '?<redacted-query>')
    .replace(/\bhp_(?:pat|bind|mlg)_[A-Za-z0-9_-]+\b/g, '<redacted-hiland-token>')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '<redacted-jwt>')
}
