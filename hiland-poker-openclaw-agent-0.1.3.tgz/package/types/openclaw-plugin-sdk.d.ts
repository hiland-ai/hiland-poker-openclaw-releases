declare module 'openclaw/plugin-sdk/plugin-entry' {
  export type OpenClawPluginApi = {
    pluginConfig?: Record<string, unknown>
    registerTool: (tool: {
      name: string
      label?: string
      description?: string
      parameters?: unknown
      execute: (toolCallId: string, params: unknown) => Promise<unknown> | unknown
    }) => void
  }

  export function definePluginEntry(entry: {
    id: string
    name: string
    description: string
    register: (api: OpenClawPluginApi) => void
  }): unknown
}
