// Wire types shared between Hiland Poker server and any Agent client.
// Mirrors docs/agent-protocol.md (v1).

export type CoopMode =
  | 'advisor'
  | 'default_action'
  | 'auto_with_veto'
  | 'full_auto'

export type Phase = 'preflop' | 'flop' | 'turn' | 'river' | 'showdown' | 'done'

export type ActionKind =
  | 'fold'
  | 'check'
  | 'call'
  | 'bet'
  | 'raise'
  | 'allin'

export type ActionSubmitKind = 'suggestion' | 'submit'

export type PassiveLegalAction = {
  action: 'fold' | 'check'
}

export type FixedAmountLegalAction = {
  action: 'call' | 'allin'
  amount?: number
}

export type RangedAmountLegalAction = {
  action: 'bet' | 'raise'
  amount?: number
  minAmount?: number
  maxAmount?: number
}

export type LegalAction =
  | PassiveLegalAction
  | FixedAmountLegalAction
  | RangedAmountLegalAction

export interface AgentCapabilities {
  modes: CoopMode[]
  actions: ActionKind[]
}

// ---- Inbound (Server → Agent) -----------------------------------------------

export interface MsgHello {
  type: 'hello'
  protocol: 'hiland-poker-agent/1'
  // Server-assigned per-connection id, useful for log correlation.
  connId: string
  ownerId?: string
  serverTime?: number
  capabilities?: AgentCapabilities
  // Seat the agent is bound to.
  seat: { roomId: string; seatPos: number }
}

export interface MsgGameState {
  type: 'game_state'
  stateSeq?: number
  roomId?: string
  handId: string
  phase: Phase
  yourSeat: number
  yourHole: [string, string] | null
  board: string[]
  pot: number
  toCall: number
  minRaise: number
  stacks: Record<number, number>
  actionOn: number | null
  deadlineMs: number | null
  mode: CoopMode
  legalActions?: LegalAction[]
}

export interface MsgDecisionRequest {
  type: 'decision_request'
  stateSeq?: number
  handId: string
  requestId: string
  mode: CoopMode
  decisionWindowMs: number
  legalActions?: LegalAction[]
}

export interface MsgActionResult {
  type: 'action_result'
  requestId: string
  status: 'accepted' | 'queued_for_veto' | 'executed' | 'rejected'
  kind?: ActionSubmitKind
  error?: MsgError
}

export interface MsgModeChanged {
  type: 'mode_changed'
  mode: CoopMode
  reason?: string
}

export interface MsgPong {
  type: 'pong'
  ts: number
}

export interface MsgError {
  type: 'error'
  code: string
  message: string
  requestId?: string
}

export type Inbound =
  | MsgHello
  | MsgGameState
  | MsgDecisionRequest
  | MsgActionResult
  | MsgModeChanged
  | MsgPong
  | MsgError

// ---- Outbound (Agent → Server) ----------------------------------------------

export interface OutAction {
  type: 'action'
  requestId: string
  // State sequence this action was based on. Server may reject stale values.
  stateSeq?: number
  action: ActionKind
  amount?: number
  // 'suggestion' = Advisor / DefaultAction modes; the Owner still decides.
  // 'submit'     = AutoVeto / FullAuto modes; goes straight into the engine.
  kind: ActionSubmitKind
  confidence?: number
  rationale?: string
}

export interface OutPing {
  type: 'ping'
  ts: number
}

export type Outbound = OutAction | OutPing
