// Wire types shared between Hiland Poker server and any Agent client.
// Mirrors docs/agent-protocol.md (v1).

export type CoopMode =
  | 'advisor'
  | 'default_action'
  | 'auto_with_veto'
  | 'full_auto'

export type Phase = 'preflop' | 'flop' | 'turn' | 'river' | 'showdown' | 'done'

export type ActionKind =
  | 'fold'
  | 'check'
  | 'call'
  | 'bet'
  | 'raise'
  | 'allin'

export type ActionSubmitKind = 'suggestion' | 'submit'

export type PassiveLegalAction = {
  action: 'fold' | 'check'
}

export type FixedAmountLegalAction = {
  action: 'call' | 'allin'
  amount?: number
}

export type RangedAmountLegalAction = {
  action: 'bet' | 'raise'
  amount?: number
  minAmount?: number
  maxAmount?: number
}

export type LegalAction =
  | PassiveLegalAction
  | FixedAmountLegalAction
  | RangedAmountLegalAction

export interface AgentCapabilities {
  modes: CoopMode[]
  actions: ActionKind[]
}

// ---- Inbound (Server → Agent) -----------------------------------------------

export interface MsgHello {
  type: 'hello'
  protocol: 'hiland-poker-agent/1'
  // Server-assigned per-connection id, useful for log correlation.
  connId: string
  ownerId?: string
  serverTime?: number
  capabilities?: AgentCapabilities
  // Seat the agent is bound to.
  seat: { roomId: string; seatPos: number }
}

/** Per-seat contribution on the current betting street (room seat index). */
export interface AgentSeatBet {
  seat: number
  bet: number
}

/** One row in the hand transcript (blinds + actions), seats are room positions. */
export interface AgentHandAction {
  phase: string
  seat: number
  kind: string
  chips: number
  streetBet: number
  tableBet: number
  allIn?: boolean
}

/** Main or side pot; eligible seats are room positions. */
export interface AgentPotLayer {
  amount: number
  eligibleSeats: number[]
}

export interface MsgGameState {
  type: 'game_state'
  stateSeq?: number
  roomId?: string
  handId: string
  phase: Phase
  yourSeat: number
  yourHole: [string, string] | null
  board: string[]
  pot: number
  toCall: number
  minRaise: number
  stacks: Record<number, number>
  /** Public seat nicknames keyed by room seat index. */
  nicknames?: Record<number, string>
  actionOn: number | null
  deadlineMs: number | null
  mode: CoopMode
  legalActions?: LegalAction[]
  /** Room seat index of the dealer button. */
  buttonSeat?: number
  smallBlindSeat?: number
  bigBlindSeat?: number
  smallBlind?: number
  bigBlind?: number
  /** Reserved; omitted when 0 / unsupported. */
  ante?: number
  /** Highest wager to match on this street (facing = streetMaxBet − hero street bet). */
  streetMaxBet?: number
  /** Minimum legal raise increment (last full raise size). */
  lastRaiseDelta?: number
  anyAllIn?: boolean
  foldedSeats?: number[]
  activeSeats?: number[]
  streetBets?: AgentSeatBet[]
  actionLog?: AgentHandAction[]
  pots?: AgentPotLayer[]
}

export interface MsgDecisionRequest {
  type: 'decision_request'
  stateSeq?: number
  handId: string
  requestId: string
  mode: CoopMode
  decisionWindowMs: number
  legalActions?: LegalAction[]
}

export interface MsgActionResult {
  type: 'action_result'
  requestId: string
  status: 'accepted' | 'queued_for_veto' | 'executed' | 'rejected'
  kind?: ActionSubmitKind
  error?: MsgError
}

export interface MsgModeChanged {
  type: 'mode_changed'
  mode: CoopMode
  reason?: string
}

export interface MsgPong {
  type: 'pong'
  ts: number
}

export interface MsgError {
  type: 'error'
  code: string
  message: string
  requestId?: string
}

export type CoachScope = 'hand' | 'session' | 'persistent'

/**
 * Server→Agent coaching instruction. The agent should ack with `coach_ack`.
 * Coaching is layered on top of the existing decision flow and only takes
 * effect when advisor=llm/agent.
 */
export interface MsgCoach {
  type: 'coach'
  coachId: string
  scope: CoachScope
  text: string
  lang?: string
  issuedAt: number
}

/**
 * Server→Agent on (re)connect: the persistent coaching notes previously
 * stored on the AgentProfile. Agent should seed its CoachingState.persistent
 * bucket with these.
 */
export interface MsgCoachHistoryEntry {
  coachId: string
  text: string
  createdAt: number
}

export interface MsgCoachHistory {
  type: 'coach_history'
  notes: MsgCoachHistoryEntry[]
}

export type Inbound =
  | MsgHello
  | MsgGameState
  | MsgDecisionRequest
  | MsgActionResult
  | MsgModeChanged
  | MsgPong
  | MsgError
  | MsgCoach
  | MsgCoachHistory

// ---- Outbound (Agent → Server) ----------------------------------------------

export interface OutAction {
  type: 'action'
  requestId: string
  // State sequence this action was based on. Server may reject stale values.
  stateSeq?: number
  action: ActionKind
  amount?: number
  // 'suggestion' = Advisor / DefaultAction modes; the Owner still decides.
  // 'submit'     = AutoVeto / FullAuto modes; goes straight into the engine.
  kind: ActionSubmitKind
  confidence?: number
  rationale?: string
}

export interface OutPing {
  type: 'ping'
  ts: number
}

export interface OutCoachAck {
  type: 'coach_ack'
  coachId: string
  ok: boolean
  error?: string
  /** Short, human-readable confirmation rendered in the Owner UI. */
  summary?: string
  /** Optional structured hints applied (e.g. {strategyTilt:'+aggressive', targetSeats:[3]}). */
  appliedHints?: Record<string, unknown>
}

export type Outbound = OutAction | OutPing | OutCoachAck
