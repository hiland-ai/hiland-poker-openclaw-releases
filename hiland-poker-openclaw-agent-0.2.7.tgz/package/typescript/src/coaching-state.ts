// CoachingState is the per-agent in-memory store of Owner-issued coaching notes.
// It is layered on top of decision making and only consulted when advisor=llm/agent.
//
// Three buckets, by retention scope:
//   - hand:       active during the current hand. Cleared on hand transition.
//   - session:    active until the agent disconnects or owner clears it.
//   - persistent: re-seeded by the server on (re)connect via `coach_history`.
//                 The server is responsible for DB persistence; the agent only
//                 needs to apply them in-memory.
//
// `__clear__` is a sentinel text the server sends to wipe a single scope bucket.

import type { CoachScope, MsgCoachHistoryEntry } from './types.js'

export interface CoachingNote {
  coachId: string
  scope: CoachScope
  text: string
  createdAt: number
}

export interface ApplyCoachInput {
  coachId: string
  scope: CoachScope
  text: string
  createdAt?: number
}

export interface ApplyCoachResult {
  ok: boolean
  summary: string
  appliedHints: Record<string, unknown>
  cleared: boolean
}

export interface CoachingPromptSection {
  /** Multi-line block to append to the LLM system prompt, or '' if no notes. */
  text: string
  noteCount: number
}

const MAX_NOTES_PER_SCOPE = 8
const CLEAR_SENTINEL = '__clear__'

/**
 * StrategyTilt is a coarse, structured aggregation of Owner intent that the
 * agent surfaces in the ack summary. It is informational only — actual style
 * adjustments happen via free-text injection into the LLM prompt.
 */
type StrategyTilt = 'aggressive' | 'tight' | 'balanced' | 'mixed'

const AGGRESSIVE_HINTS = [
  '激进',
  '更激进',
  '加注',
  '抢',
  '压',
  '打死',
  'aggressive',
  'raise more',
  'attack',
]
const TIGHT_HINTS = ['保守', '收紧', '紧', '少打', '弃', 'tight', 'fold more', 'conservative']
const TARGET_SEAT_RE = /seat\s*(\d+)|座(?:位)?\s*(\d+)|(\d+)\s*号位/gi

export class CoachingState {
  private hand: CoachingNote[] = []
  private session: CoachingNote[] = []
  private persistent: CoachingNote[] = []
  private currentHandId: string | null = null

  /** Replace the persistent bucket with the supplied notes (used on connect). */
  seedPersistent(notes: MsgCoachHistoryEntry[]): void {
    this.persistent = (notes || [])
      .filter((entry) => typeof entry.text === 'string' && entry.text.trim() !== '')
      .map((entry) => ({
        coachId: entry.coachId,
        scope: 'persistent' as CoachScope,
        text: entry.text,
        createdAt: entry.createdAt || Date.now(),
      }))
      .slice(-MAX_NOTES_PER_SCOPE)
  }

  /** Drop hand-scoped notes when a new hand begins. */
  observeHandId(handId: string | undefined): void {
    if (!handId) return
    if (this.currentHandId !== null && this.currentHandId !== handId) {
      this.hand = []
    }
    this.currentHandId = handId
  }

  /** Apply one coach instruction. Returns the ack-ready summary/hints. */
  apply(input: ApplyCoachInput): ApplyCoachResult {
    const text = (input.text || '').trim()
    if (!text) {
      return { ok: false, summary: '空指令已忽略', appliedHints: {}, cleared: false }
    }
    if (text === CLEAR_SENTINEL) {
      this.clear(input.scope)
      return {
        ok: true,
        summary: scopeLabel(input.scope) + '调教已清空',
        appliedHints: { cleared: input.scope },
        cleared: true,
      }
    }
    const note: CoachingNote = {
      coachId: input.coachId,
      scope: input.scope,
      text,
      createdAt: input.createdAt ?? Date.now(),
    }
    const bucket = this.bucketFor(input.scope)
    bucket.push(note)
    while (bucket.length > MAX_NOTES_PER_SCOPE) bucket.shift()

    const tilt = detectTilt(text)
    const targetSeats = detectTargetSeats(text)
    const summary = buildSummary(input.scope, tilt, targetSeats, text)
    const hints: Record<string, unknown> = { scope: input.scope }
    if (tilt !== 'balanced') hints.strategyTilt = tilt
    if (targetSeats.length > 0) hints.targetSeats = targetSeats
    return { ok: true, summary, appliedHints: hints, cleared: false }
  }

  /** Wipe one bucket (or all if scope is undefined). */
  clear(scope?: CoachScope): void {
    if (scope === 'hand') {
      this.hand = []
      return
    }
    if (scope === 'session') {
      this.session = []
      return
    }
    if (scope === 'persistent') {
      this.persistent = []
      return
    }
    this.hand = []
    this.session = []
    this.persistent = []
  }

  /**
   * Build the system-prompt block describing all active coaching notes.
   * Persistent notes come first (lowest priority), then session, then hand
   * (highest priority — most recent intent).
   */
  buildPromptSection(language: 'zh-CN' | 'en' = 'zh-CN'): CoachingPromptSection {
    const ordered: CoachingNote[] = [...this.persistent, ...this.session, ...this.hand]
    if (ordered.length === 0) return { text: '', noteCount: 0 }
    const header =
      language === 'en'
        ? 'Owner coaching (most-specific last; later overrides earlier; treat as soft preference, never violate game rules):'
        : '机主调教（后写覆盖先写；视作软偏好，不能违反规则）:'
    const lines = ordered.map((note, index) => {
      const tag = note.scope === 'hand' ? '[hand]' : note.scope === 'session' ? '[session]' : '[persistent]'
      return `${index + 1}. ${tag} ${truncate(note.text, 240)}`
    })
    return { text: [header, ...lines].join('\n'), noteCount: ordered.length }
  }

  snapshot(): {
    hand: CoachingNote[]
    session: CoachingNote[]
    persistent: CoachingNote[]
  } {
    return {
      hand: this.hand.slice(),
      session: this.session.slice(),
      persistent: this.persistent.slice(),
    }
  }

  private bucketFor(scope: CoachScope): CoachingNote[] {
    if (scope === 'hand') return this.hand
    if (scope === 'session') return this.session
    return this.persistent
  }
}

function detectTilt(text: string): StrategyTilt {
  const lower = text.toLowerCase()
  const aggressive = AGGRESSIVE_HINTS.some((kw) => lower.includes(kw.toLowerCase()))
  const tight = TIGHT_HINTS.some((kw) => lower.includes(kw.toLowerCase()))
  if (aggressive && tight) return 'mixed'
  if (aggressive) return 'aggressive'
  if (tight) return 'tight'
  return 'balanced'
}

function detectTargetSeats(text: string): number[] {
  const seats = new Set<number>()
  let m: RegExpExecArray | null
  TARGET_SEAT_RE.lastIndex = 0
  while ((m = TARGET_SEAT_RE.exec(text))) {
    const value = m[1] ?? m[2] ?? m[3]
    const seat = Number(value)
    if (Number.isFinite(seat) && seat >= 0 && seat < 32) seats.add(seat)
  }
  return Array.from(seats).sort((a, b) => a - b)
}

function buildSummary(scope: CoachScope, tilt: StrategyTilt, seats: number[], text: string): string {
  const scopeLabelText = scopeLabel(scope)
  const parts: string[] = [`已采纳·${scopeLabelText}`]
  if (tilt === 'aggressive') parts.push('偏激进')
  else if (tilt === 'tight') parts.push('偏保守')
  else if (tilt === 'mixed') parts.push('风格混合')
  if (seats.length > 0) parts.push(`针对座位 ${seats.join(',')}`)
  if (parts.length === 1) parts.push(truncate(text, 36))
  return parts.join('·')
}

function scopeLabel(scope: CoachScope): string {
  if (scope === 'hand') return '本手'
  if (scope === 'session') return '本局'
  return '永久'
}

function truncate(s: string, n: number): string {
  return s.length <= n ? s : s.slice(0, n - 1) + '…'
}
