// Trivial reference Agent: always check when free, otherwise fold.
// Useful as a smoke-test bot once the agent endpoint is live.

import { AgentClient } from '../typescript/src/client.js'

const URL = process.env.HILAND_AGENT_URL ?? 'wss://localhost:8080/agent'
const PAT = process.env.HILAND_PAT ?? ''
const SEAT = process.env.HILAND_SEAT_TOKEN ?? ''
const AUTOSUBMIT = process.env.HILAND_AGENT_AUTOSUBMIT === 'true'

const agent = new AgentClient({
  url: URL,
  pat: PAT,
  seatBindToken: SEAT,
  autosubmit: AUTOSUBMIT,
  decide: ({ state }) => {
    if (state.toCall === 0) return { action: 'check', rationale: 'Free check available.' }
    return { action: 'fold', rationale: 'Smoke-test bot folds to pressure.' }
  },
  onEvent: (event) => {
    if (event.type === 'hello') {
      console.log(`agent bound to room=${event.message.seat.roomId} seat=${event.message.seat.seatPos}`)
    }
    if (event.type === 'action_sent') {
      console.log(`sent ${event.message.kind}: ${event.message.action}`)
    }
  },
  onError: (e) => console.error('agent error:', e.message),
})

await agent.start()
console.log('check-or-fold agent connected and waiting...')
