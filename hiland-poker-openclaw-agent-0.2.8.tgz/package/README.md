# Hiland Poker — Agent SDK / OpenClaw Agent

Anything you need to write an Agent that sits in the Agent half of a Hiland Poker seat.


| Path                                           | What it is                                                                                                                    |
| ---------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| `[index.ts](index.ts)`                         | Native OpenClaw plugin entry. Registers Hiland Poker Agent tools.                                                             |
| `[openclaw.plugin.json](openclaw.plugin.json)` | OpenClaw plugin manifest/config schema.                                                                                       |
| `[typescript/](typescript)`                    | Strongly-typed TS SDK (`AgentClient`, wire types, baseline strategy, optional LLM advisor) usable from any Node ≥ 20 program. |
| `[openclaw-skill/](openclaw-skill)`            | Reference OpenClaw skill instructions.                                                                                        |
| `[examples/](examples)`                        | Tiny standalone bots (e.g. `check-or-fold.ts`) used for smoke testing.                                                        |


The wire protocol the SDK speaks is documented in `[../docs/agent-protocol.md](../docs/agent-protocol.md)`. Server `game_state` may include table context (`buttonSeat`, blinds, `streetBets`, `actionLog`, `pots`, `activeSeats` / `foldedSeats`, etc.); see §3.1 there. TypeScript `MsgGameState` in `[typescript/src/types.ts](typescript/src/types.ts)` mirrors these fields.

## OpenClaw plugin tools

The plugin registers three tools:

- `hiland_poker_agent_status` — checks config presence without revealing secrets; when a long-lived `/agent` session exists in this OpenClaw process, `details.ownerWsActivity` includes **inbound** and **outbound** WebSocket log tails (ring buffers). Pass `includeWsLogDetail: true` for full tails in the tool text output.
- `hiland_poker_agent_decide` — computes one local action suggestion from a `game_state` / optional `decision_request`; no server connection. With `advisor: "llm"`, it may call the configured LLM provider.
- `hiland_poker_agent_connect` — establishes a long-lived owner-bound connection on `/agent` for observability and continuous decision flow; on connect it reports effective `llmProtocol` / `llmModel` / `llmBaseUrl` (base URL redacted).

Safety defaults:

- `autosubmit` is off, so even auto-capable modes emit `kind: "suggestion"` unless explicitly enabled.
- `advisor` defaults to `llm`.
- In decision/connection entry points (`decide`, `connect`), `advisor: "llm"` now requires runnable LLM config (`llmBaseUrl`, `llmApiKey`, `llmModel`). Missing items cause a clear error and execution is rejected.
- Tool text output never prints PATs, JWTs, LLM API keys, or full token-bearing URLs.

## Configuration

Use OpenClaw plugin config or environment variables:


| Config key       | Env var                                                                                | Required           | Notes                                                                                                                                                                                                                                                                         |
| ---------------- | -------------------------------------------------------------------------------------- | ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `apiBaseUrl`     | `HILAND_API_BASE_URL`                                                                  | no                 | REST API origin used by status/connect fallbacks, e.g. `https://example.com`. If omitted, the plugin can derive it from `agentUrl`.                                                                                                                                           |
| `nickname`       | `OPENCLAW_USER_NICKNAME` / `OPENCLAW_USER_DISPLAY_NAME` / `OPENCLAW_USERNAME` / `USER` | no                 | Optional owner display name used in agent handshake metadata.                                                                                                                                                                                                                 |
| `agentUrl`       | `HILAND_AGENT_URL`                                                                     | yes for connecting | WebSocket endpoint, e.g. `wss://example.com/agent`.                                                                                                                                                                                                                           |
| `pat`            | `HILAND_PAT`                                                                           | yes for connecting | Owner Personal Access Token. Keep secret.                                                                                                                                                                                                                                     |
| `strategy`       | `HILAND_AGENT_STRATEGY`                                                                | no                 | Baseline fallback style: `conservative`, `balanced`, or `aggressive`; default `balanced`.                                                                                                                                                                                     |
| `persona`        | `HILAND_AGENT_PERSONA`                                                                 | no                 | Playstyle: `gto_cold`, `mad_dog`, `exploit`, `turtle`, `grudge`, `learning`, `trash_talk` (supports Chinese aliases like `疯狗`, `嘴炮`). Shapes baseline heuristics and LLM system instructions; `learning` rotates conservative→balanced→aggressive by hands observed per room. |
| `advisor`        | n/a                                                                                    | no                 | `baseline` or `llm`; default `llm`. Tool params can override this per decision/run.                                                                                                                                                                                           |
| `autosubmit`     | `HILAND_AGENT_AUTOSUBMIT`                                                              | no                 | `true` only when the Owner explicitly wants auto-play.                                                                                                                                                                                                                        |
| `llmProvider`    | `HILAND_LLM_ADVISOR_PROVIDER`                                                          | no                 | `openai-compatible` or `anthropic`; inferred from `llmProtocol` when omitted.                                                                                                                                                                                                 |
| `llmProtocol`    | `HILAND_LLM_PROTOCOL` / `OPENAI_PROTOCOL` / `ANTHROPIC_PROTOCOL`                       | no                 | `responses` = OpenAI Responses; `messages` = Anthropic Messages; `chat-completions` = OpenAI-compatible chat completions; default `responses`.                                                                                                                                |
| `llmBaseUrl`     | `HILAND_LLM_BASE_URL` / `OPENAI_BASE_URL` / `ANTHROPIC_BASE_URL`                       | no                 | Defaults to `https://api.openai.com/v1` for OpenAI protocols or `https://api.anthropic.com/v1` for Anthropic Messages. The SDK appends the endpoint for the selected protocol.                                                                                                |
| `llmApiKey`      | `HILAND_LLM_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`                          | yes for LLM        | Keep secret. Never put this in prompts or logs.                                                                                                                                                                                                                               |
| `llmModel`       | `HILAND_LLM_MODEL` / `OPENAI_MODEL` / `ANTHROPIC_MODEL`                                | no                 | Default `gpt-5.4-mini` for OpenAI protocols or `claude-3-5-haiku-latest` for Anthropic Messages.                                                                                                                                                                               |
| `llmTimeoutMs`   | `HILAND_LLM_TIMEOUT_MS`                                                                | no                 | Default `60000` (60s, aligned with the room's 75s action timeout); minimum `500`.                                                                                                                                                                                             |
| `llmTemperature` | `HILAND_LLM_TEMPERATURE`                                                               | no                 | Default `0.15`; clamped `0..1`.                                                                                                                                                                                                                                               |
| `llmMaxTokens`   | `HILAND_LLM_MAX_TOKENS`                                                                | no                 | Default `220`; clamped `80..1000`.                                                                                                                                                                                                                                            |
| `llmLanguage`    | `HILAND_LLM_LANGUAGE`                                                                  | no                 | `zh-CN` or `en`; default `zh-CN`.                                                                                                                                                                                                                                             |
| `llmThinking`    | `HILAND_LLM_THINKING`                                                                  | no                 | Reasoning depth for thinking-capable models. `off` (default) sends a normal request. `low` / `medium` / `high` map to OpenAI `reasoning.effort` / `reasoning_effort`, or Anthropic `thinking.budget_tokens` (≈2048 / 8192 / 16384). Anthropic auto-forces `temperature=1`.    |

### Agent WebSocket diagnostics (optional)

These apply to the OpenClaw plugin’s long-lived `hiland_poker_agent_connect` session (`/agent`). They do **not** print PATs or LLM API keys; verbose JSON still includes **hole cards** only as `[hole:redacted]` in the compact `game_state` preview.

| Env var | Default | Purpose |
| --- | --- | --- |
| `HILAND_AGENT_LOG_TAIL_MAX` | `48` | Ring-buffer size (8–2000) for inbound + outbound log lines kept in memory and returned in `hiland_poker_agent_status` `details`. |
| `HILAND_AGENT_LOG_FILE` | (unset) | Append every log line (ISO + `[in]`/`[out]` + summary) to this file path. |
| `HILAND_AGENT_LOG_STDERR` | off | Set to `1` / `true` / `yes` to mirror the same lines to stderr (OpenClaw host logs). |
| `HILAND_AGENT_LOG_VERBOSE` | off | Set to `1` / `true` or use `HILAND_AGENT_LOG_LEVEL=debug` to add an extra `:raw` line per frame (truncated JSON; `game_state` is slimmed). |

Call **`hiland_poker_agent_status`** with `{ "includeWsLogDetail": true }` to print the **full** inbound/outbound tails in the tool’s text reply (otherwise the text summary shows the last 24 lines per direction; `details` in the tool response always carries the full buffers up to `tailMax`).


## LLM advisor

`llm-advisor` converts the latest visible `game_state` and `decision_request` into a compact no-limit Hold'em decision object, calls the selected LLM endpoint, and validates the response before sending anything to Hiland Poker. It supports these protocol shapes:

- `llmProtocol: "responses"` — OpenAI Responses protocol, `POST {llmBaseUrl}/responses`, using `instructions`, `input`, and `max_output_tokens`.
- `llmProtocol: "messages"` — Anthropic Messages protocol, `POST {llmBaseUrl}/messages`, using `system`, `messages`, `max_tokens`, `x-api-key`, and `anthropic-version`.
- `llmProtocol: "chat-completions"` — OpenAI-compatible chat completions, `POST {llmBaseUrl}/chat/completions`, using `messages`, `max_tokens`, and `response_format`.

Expected model response:

```json
{"action":"call","amount":200,"confidence":0.68,"rationale":"赔率合适，继续看下一街。"}
```

Hard guards:

- The selected action must exist in `legalActions`.
- `bet` / `raise` amounts must be integers within `minAmount..maxAmount`.
- `call` / `allin` use the server-provided amount.
- Stale hand/state, missing hole cards, no legal actions, HTTP/model errors, non-JSON, or illegal JSON fallback to baseline.
- Missing required LLM runtime config (`llmBaseUrl`, `llmApiKey`, `llmModel`) is treated as configuration error at entry and will fail fast instead of silently falling back. Errors include remediation: use OpenClaw/chat env (`OPENAI_*`, `ANTHROPIC_*`, `HILAND_LLM_*`), plugin Settings, or per-call tool params—**not** `gateway config.patch` (protected plugin paths are rejected).
- Rationale is short and user-facing; API keys and token-bearing URLs are redacted from errors.

## Coaching (Owner voice/text directives)

The plugin maintains a `CoachingState` (see `typescript/src/coaching-state.ts`) with three buckets — `hand`, `session`, `persistent` — populated by server-routed `coach` messages. On reconnect, the server pushes the persistent bucket via `coach_history` so long-term tone/persona tweaks survive restarts.

How it integrates with decision making:

- Coaching is a soft prompt addendum, only consulted when `advisor=llm`. With `advisor=baseline`, the agent rejects coaching with `coach_advisor_required`.
- During `decision_request` the buckets are concatenated `persistent → session → hand` (later overrides earlier) and appended to the LLM system prompt below the persona / strategy guidance.
- The agent never bypasses `legalActions`. Owner coaching cannot force an illegal action.
- Each `coach` is acknowledged with a short `coach_ack.summary` (e.g. `已采纳·本局·偏激进·针对座位 3`) and structured `appliedHints` derived from L1 keyword parsing — no extra LLM round trip.
- Server is the only writer of `AgentProfile.coachingNotes`; the agent never persists by itself.

See `docs/agent-protocol.md §3.8/3.9/4.5/4.6` for the wire format and `docs/architecture.md §5.1` for the end-to-end control link.

## Local validation

```bash
npm install
npm --prefix typescript install
npm run typecheck
npm run sdk:typecheck
npm run build
```

## Standalone SDK smoke bot

```bash
export HILAND_AGENT_URL='wss://example.com/agent'
export HILAND_PAT='...'
npm run example:check-or-fold
```

For one-off execution without installing root dev dependencies, you can also run `npx tsx examples/check-or-fold.ts`.

`check-or-fold.ts` remains intentionally simple: check when free, otherwise fold.