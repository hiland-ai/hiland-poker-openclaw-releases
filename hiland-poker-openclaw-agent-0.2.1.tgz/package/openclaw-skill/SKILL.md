---
name: hiland-poker-agent
description: Use this skill when the user wants OpenClaw to join a Hiland Poker seat as an Agent/co-pilot, connect to Hiland Poker via PAT and AgentBindToken, observe game_state, provide poker action suggestions, or submit actions in permitted auto modes.
---

# Hiland Poker Agent

This skill lets OpenClaw act as the Agent half of an Owner+Agent Hiland Poker seat.

## Safety defaults

- Default to `kind: "suggestion"`; do not auto-submit unless the user explicitly asks and the server mode allows it.
- Never reveal `HILAND_PAT`, `HILAND_AGENT_BIND_TOKEN`, JWTs, or full URLs containing tokens.
- Treat the server as authoritative. Only act on the latest `game_state` and `decision_request`.
- Never infer or claim hidden cards for other seats.
- If credentials are missing or expired, ask the user to generate a new PAT / AgentBindToken in the Hiland web client.

## Configuration

Read credentials from secure OpenClaw env/vault/config:

| Key | Required | Description |
| --- | --- | --- |
| `HILAND_API_BASE_URL` | no | REST API origin used by status/connect fallback, e.g. `https://hiland.example.com`; can be derived from `HILAND_AGENT_URL` when omitted |
| `HILAND_AGENT_URL` | yes for connecting | Agent WebSocket endpoint, e.g. `wss://hiland.example.com/agent` |
| `HILAND_PAT` | yes for connecting | Owner Personal Access Token from Hiland web client |
| `HILAND_AGENT_BIND_TOKEN` | yes for connecting | Short-lived token bound to the owner identity |
| `HILAND_AGENT_STRATEGY` | no | Baseline fallback style: `conservative`, `balanced`, or `aggressive`; default `balanced` |
| `HILAND_AGENT_PERSONA` | no | Playstyle overlay: `gto_cold`, `mad_dog`, `exploit`, `turtle`, `grudge`, `learning`, `trash_talk` (or Chinese aliases e.g. `疯狗`, `嘴炮`). Combines with `strategy` / LLM prompts; `learning` persists a per-room hand counter under `~/.hiland-poker/persona-runtime.json`. |
| `HILAND_AGENT_AUTOSUBMIT` | no | `true` only when the user explicitly wants auto-play |
| `HILAND_LLM_ADVISOR_PROVIDER` | no | `openai-compatible` or `anthropic`; inferred from `llmProtocol` when omitted |
| `HILAND_LLM_PROTOCOL` / `OPENAI_PROTOCOL` / `ANTHROPIC_PROTOCOL` | no | `responses` for OpenAI Responses, `messages` for Anthropic Messages, or `chat-completions` for OpenAI-compatible chat completions; default `responses` |
| `HILAND_LLM_BASE_URL` / `OPENAI_BASE_URL` / `ANTHROPIC_BASE_URL` | no | Base URL; defaults to `https://api.openai.com/v1` for OpenAI protocols or `https://api.anthropic.com/v1` for Anthropic Messages |
| `HILAND_LLM_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` | yes for LLM | LLM API key. Never print this value. |
| `HILAND_LLM_MODEL` / `OPENAI_MODEL` / `ANTHROPIC_MODEL` | no | LLM model; defaults to `gpt-4o-mini` for OpenAI protocols or `claude-3-5-haiku-latest` for Anthropic Messages |
| `HILAND_LLM_TIMEOUT_MS` | no | LLM timeout; default `3500` |
| `HILAND_LLM_TEMPERATURE` | no | Default `0.15` |
| `HILAND_LLM_MAX_TOKENS` | no | Default `220` |
| `HILAND_LLM_LANGUAGE` | no | `zh-CN` or `en`; default `zh-CN` |

When LLM config is incomplete, tell the user how to fix it using **OpenClaw environment variables** (same keys OpenClaw often uses for chat, e.g. `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`), **`HILAND_LLM_*`**, **plugin Settings / UI**, or **per-tool parameters** (`llmBaseUrl`, `llmApiKey`, `llmModel`, …). **Do not** suggest `gateway config.patch` for this plugin’s config paths—OpenClaw treats them as protected and the patch will be rejected.

## OpenClaw plugin tools

Prefer the native plugin tools when available:

| Tool | Use |
| --- | --- |
| `hiland_poker_agent_status` | Validate config presence without printing secrets. Pass `includeWsInboundTail: true` to see recent inbound `/agent` frames (e.g. `decision_request`) for the long-lived session in this OpenClaw process. |
| `hiland_poker_agent_decide` | Compute one local suggestion from `game_state` / optional `decision_request`; no Hiland server connection. With `advisor: "llm"`, it may call the configured LLM provider. |
| `hiland_poker_agent_connect` | Long-lived owner-bound WebSocket on `GET /agent` (presence + table stream when seated). Connect result includes effective `llmProtocol` / `llmModel` / `llmBaseUrl` (URL redacted). |

## Workflow

1. Call `hiland_poker_agent_status` before connecting if the user has not just provided config.
2. Connect to `HILAND_AGENT_URL` using query params `token=<HILAND_PAT>&bind=<HILAND_AGENT_BIND_TOKEN>`.
3. Wait for `hello` with protocol `hiland-poker-agent/1`.
4. Store the latest `game_state` in working memory.
5. On `decision_request`, choose one legal action from `legalActions`.
6. Send `action` with:
   - `kind: "suggestion"` in `advisor` and `default_action` modes.
   - `kind: "submit"` only in `auto_with_veto` or `full_auto`, and only if autosubmit was explicitly enabled.
7. Send `ping` every 20 seconds while connected.
8. On `error`, report a concise user-safe message and suggest the next fix.

## Decision contract

When deciding, use exactly this internal shape:

```json
{
  "action": "fold | check | call | bet | raise | allin",
  "amount": 0,
  "kind": "suggestion | submit",
  "confidence": 0.0,
  "rationale": "<= 240 chars, user-facing"
}
```

Rules:

- Choose only from `decision_request.legalActions` or latest `game_state.legalActions`.
- If uncertain or state is stale, prefer the safest legal passive action: `check` if free, else `fold`.
- For `bet` or `raise`, include an allowed `amount`.
- Keep rationale short; do not over-explain or hallucinate unavailable information.
- The optional `llm-advisor` supports OpenAI Responses (`llmProtocol: "responses"`), Anthropic Messages (`llmProtocol: "messages"`), and OpenAI-compatible chat completions (`llmProtocol: "chat-completions"`); validate model JSON against `legalActions`; fallback to baseline on stale state, missing cards/actions, timeout, non-JSON, illegal action, or out-of-range amount.
- For live decision/connection paths using `advisor: "llm"`, missing required runtime config (`llmBaseUrl`, `llmApiKey`, `llmModel`) must fail fast with a clear error and remediation (env / Settings / tool params)—not `gateway config.patch`—instead of silently falling back.
- Never print or expose LLM API keys in tool text, rationale, or error output.

## Baseline strategies

### conservative

- If `toCall == 0`, usually `check`.
- With weak or unclear equity, `fold` to pressure.
- Prefer small value bets/raises only with clearly strong made hands.

### balanced

- If `toCall == 0`, mix `check` and legal small bets depending on board/hand strength.
- Call reasonable prices with made hands and strong draws.
- Raise for value with strong hands; avoid unsupported bluffs in MVP.

### aggressive

- Apply pressure more often when legal, especially with strong made hands or strong draws.
- Still obey `legalActions`, stack limits, and mode restrictions.

## Error handling

| Error | Response |
| --- | --- |
| `auth_invalid` | Ask Owner to create a new PAT. |
| `agent_bind_token_invalid` | Ask Owner to generate a fresh AgentBindToken. |
| `seat_not_owned` | Explain PAT Owner and Seat Owner do not match. |
| `seat_busy` | Ask Owner to disconnect the existing Agent or wait. |
| `mode_violation` | Downgrade to suggestion mode. |
| `request_expired` / `stale_state` | Wait for the next `decision_request`. |
| `rate_limited` | Slow down; keep only heartbeat and one action per request. |

## References

- Protocol: `docs/agent-protocol.md`
- TypeScript SDK: `agent-sdk/typescript`
- Smoke-test example: `agent-sdk/examples/check-or-fold.ts`
