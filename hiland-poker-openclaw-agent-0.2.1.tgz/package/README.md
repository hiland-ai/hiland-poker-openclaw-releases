# Hiland Poker — Agent SDK / OpenClaw Agent

Anything you need to write an Agent that sits in the Agent half of a Hiland Poker seat.


| Path                                           | What it is                                                                                                                    |
| ---------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| `[index.ts](index.ts)`                         | Native OpenClaw plugin entry. Registers Hiland Poker Agent tools.                                                             |
| `[openclaw.plugin.json](openclaw.plugin.json)` | OpenClaw plugin manifest/config schema.                                                                                       |
| `[typescript/](typescript)`                    | Strongly-typed TS SDK (`AgentClient`, wire types, baseline strategy, optional LLM advisor) usable from any Node ≥ 20 program. |
| `[openclaw-skill/](openclaw-skill)`            | Reference OpenClaw skill instructions.                                                                                        |
| `[examples/](examples)`                        | Tiny standalone bots (e.g. `check-or-fold.ts`) used for smoke testing.                                                        |


The wire protocol the SDK speaks is documented in `[../docs/agent-protocol.md](../docs/agent-protocol.md)`. Server `game_state` may include table context (`buttonSeat`, blinds, `streetBets`, `actionLog`, `pots`, `activeSeats` / `foldedSeats`, etc.); see §3.1 there. TypeScript `MsgGameState` in `[typescript/src/types.ts](typescript/src/types.ts)` mirrors these fields.

## OpenClaw plugin tools

The plugin registers three tools:

- `hiland_poker_agent_status` — checks config presence without revealing secrets.
- `hiland_poker_agent_decide` — computes one local action suggestion from a `game_state` / optional `decision_request`; no server connection. With `advisor: "llm"`, it may call the configured LLM provider.
- `hiland_poker_agent_connect` — establishes a long-lived owner-bound connection on `/agent` for observability and continuous decision flow; on connect it reports effective `llmProtocol` / `llmModel` / `llmBaseUrl` (base URL redacted).

Safety defaults:

- `autosubmit` is off, so even auto-capable modes emit `kind: "suggestion"` unless explicitly enabled.
- `advisor` defaults to `llm`.
- In decision/connection entry points (`decide`, `connect`), `advisor: "llm"` now requires runnable LLM config (`llmBaseUrl`, `llmApiKey`, `llmModel`). Missing items cause a clear error and execution is rejected.
- Tool text output never prints PATs, AgentBindTokens, JWTs, LLM API keys, or full token-bearing URLs.

## Configuration

Use OpenClaw plugin config or environment variables:


| Config key       | Env var                                                                                | Required           | Notes                                                                                                                                                                                                                                                                         |
| ---------------- | -------------------------------------------------------------------------------------- | ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `apiBaseUrl`     | `HILAND_API_BASE_URL`                                                                  | no                 | REST API origin used by status/connect fallbacks, e.g. `https://example.com`. If omitted, the plugin can derive it from `agentUrl`.                                                                                                                                           |
| `nickname`       | `OPENCLAW_USER_NICKNAME` / `OPENCLAW_USER_DISPLAY_NAME` / `OPENCLAW_USERNAME` / `USER` | no                 | Optional owner display name used in agent handshake metadata.                                                                                                                                                                                                                 |
| `agentUrl`       | `HILAND_AGENT_URL`                                                                     | yes for connecting | WebSocket endpoint, e.g. `wss://example.com/agent`.                                                                                                                                                                                                                           |
| `pat`            | `HILAND_PAT`                                                                           | yes for connecting | Owner Personal Access Token. Keep secret.                                                                                                                                                                                                                                     |
| `agentBindToken` | `HILAND_AGENT_BIND_TOKEN`                                                              | yes for connecting | Short-lived token bound to the owner. Keep secret.                                                                                                                                                                                                                            |
| `strategy`       | `HILAND_AGENT_STRATEGY`                                                                | no                 | Baseline fallback style: `conservative`, `balanced`, or `aggressive`; default `balanced`.                                                                                                                                                                                     |
| `persona`        | `HILAND_AGENT_PERSONA`                                                                 | no                 | Playstyle: `gto_cold`, `mad_dog`, `exploit`, `turtle`, `grudge`, `learning`, `trash_talk` (supports Chinese aliases like `疯狗`, `嘴炮`). Shapes baseline heuristics and LLM system instructions; `learning` rotates conservative→balanced→aggressive by hands observed per room. |
| `advisor`        | n/a                                                                                    | no                 | `baseline` or `llm`; default `llm`. Tool params can override this per decision/run.                                                                                                                                                                                           |
| `autosubmit`     | `HILAND_AGENT_AUTOSUBMIT`                                                              | no                 | `true` only when the Owner explicitly wants auto-play.                                                                                                                                                                                                                        |
| `llmProvider`    | `HILAND_LLM_ADVISOR_PROVIDER`                                                          | no                 | `openai-compatible` or `anthropic`; inferred from `llmProtocol` when omitted.                                                                                                                                                                                                 |
| `llmProtocol`    | `HILAND_LLM_PROTOCOL` / `OPENAI_PROTOCOL` / `ANTHROPIC_PROTOCOL`                       | no                 | `responses` = OpenAI Responses; `messages` = Anthropic Messages; `chat-completions` = OpenAI-compatible chat completions; default `responses`.                                                                                                                                |
| `llmBaseUrl`     | `HILAND_LLM_BASE_URL` / `OPENAI_BASE_URL` / `ANTHROPIC_BASE_URL`                       | no                 | Defaults to `https://api.openai.com/v1` for OpenAI protocols or `https://api.anthropic.com/v1` for Anthropic Messages. The SDK appends the endpoint for the selected protocol.                                                                                                |
| `llmApiKey`      | `HILAND_LLM_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`                          | yes for LLM        | Keep secret. Never put this in prompts or logs.                                                                                                                                                                                                                               |
| `llmModel`       | `HILAND_LLM_MODEL` / `OPENAI_MODEL` / `ANTHROPIC_MODEL`                                | no                 | Default `gpt-4o-mini` for OpenAI protocols or `claude-3-5-haiku-latest` for Anthropic Messages.                                                                                                                                                                               |
| `llmTimeoutMs`   | `HILAND_LLM_TIMEOUT_MS`                                                                | no                 | Default `3500`; minimum `500`.                                                                                                                                                                                                                                                |
| `llmTemperature` | `HILAND_LLM_TEMPERATURE`                                                               | no                 | Default `0.15`; clamped `0..1`.                                                                                                                                                                                                                                               |
| `llmMaxTokens`   | `HILAND_LLM_MAX_TOKENS`                                                                | no                 | Default `220`; clamped `80..1000`.                                                                                                                                                                                                                                            |
| `llmLanguage`    | `HILAND_LLM_LANGUAGE`                                                                  | no                 | `zh-CN` or `en`; default `zh-CN`.                                                                                                                                                                                                                                             |


## LLM advisor

`llm-advisor` converts the latest visible `game_state` and `decision_request` into a compact no-limit Hold'em decision object, calls the selected LLM endpoint, and validates the response before sending anything to Hiland Poker. It supports these protocol shapes:

- `llmProtocol: "responses"` — OpenAI Responses protocol, `POST {llmBaseUrl}/responses`, using `instructions`, `input`, and `max_output_tokens`.
- `llmProtocol: "messages"` — Anthropic Messages protocol, `POST {llmBaseUrl}/messages`, using `system`, `messages`, `max_tokens`, `x-api-key`, and `anthropic-version`.
- `llmProtocol: "chat-completions"` — OpenAI-compatible chat completions, `POST {llmBaseUrl}/chat/completions`, using `messages`, `max_tokens`, and `response_format`.

Expected model response:

```json
{"action":"call","amount":200,"confidence":0.68,"rationale":"赔率合适，继续看下一街。"}
```

Hard guards:

- The selected action must exist in `legalActions`.
- `bet` / `raise` amounts must be integers within `minAmount..maxAmount`.
- `call` / `allin` use the server-provided amount.
- Stale hand/state, missing hole cards, no legal actions, HTTP/model errors, non-JSON, or illegal JSON fallback to baseline.
- Missing required LLM runtime config (`llmBaseUrl`, `llmApiKey`, `llmModel`) is treated as configuration error at entry and will fail fast instead of silently falling back. Errors include remediation: use OpenClaw/chat env (`OPENAI_*`, `ANTHROPIC_*`, `HILAND_LLM_*`), plugin Settings, or per-call tool params—**not** `gateway config.patch` (protected plugin paths are rejected).
- Rationale is short and user-facing; API keys and token-bearing URLs are redacted from errors.

## Local validation

```bash
npm install
npm --prefix typescript install
npm run typecheck
npm run sdk:typecheck
npm run build
```

## Standalone SDK smoke bot

```bash
export HILAND_AGENT_URL='wss://example.com/agent'
export HILAND_PAT='...'
export HILAND_AGENT_BIND_TOKEN='...'
npm run example:check-or-fold
```

For one-off execution without installing root dev dependencies, you can also run `npx tsx examples/check-or-fold.ts`.

`check-or-fold.ts` remains intentionally simple: check when free, otherwise fold.