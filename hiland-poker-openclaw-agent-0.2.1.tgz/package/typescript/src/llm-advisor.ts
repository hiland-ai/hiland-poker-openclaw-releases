import type { DecideResult } from './client.js'
import { decideWithBaselineStrategy, type StrategyName } from './strategy.js'
import {
  personaSystemPromptAddendum,
  rationaleMaxChars,
  type AgentPersona,
} from './persona.js'
import type {
  ActionKind,
  AgentHandAction,
  AgentPotLayer,
  AgentSeatBet,
  LegalAction,
  MsgDecisionRequest,
  MsgGameState,
  RangedAmountLegalAction,
} from './types.js'

export type LLMAdvisorProvider = 'openai-compatible' | 'anthropic'
export type LLMAdvisorProtocol = 'responses' | 'messages' | 'chat-completions'

export interface LLMAdvisorConfig {
  /** Provider implied by protocol unless explicitly set. */
  provider: LLMAdvisorProvider
  /**
   * LLM request protocol:
   * - responses: OpenAI Responses API, POST /responses
   * - messages: Anthropic Messages API, POST /messages
   * - chat-completions: OpenAI-compatible Chat Completions, POST /chat/completions
   */
  protocol: LLMAdvisorProtocol
  baseUrl: string
  apiKey?: string
  model: string
  timeoutMs: number
  temperature: number
  maxTokens: number
  language: 'zh-CN' | 'en'
}

export interface LLMAdvisorContext {
  state: MsgGameState
  request?: MsgDecisionRequest
  legalActions: LegalAction[]
  strategy: StrategyName
  config: LLMAdvisorConfig
  persona?: AgentPersona
  personaHandIndex?: number
  nemesisSeat?: number | null
}

export type LLMAdvisorSource = 'llm' | 'baseline' | 'fallback'

export type LLMAdvisorDecision = DecideResult & {
  source: LLMAdvisorSource
  fallbackReason?: string
}

type OpenAICompatibleChatCompletionsResponse = {
  choices?: Array<{
    message?: { content?: string | null }
    text?: string | null
  }>
}

type OpenAICompatibleResponsesResponse = OpenAICompatibleChatCompletionsResponse & {
  output_text?: string | null
  output?: Array<{
    content?: Array<{
      type?: string
      text?: string | null
      json?: unknown
      value?: unknown
    }>
    text?: string | null
    json?: unknown
    value?: unknown
  }>
}

type AnthropicMessagesResponse = {
  content?: Array<{
    type?: string
    text?: string | null
  }>
}

type AdvisorJSON = {
  action?: unknown
  amount?: unknown
  confidence?: unknown
  rationale?: unknown
}

type PokerDecisionInput = {
  task: string
  game: string
  phase: string
  heroSeat: number
  heroHole: readonly string[] | null
  board: readonly string[]
  pot: number
  toCall: number
  minRaise: number
  heroStack: number
  effectiveStack: number | null
  stackToPotRatio: number | null
  potOdds: number
  playersInHand: number
  legalActions: LegalAction[]
  mode: string
  strategy: StrategyName
  persona?: AgentPersona
  personaHandIndex?: number
  nemesisSeat?: number | null
  buttonSeat?: number
  smallBlindSeat?: number
  bigBlindSeat?: number
  smallBlind?: number
  bigBlind?: number
  ante?: number
  streetMaxBet?: number
  lastRaiseDelta?: number
  anyAllIn?: boolean
  foldedSeats?: number[]
  activeSeats?: number[]
  streetBets?: AgentSeatBet[]
  actionLog?: AgentHandAction[]
  pots?: AgentPotLayer[]
}

const DEFAULT_TIMEOUT_MS = 3_500
const DEFAULT_TEMPERATURE = 0.15
const DEFAULT_MAX_TOKENS = 220
const DEFAULT_OPENAI_BASE_URL = 'https://api.openai.com/v1'
const DEFAULT_ANTHROPIC_BASE_URL = 'https://api.anthropic.com/v1'
const DEFAULT_ANTHROPIC_VERSION = '2023-06-01'

export function resolveLLMAdvisorConfig(raw: Record<string, unknown> = {}, env: NodeJS.ProcessEnv = process.env): LLMAdvisorConfig {
  const protocol = readProtocol(raw.llmProtocol ?? env.HILAND_LLM_PROTOCOL ?? env.OPENAI_PROTOCOL ?? env.ANTHROPIC_PROTOCOL)
  const provider = readProvider(raw.llmProvider ?? env.HILAND_LLM_ADVISOR_PROVIDER, protocol)
  const baseUrl =
    readString(raw.llmBaseUrl ?? env.HILAND_LLM_BASE_URL ?? protocolBaseUrlEnv(protocol, env)) ?? defaultBaseUrl(protocol)
  const apiKey = readString(raw.llmApiKey ?? env.HILAND_LLM_API_KEY ?? protocolApiKeyEnv(protocol, env))
  const model = readString(raw.llmModel ?? env.HILAND_LLM_MODEL ?? protocolModelEnv(protocol, env)) ?? defaultModel(protocol)
  const timeoutMs = Math.max(readInteger(raw.llmTimeoutMs ?? env.HILAND_LLM_TIMEOUT_MS, DEFAULT_TIMEOUT_MS), 500)
  const temperature = clampNumber(readNumber(raw.llmTemperature ?? env.HILAND_LLM_TEMPERATURE, DEFAULT_TEMPERATURE), 0, 1)
  const maxTokens = clampInteger(readInteger(raw.llmMaxTokens ?? env.HILAND_LLM_MAX_TOKENS, DEFAULT_MAX_TOKENS), 80, 1000)
  const language = readString(raw.llmLanguage ?? env.HILAND_LLM_LANGUAGE) === 'en' ? 'en' : 'zh-CN'
  return { provider, protocol, baseUrl, apiKey, model, timeoutMs, temperature, maxTokens, language }
}

export function hasRunnableLLMAdvisor(config: LLMAdvisorConfig): boolean {
  return Boolean(config.baseUrl && config.apiKey && config.model)
}

export function listMissingLLMAdvisorRequirements(config: LLMAdvisorConfig): Array<'baseUrl' | 'apiKey' | 'model'> {
  const missing: Array<'baseUrl' | 'apiKey' | 'model'> = []
  if (!config.baseUrl) missing.push('baseUrl')
  if (!config.apiKey) missing.push('apiKey')
  if (!config.model) missing.push('model')
  return missing
}

export async function decideWithLLMAdvisor(ctx: LLMAdvisorContext): Promise<LLMAdvisorDecision> {
  const baseline = decideWithBaselineStrategy({
    state: ctx.state,
    request: ctx.request,
    legalActions: ctx.legalActions,
    strategy: ctx.strategy,
    persona: ctx.persona,
    personaHandIndex: ctx.personaHandIndex,
    nemesisSeat: ctx.nemesisSeat,
  })

  if (!hasRunnableLLMAdvisor(ctx.config)) {
    return { ...baseline, source: 'baseline', fallbackReason: 'llm_not_configured' }
  }

  const freshness = validateDecisionFreshness(ctx.state, ctx.request, ctx.legalActions)
  if (freshness) return { ...baseline, source: 'fallback', fallbackReason: freshness }

  try {
    const input = buildPokerDecisionInput(
      ctx.state,
      ctx.request,
      ctx.legalActions,
      ctx.strategy,
      ctx.persona,
      ctx.personaHandIndex,
      ctx.nemesisSeat,
    )
    const ai = await callLLMAdvisor(input, ctx.config, ctx.persona)
    const validated = validateAdvisorJSON(ai, ctx.legalActions, ctx.config.language, ctx.persona)
    return { ...validated, source: 'llm' }
  } catch (error) {
    return { ...baseline, source: 'fallback', fallbackReason: userSafeLLMError(error) }
  }
}

export function buildPokerDecisionInput(
  state: MsgGameState,
  request: MsgDecisionRequest | undefined,
  legalActions: LegalAction[],
  strategy: StrategyName,
  persona?: AgentPersona,
  personaHandIndex?: number,
  nemesisSeat?: number | null,
): PokerDecisionInput {
  const heroStack = Number(state.stacks?.[state.yourSeat] ?? 0)
  const opponentStacks = Object.entries(state.stacks ?? {})
    .filter(([seat]) => Number(seat) !== state.yourSeat)
    .map(([, stack]) => Number(stack))
    .filter((stack) => Number.isFinite(stack) && stack > 0)
  const effectiveStack = opponentStacks.length ? Math.min(heroStack, ...opponentStacks) : heroStack || null
  const pot = Math.max(0, Number(state.pot ?? 0))
  const toCall = Math.max(0, Number(state.toCall ?? 0))
  const playersInHand =
    state.activeSeats?.length ??
    Object.values(state.stacks ?? {}).filter((stack) => Number(stack) > 0).length

  return {
    task: 'Choose exactly one Texas Holdem advisor action from legalActions. Return JSON only.',
    game: 'No-limit Texas Holdem',
    phase: state.phase,
    heroSeat: state.yourSeat,
    heroHole: state.yourHole,
    board: state.board ?? [],
    pot,
    toCall,
    minRaise: Math.max(0, Number(state.minRaise ?? 0)),
    heroStack,
    effectiveStack,
    stackToPotRatio: pot > 0 ? round(heroStack / pot, 3) : null,
    potOdds: toCall > 0 ? round(toCall / (pot + toCall), 3) : 0,
    playersInHand,
    legalActions,
    mode: request?.mode ?? state.mode,
    strategy,
    persona,
    personaHandIndex,
    nemesisSeat: nemesisSeat ?? null,
    buttonSeat: state.buttonSeat,
    smallBlindSeat: state.smallBlindSeat,
    bigBlindSeat: state.bigBlindSeat,
    smallBlind: state.smallBlind,
    bigBlind: state.bigBlind,
    ante: state.ante,
    streetMaxBet: state.streetMaxBet,
    lastRaiseDelta: state.lastRaiseDelta,
    anyAllIn: state.anyAllIn,
    foldedSeats: state.foldedSeats,
    activeSeats: state.activeSeats,
    streetBets: state.streetBets,
    actionLog: state.actionLog,
    pots: state.pots,
  }
}

function validateDecisionFreshness(state: MsgGameState, request: MsgDecisionRequest | undefined, legalActions: LegalAction[]): string | undefined {
  if (request?.handId && state.handId && request.handId !== state.handId) return 'hand_mismatch'
  if (request?.stateSeq !== undefined && state.stateSeq !== undefined && request.stateSeq !== state.stateSeq) return 'stale_state'
  if (state.actionOn !== null && state.actionOn !== state.yourSeat) return 'not_your_turn'
  if (!state.yourHole || state.yourHole.length !== 2) return 'missing_hole_cards'
  if (!legalActions.length) return 'missing_legal_actions'
  return undefined
}

async function callLLMAdvisor(input: PokerDecisionInput, config: LLMAdvisorConfig, persona?: AgentPersona): Promise<AdvisorJSON> {
  if (config.protocol === 'messages') return callAnthropicMessages(input, config, persona)
  if (config.protocol === 'chat-completions') return callOpenAICompatibleChatCompletions(input, config, persona)
  return callOpenAICompatibleResponses(input, config, persona)
}

async function callOpenAICompatibleResponses(
  input: PokerDecisionInput,
  config: LLMAdvisorConfig,
  persona?: AgentPersona,
): Promise<AdvisorJSON> {
  const parsed = await postLLMJSON<OpenAICompatibleResponsesResponse>(config, '/responses', {
    model: config.model,
    temperature: config.temperature,
    max_output_tokens: config.maxTokens,
    text: { format: { type: 'json_object' } },
    instructions: systemPrompt(config.language, persona),
    input: JSON.stringify(input),
  })
  const content = extractResponsesContent(parsed)
  if (!content) throw new Error('llm_empty_response')
  return parseJSONObject(content)
}

async function callAnthropicMessages(
  input: PokerDecisionInput,
  config: LLMAdvisorConfig,
  persona?: AgentPersona,
): Promise<AdvisorJSON> {
  const parsed = await postLLMJSON<AnthropicMessagesResponse>(config, '/messages', {
    model: config.model,
    temperature: config.temperature,
    max_tokens: config.maxTokens,
    system: systemPrompt(config.language, persona),
    messages: [{ role: 'user', content: JSON.stringify(input) }],
  })
  const content = extractAnthropicMessagesContent(parsed)
  if (!content) throw new Error('llm_empty_response')
  return parseJSONObject(content)
}

async function callOpenAICompatibleChatCompletions(
  input: PokerDecisionInput,
  config: LLMAdvisorConfig,
  persona?: AgentPersona,
): Promise<AdvisorJSON> {
  const parsed = await postLLMJSON<OpenAICompatibleChatCompletionsResponse>(config, '/chat/completions', {
    model: config.model,
    temperature: config.temperature,
    max_tokens: config.maxTokens,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: systemPrompt(config.language, persona) },
      { role: 'user', content: JSON.stringify(input) },
    ],
  })
  const content = extractChatCompletionsContent(parsed)
  if (!content) throw new Error('llm_empty_response')
  return parseJSONObject(content)
}

async function postLLMJSON<T>(config: LLMAdvisorConfig, path: string, body: unknown): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), config.timeoutMs)
  try {
    const response = await fetch(joinURL(config.baseUrl, path), {
      method: 'POST',
      headers: buildLLMHeaders(config),
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    const text = await response.text()
    if (!response.ok) throw new Error(`llm_http_${response.status}: ${text.slice(0, 240)}`)
    try {
      return JSON.parse(text) as T
    } catch {
      throw new Error('llm_invalid_response_json')
    }
  } finally {
    clearTimeout(timeout)
  }
}

function buildLLMHeaders(config: LLMAdvisorConfig): Record<string, string> {
  if (config.protocol === 'messages') {
    return {
      'Content-Type': 'application/json',
      'anthropic-version': DEFAULT_ANTHROPIC_VERSION,
      'x-api-key': config.apiKey ?? '',
    }
  }

  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${config.apiKey ?? ''}`,
  }
}

function extractChatCompletionsContent(parsed: OpenAICompatibleChatCompletionsResponse): string | undefined {
  return nonEmptyString(parsed.choices?.[0]?.message?.content) ?? nonEmptyString(parsed.choices?.[0]?.text)
}

function extractResponsesContent(parsed: OpenAICompatibleResponsesResponse): string | undefined {
  const direct = nonEmptyString(parsed.output_text)
  if (direct) return direct

  for (const item of parsed.output ?? []) {
    const itemText = nonEmptyString(item.text) ?? stringifyContentValue(item.json) ?? stringifyContentValue(item.value)
    if (itemText) return itemText
    for (const content of item.content ?? []) {
      const contentText = nonEmptyString(content.text) ?? stringifyContentValue(content.json) ?? stringifyContentValue(content.value)
      if (contentText) return contentText
    }
  }

  return extractChatCompletionsContent(parsed)
}

function extractAnthropicMessagesContent(parsed: AnthropicMessagesResponse): string | undefined {
  const parts = (parsed.content ?? [])
    .map((item) => nonEmptyString(item.text))
    .filter((item): item is string => Boolean(item))
  return parts.length ? parts.join('\n') : undefined
}

function nonEmptyString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() !== '' ? value : undefined
}

function stringifyContentValue(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined
  if (typeof value === 'string') return nonEmptyString(value)
  if (typeof value === 'object') return JSON.stringify(value)
  return undefined
}

function systemPrompt(language: LLMAdvisorConfig['language'], persona?: AgentPersona): string {
  const rationaleLanguage = language === 'en' ? 'English' : 'Simplified Chinese'
  const maxR = rationaleMaxChars(persona)
  const lines = [
    'You are a Texas Holdem poker advisor.',
    'Choose exactly one action from the provided legalActions array.',
    'Never invent actions, cards, opponents hole cards, or unavailable information.',
    'For bet/raise, amount must be an integer between minAmount and maxAmount inclusive.',
    'For call/allin, use the provided amount if present.',
    'For fold/check, omit amount or use 0.',
    'Return JSON only with keys: action, amount, confidence, rationale.',
    'confidence must be a number from 0 to 1.',
    `rationale must be ${rationaleLanguage}, concise, <= ${maxR} characters.`,
  ]
  if (persona) lines.push(personaSystemPromptAddendum(persona, language))
  return lines.join('\n')
}

function validateAdvisorJSON(
  ai: AdvisorJSON,
  legalActions: LegalAction[],
  language: LLMAdvisorConfig['language'],
  persona?: AgentPersona,
): DecideResult {
  const action = typeof ai.action === 'string' ? ai.action : ''
  if (!isActionKind(action)) throw new Error('llm_invalid_action')
  const legal = legalActions.find((item) => item.action === action)
  if (!legal) throw new Error('llm_action_not_legal')

  const confidence = clampNumber(readNumber(ai.confidence, 0.55), 0, 1)
  const rationale = sanitizeRationale(
    typeof ai.rationale === 'string' ? ai.rationale : defaultRationale(action, language),
    language,
    rationaleMaxChars(persona),
  )

  if (action === 'fold' || action === 'check') {
    return { action, amount: undefined, confidence, rationale }
  }

  if (action === 'call' || action === 'allin') {
    return { action, amount: 'amount' in legal ? legal.amount : undefined, confidence, rationale }
  }

  const ranged = legal as RangedAmountLegalAction
  const minAmount = ranged.minAmount ?? ranged.amount ?? 0
  const maxAmount = ranged.maxAmount ?? ranged.amount ?? minAmount
  const amount = readInteger(ai.amount, Number.NaN)
  if (!Number.isFinite(amount)) throw new Error('llm_invalid_amount')
  if (amount < minAmount || amount > maxAmount) throw new Error('llm_amount_out_of_range')
  return { action, amount, confidence, rationale }
}

function parseJSONObject(content: string): AdvisorJSON {
  const trimmed = content.trim()
  try {
    return JSON.parse(trimmed) as AdvisorJSON
  } catch {
    const match = trimmed.match(/\{[\s\S]*\}/)
    if (!match) throw new Error('llm_non_json_response')
    return JSON.parse(match[0]) as AdvisorJSON
  }
}

function isActionKind(value: string): value is ActionKind {
  return value === 'fold' || value === 'check' || value === 'call' || value === 'bet' || value === 'raise' || value === 'allin'
}

function defaultRationale(action: ActionKind, language: LLMAdvisorConfig['language']): string {
  if (language === 'en') return `Legal ${action} selected after evaluating visible state.`
  return `根据当前可见牌面，选择合法动作 ${action}。`
}

function sanitizeRationale(
  value: string,
  language: LLMAdvisorConfig['language'],
  maxLen: number,
): string {
  const trimmed = value.replace(/\s+/g, ' ').trim()
  const fallback = language === 'en' ? 'Legal action selected from current visible state.' : '基于当前可见信息选择该合法动作。'
  const cap = Math.max(40, Math.min(maxLen, 320))
  return (trimmed || fallback).slice(0, cap)
}

function joinURL(base: string, path: string): string {
  const normalized = base.endsWith('/') ? base : `${base}/`
  return new URL(path.replace(/^\//, ''), normalized).toString()
}

function readProvider(value: unknown, protocol: LLMAdvisorProtocol): LLMAdvisorProvider {
  const normalized = readString(value)?.toLowerCase()
  if (normalized === 'anthropic' || normalized === 'anthropic-compatible') return 'anthropic'
  if (normalized === 'openai' || normalized === 'openai-compatible') return 'openai-compatible'
  return protocol === 'messages' ? 'anthropic' : 'openai-compatible'
}

function readProtocol(value: unknown): LLMAdvisorProtocol {
  const normalized = readString(value)?.toLowerCase()
  if (normalized === 'responses' || normalized === 'response' || normalized === 'openai-responses' || normalized === 'openai_responses') {
    return 'responses'
  }
  if (normalized === 'messages' || normalized === 'message' || normalized === 'anthropic-messages' || normalized === 'anthropic_messages') {
    return 'messages'
  }
  if (
    normalized === 'chat-completions' ||
    normalized === 'chat_completions' ||
    normalized === 'chat-completion' ||
    normalized === 'chat_completion' ||
    normalized === 'openai-chat-completions' ||
    normalized === 'openai_chat_completions'
  ) {
    return 'chat-completions'
  }
  return 'responses'
}

function defaultBaseUrl(protocol: LLMAdvisorProtocol): string {
  return protocol === 'messages' ? DEFAULT_ANTHROPIC_BASE_URL : DEFAULT_OPENAI_BASE_URL
}

function defaultModel(protocol: LLMAdvisorProtocol): string {
  return protocol === 'messages' ? 'claude-3-5-haiku-latest' : 'gpt-4o-mini'
}

function protocolBaseUrlEnv(protocol: LLMAdvisorProtocol, env: NodeJS.ProcessEnv): string | undefined {
  return protocol === 'messages' ? env.ANTHROPIC_BASE_URL : env.OPENAI_BASE_URL
}

function protocolApiKeyEnv(protocol: LLMAdvisorProtocol, env: NodeJS.ProcessEnv): string | undefined {
  return protocol === 'messages' ? env.ANTHROPIC_API_KEY : env.OPENAI_API_KEY
}

function protocolModelEnv(protocol: LLMAdvisorProtocol, env: NodeJS.ProcessEnv): string | undefined {
  return protocol === 'messages' ? env.ANTHROPIC_MODEL : env.OPENAI_MODEL
}

function readString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined
}

function readNumber(value: unknown, fallback: number): number {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return fallback
}

function readInteger(value: unknown, fallback: number): number {
  const number = readNumber(value, fallback)
  return Number.isFinite(number) ? Math.trunc(number) : fallback
}

function clampNumber(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value))
}

function clampInteger(value: number, min: number, max: number): number {
  return Math.trunc(clampNumber(value, min, max))
}

function round(value: number, digits: number): number {
  const factor = 10 ** digits
  return Math.round(value * factor) / factor
}

function userSafeLLMError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  return message
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, 'Bearer <redacted>')
    .replace(/x-api-key\s*[:=]\s*[^\s,)]+/gi, 'x-api-key=<redacted>')
    .replace(/\bsk-[A-Za-z0-9_-]+\b/g, '<redacted-api-key>')
    .replace(/([?&](?:apiKey|llmApiKey|token)=)[^&\s)]+/gi, '$1<redacted>')
    .slice(0, 180)
}
